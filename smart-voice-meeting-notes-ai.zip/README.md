# Smart Voice Meeting Notes AI

**Dengar. Catat. Rangkum. Dokumentasikan.**

Aplikasi web statis (Free-First / GitHub Pages Ready) untuk merekam rapat, seminar, pelatihan, dan kegiatan profesional langsung dari browser, menyimpan audio secara bertahap di IndexedDB, menyusun transkrip & notulen format A–I, serta mengekspor dokumen (DOCX, HTML, TXT, CSV, Cetak/PDF).

## Fitur Utama (100% Berjalan Tanpa Server Wajib)
- **Rekam Audio Lokal**: MediaRecorder API + Web Audio API visualizer + penyimpanan chunk bertahap ke IndexedDB + pemulihan rekaman yang terhenti.
- **Transkripsi Browser & Manual**: Mendukung Web Speech API (`id-ID`) jika browser mendukung, serta editor transkrip lengkap dengan timestamp, label pembicara, tanda `[PENTING]`, dan `[TIDAK JELAS]`.
- **Notulen & Output Terstruktur**: Format `NOTULEN RAPAT` A–I, ringkasan, keputusan, tabel tindak lanjut, laporan, surat, ide, dan outline presentasi.
- **Ekspor Dokumen Client-Side**: Unduh `.docx` (Word), `.html`, `.txt`, `.csv` (termasuk format 4-sheet), dan Cetak / Simpan PDF.
- **AI Opsional (Gemini API)**: Pengguna dapat memasukkan API Key sendiri di memori sesi (tidak disimpan permanen di browser/repo) untuk transkripsi audio AI, penyusunan notulen, dan Tanya Rapat.
- **Google Docs & Sheets Opsional**: Mendukung OAuth Client ID opsional dari browser tanpa backend; selalu tersedia alternatif DOCX & CSV.
- **Backup & Restore JSON**: Ekspor dan pulihkan data rapat (dengan pilihan menyertakan atau mengecualikan audio).
- **PWA Offline Shell**: Dapat dipasang di Android / Desktop melalui `manifest.json` dan `sw.js`.

## Cara Publikasi Gratis di GitHub Pages

### Opsi 1: Tanpa Build / Tanpa Terminal (Menggunakan folder `docs/`)
Proyek ini sudah menyertakan hasil build statis siap pakai di folder **`docs/`** dengan path relatif (`./`):
1. Unduh seluruh proyek dari Google AI Studio.
2. Buat repositori baru di GitHub dan unggah seluruh isi proyek (termasuk folder `docs/`).
3. Buka **Settings -> Pages** di repositori GitHub Anda.
4. Pada **Build and deployment -> Source**, pilih **Deploy from a branch**.
5. Pilih Branch **`main`** dan Folder **`/docs`**, lalu klik **Save**.
6. Dalam 1–2 menit, aplikasi dapat diakses gratis di `https://<username>.github.io/<nama-repo>/`.

### Opsi 2: Otomatis via GitHub Actions
Repositori ini juga dilengkapi `.github/workflows/deploy-pages.yml` jika Anda ingin mengaktifkan **Source: GitHub Actions** pada **Settings -> Pages**.

## Privasi & Keamanan
- Jangan pernah menanamkan API Key atau token rahasia di dalam repositori GitHub.
- Aplikasi inti tidak membutuhkan Cloud Billing, Firebase, Supabase, atau server backend.
