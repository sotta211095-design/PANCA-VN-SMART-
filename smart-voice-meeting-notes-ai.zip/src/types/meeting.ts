export type ThemeMode = 'dark' | 'light';

export type NavigationTab =
  | 'dashboard'
  | 'recorder'
  | 'history'
  | 'assistant'
  | 'settings'
  | 'privacy'
  | 'detail';

export type TranscriptionStatus =
  | 'belum_ada'
  | 'draft_browser'
  | 'manual'
  | 'ai_sebagian'
  | 'ai_selesai';

export type DocumentStatus =
  | 'belum_ada'
  | 'template_lokal'
  | 'ai_draft';

export type LetterKind =
  | 'tindak_lanjut'
  | 'undangan'
  | 'permohonan'
  | 'tugas'
  | 'internal';

export interface TranscriptSegment {
  id: string;
  timestampSeconds: number | null;
  speaker: string;
  text: string;
  isImportant?: boolean;
  isUnclear?: boolean;
  note?: string;
}

export interface DecisionItem {
  id: string;
  decision: string;
  notes: string;
}

export interface ActionItem {
  id: string;
  task: string;
  pic: string;
  deadline: string;
  status: 'Belum Dimulai' | 'Proses' | 'Selesai';
}

export interface NotulenData {
  source: 'template' | 'ai';
  generatedAt: string;
  informasiKegiatan: {
    namaKegiatan: string;
    tanggal: string;
    waktu: string;
    lokasi: string;
    agenda: string;
    peserta: string;
    pimpinan: string;
    notulis: string;
  };
  tujuanRapat: string;
  ringkasanPembahasan: string;
  pokokPembahasan: string[];
  keputusanDanKesepakatan: string[];
  kendalaDanCatatan: string;
  kesimpulan: string;
  catatanPenyusunan: string;
}

export interface ReportOutput {
  pendahuluan: string;
  tujuan: string;
  pelaksanaan: string;
  pembahasan: string;
  hasil: string;
  kesimpulan: string;
  tindakLanjut: string;
}

export interface PresentationSlide {
  slideNumber: number;
  title: string;
  bullets: string[];
}

export interface DiscussionTopic {
  id: string;
  topic: string;
  summary: string;
}

export interface MeetingRecord {
  id: string;
  title: string;
  activityName: string;
  category: string;
  date: string;
  startTime: string;
  location: string;
  notes: string;
  durationSeconds: number;
  createdAt: string;
  updatedAt: string;
  recordingState: 'completed' | 'recovered' | 'manual_entry';
  transcriptionStatus: TranscriptionStatus;
  documentStatus: DocumentStatus;
  hasAudio: boolean;
  audioMimeType: string;
  audioByteSize: number;
  audioChunkCount: number;
  transcriptSegments: TranscriptSegment[];
  notulen: NotulenData | null;
  summaryText: string;
  decisions: DecisionItem[];
  actionItems: ActionItem[];
  discussionTopics: DiscussionTopic[];
  reportOutput: ReportOutput | null;
  letterKind: LetterKind;
  letterOutput: string;
  ideasOutput: string[];
  presentationOutline: PresentationSlide[];
  googleDocsUrl?: string;
  googleSheetsUrl?: string;
}

export interface AudioChunkRecord {
  id: string;
  meetingId: string;
  seq: number;
  blob: Blob;
  size: number;
  mimeType: string;
  createdAt: number;
}

export interface AppSettings {
  theme: ThemeMode;
  language: 'id-ID' | 'en-US';
  speechLanguage: 'id-ID' | 'en-US' | 'ms-MY';
  autoDeleteAudioAfterTranscript: boolean;
  customCategories: string[];
  geminiModel: string;
  googleClientId: string;
}

export interface BackupPayload {
  schemaVersion: number;
  appName: string;
  exportedAt: string;
  includesAudio: boolean;
  settings: AppSettings;
  meetings: MeetingRecord[];
  audioFiles?: Array<{
    meetingId: string;
    mimeType: string;
    base64Data: string;
  }>;
}

export interface ToastMessage {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  description?: string;
}

export const DEFAULT_CATEGORIES: string[] = [
  'Rapat Sekolah',
  'Pendampingan Digitalisasi',
  'Workshop',
  'Pelatihan',
  'Sosialisasi',
  'Seminar',
  'Diskusi',
  'Rapat Koordinasi',
  'Kegiatan Pendidikan',
  'Kegiatan Pemerintahan',
  'Lainnya',
];

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  language: 'id-ID',
  speechLanguage: 'id-ID',
  autoDeleteAudioAfterTranscript: false,
  customCategories: [],
  geminiModel: 'gemini-4-hydrogen',
  googleClientId: '',
};
