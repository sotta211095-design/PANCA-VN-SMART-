import {
  ActionItem,
  BackupPayload,
  DecisionItem,
  DEFAULT_SETTINGS,
  DiscussionTopic,
  LetterKind,
  MeetingRecord,
  NotulenData,
  PresentationSlide,
  ReportOutput,
  TranscriptSegment,
} from '../types/meeting';
import { formatDurationHMS, generateId } from './formatters';

export function formatTranscriptLine(seg: TranscriptSegment): string {
  const speaker = seg.speaker.trim() || 'Pembicara 1';
  const flags: string[] = [];
  if (seg.isImportant) flags.push('[PENTING]');
  if (seg.isUnclear) flags.push('[TIDAK JELAS]');
  const prefixFlags = flags.length > 0 ? `${flags.join(' ')} ` : '';

  if (seg.timestampSeconds !== null && Number.isFinite(seg.timestampSeconds)) {
    return `[${formatDurationHMS(seg.timestampSeconds)}] ${speaker}: ${prefixFlags}${seg.text}`;
  }
  return `${speaker}: ${prefixFlags}${seg.text}`;
}

export function formatTranscriptText(segments: TranscriptSegment[]): string {
  return segments.map(formatTranscriptLine).join('\n');
}

export function parseTimeToSeconds(hms: string): number | null {
  const match = hms.match(/^(\d{2}):(\d{2}):(\d{2})$/);
  if (!match) return null;
  const h = Number(match[1]);
  const m = Number(match[2]);
  const s = Number(match[3]);
  if (m >= 60 || s >= 60) return null;
  return h * 3600 + m * 60 + s;
}

export function parseTranscriptLines(rawText: string): TranscriptSegment[] {
  const lines = rawText
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  return lines.map((line, index) => {
    let remaining = line;
    let timestampSeconds: number | null = null;
    let speaker = 'Pembicara 1';

    const tsMatch = remaining.match(/^\[(\d{2}:\d{2}:\d{2})\]\s*(.*)$/);
    if (tsMatch) {
      timestampSeconds = parseTimeToSeconds(tsMatch[1]);
      remaining = tsMatch[2];
    }

    const spkMatch = remaining.match(/^([^:]{1,40}):\s*(.*)$/);
    if (spkMatch) {
      speaker = spkMatch[1].trim() || 'Pembicara 1';
      remaining = spkMatch[2];
    }

    const isImportant = remaining.includes('[PENTING]');
    const isUnclear = remaining.includes('[TIDAK JELAS]');
    remaining = remaining
      .replace(/\[PENTING\]\s*/g, '')
      .replace(/\[TIDAK JELAS\]\s*/g, '')
      .trim();

    return {
      id: `seg_${index}_${remaining.slice(0, 12)}`,
      timestampSeconds,
      speaker,
      text: remaining,
      isImportant,
      isUnclear,
    };
  });
}

export function generateTemplateNotulen(meeting: MeetingRecord): NotulenData {
  const transcriptText = formatTranscriptText(meeting.transcriptSegments).trim();
  const hasTranscript = transcriptText.length > 0;
  const excerptLines = meeting.transcriptSegments
    .slice(0, 5)
    .map((s) => `${s.speaker}: ${s.text}`);

  return {
    source: 'template',
    generatedAt: new Date().toISOString(),
    informasiKegiatan: {
      namaKegiatan: meeting.activityName.trim() || meeting.title.trim() || 'Belum diisi',
      tanggal: meeting.date.trim() || 'Belum diisi',
      waktu: meeting.startTime.trim() || 'Belum diisi',
      lokasi: meeting.location.trim() || 'Belum diisi',
      agenda: meeting.title.trim() || 'Belum diisi',
      peserta: 'Belum diisi',
      pimpinan: 'Belum diisi',
      notulis: 'Belum diisi',
    },
    tujuanRapat: meeting.notes.trim()
      ? `Catatan awal kegiatan: ${meeting.notes.trim()}`
      : 'Belum diisi — silakan lengkapi tujuan rapat berdasarkan agenda kegiatan.',
    ringkasanPembahasan: hasTranscript
      ? `Template lokal disusun dari ${meeting.transcriptSegments.length} segmen transkrip yang tersimpan. Silakan tinjau dan rapikan ringkasan berikut:\n\n${excerptLines.join('\n')}`
      : 'Belum ada transkrip tersimpan. Silakan tambahkan transkrip atau isi ringkasan pembahasan secara manual.',
    pokokPembahasan: hasTranscript
      ? meeting.transcriptSegments
          .filter((s) => s.isImportant)
          .map((s) => s.text)
          .slice(0, 8)
      : [],
    keputusanDanKesepakatan:
      meeting.decisions.length > 0
        ? meeting.decisions.map((d) => d.decision)
        : ['Belum ditemukan keputusan yang dinyatakan secara jelas.'],
    kendalaDanCatatan: meeting.transcriptSegments.some((s) => s.isUnclear)
      ? 'Terdapat bagian transkrip yang ditandai [TIDAK JELAS] dan perlu verifikasi ulang terhadap rekaman audio.'
      : 'Belum ada kendala yang dicatat secara eksplisit.',
    kesimpulan: hasTranscript
      ? 'Notulen ini merupakan draf template lokal non-AI. Mohon periksa kembali kesesuaian fakta, keputusan, dan tindak lanjut sebelum dibagikan.'
      : 'Belum ada kesimpulan — silakan lengkapi setelah transkrip atau catatan rapat tersedia.',
    catatanPenyusunan:
      'Disusun menggunakan Template Lokal (tanpa AI). Data seperti peserta, pimpinan, notulis, keputusan, dan PIC tidak dikarang otomatis dan perlu dilengkapi/diperiksa oleh notulis.',
  };
}

export function formatNotulenMarkdownText(notulen: NotulenData, actionItems: ActionItem[]): string {
  const info = notulen.informasiKegiatan;
  const lines: string[] = [
    'NOTULEN RAPAT',
    '============================================================',
    '',
    'A. Informasi Kegiatan',
    `- Nama Kegiatan : ${info.namaKegiatan || 'Belum diisi'}`,
    `- Tanggal       : ${info.tanggal || 'Belum diisi'}`,
    `- Waktu         : ${info.waktu || 'Belum diisi'}`,
    `- Lokasi        : ${info.lokasi || 'Belum diisi'}`,
    `- Agenda        : ${info.agenda || 'Belum diisi'}`,
    `- Peserta       : ${info.peserta || 'Belum diisi'}`,
    `- Pimpinan      : ${info.pimpinan || 'Belum diisi'}`,
    `- Notulis       : ${info.notulis || 'Belum diisi'}`,
    '',
    'B. Tujuan Rapat',
    notulen.tujuanRapat || 'Belum diisi',
    '',
    'C. Ringkasan Pembahasan',
    notulen.ringkasanPembahasan || 'Belum diisi',
    '',
    'D. Pokok Pembahasan',
    ...(notulen.pokokPembahasan.length > 0
      ? notulen.pokokPembahasan.map((item, idx) => `${idx + 1}. ${item}`)
      : ['Belum diisi']),
    '',
    'E. Keputusan dan Kesepakatan',
    ...(notulen.keputusanDanKesepakatan.length > 0
      ? notulen.keputusanDanKesepakatan.map((item, idx) => `${idx + 1}. ${item}`)
      : ['Belum ditemukan keputusan yang dinyatakan secara jelas.']),
    '',
    'F. Tindak Lanjut',
  ];

  if (actionItems.length === 0) {
    lines.push('Belum ada tindak lanjut yang dicatat.');
  } else {
    lines.push('No | Tindak Lanjut | PIC | Tenggat | Status');
    actionItems.forEach((item, idx) => {
      lines.push(
        `${idx + 1} | ${item.task || 'Belum diisi'} | ${item.pic || 'Belum ditentukan'} | ${item.deadline || 'Belum ditentukan'} | ${item.status}`
      );
    });
  }

  lines.push(
    '',
    'G. Kendala dan Catatan Penting',
    notulen.kendalaDanCatatan || 'Belum ada catatan kendala.',
    '',
    'H. Kesimpulan',
    notulen.kesimpulan || 'Belum diisi',
    '',
    'I. Catatan Penyusunan',
    notulen.catatanPenyusunan ||
      'Dokumen ini perlu diperiksa kembali sebelum digunakan sebagai dokumen resmi.'
  );

  return lines.join('\n');
}

export function generateTemplateSummary(meeting: MeetingRecord): string {
  if (meeting.transcriptSegments.length === 0) {
    return 'Belum ada transkrip untuk dirangkum. Silakan rekam, transkrip, atau tulis catatan rapat terlebih dahulu.';
  }
  const important = meeting.transcriptSegments.filter((s) => s.isImportant);
  const base = (important.length > 0 ? important : meeting.transcriptSegments).slice(0, 6);
  return [
    `Ringkasan Lokal (Template Non-AI) — ${meeting.title || 'Rapat Tanpa Judul'}`,
    `Tanggal: ${meeting.date || 'Belum diisi'} · Kategori: ${meeting.category}`,
    '',
    'Poin yang tercatat dalam transkrip:',
    ...base.map((s) => `- ${formatTranscriptLine(s)}`),
    '',
    'Catatan: Ringkasan ini diambil langsung dari baris transkrip lokal tanpa pemrosesan AI.',
  ].join('\n');
}

export function generateTemplateReport(meeting: MeetingRecord): ReportOutput {
  const infoTitle = meeting.activityName || meeting.title || 'Kegiatan Rapat';
  return {
    pendahuluan: `Laporan ini mendokumentasikan pelaksanaan kegiatan "${infoTitle}" kategori ${meeting.category}.`,
    tujuan: meeting.notes.trim() || 'Belum diisi — lengkapi tujuan pelaksanaan kegiatan.',
    pelaksanaan: `Dilaksanakan pada tanggal ${meeting.date || 'Belum diisi'} pukul ${meeting.startTime || 'Belum diisi'} bertempat di ${meeting.location || 'Belum diisi'} dengan durasi rekaman ${formatDurationHMS(meeting.durationSeconds)}.`,
    pembahasan:
      meeting.summaryText.trim() ||
      (meeting.transcriptSegments.length > 0
        ? meeting.transcriptSegments.slice(0, 4).map((s) => s.text).join(' ')
        : 'Belum ada transkrip pembahasan.'),
    hasil:
      meeting.decisions.length > 0
        ? meeting.decisions.map((d, i) => `${i + 1}. ${d.decision}`).join('\n')
        : 'Belum ditemukan keputusan yang dinyatakan secara jelas.',
    kesimpulan:
      meeting.notulen?.kesimpulan ||
      'Kegiatan telah didokumentasikan secara lokal. Silakan tinjau kembali rincian hasil dan tindak lanjut.',
    tindakLanjut:
      meeting.actionItems.length > 0
        ? meeting.actionItems
            .map(
              (a, i) =>
                `${i + 1}. ${a.task} (PIC: ${a.pic || 'Belum ditentukan'}, Tenggat: ${a.deadline || 'Belum ditentukan'}, Status: ${a.status})`
            )
            .join('\n')
        : 'Belum ada daftar tindak lanjut.',
  };
}

export function generateTemplateLetter(meeting: MeetingRecord, kind: LetterKind): string {
  const kindLabels: Record<LetterKind, string> = {
    tindak_lanjut: 'SURAT TINDAK LANJUT HASIL RAPAT',
    undangan: 'SURAT UNDANGAN RAPAT',
    permohonan: 'SURAT PERMOHONAN',
    tugas: 'SURAT TUGAS',
    internal: 'NOTA DINAS / SURAT INTERNAL',
  };

  const agenda = meeting.title || meeting.activityName || '[Agenda Kegiatan — Belum Diisi]';
  const tindakLanjutLines =
    meeting.actionItems.length > 0
      ? meeting.actionItems.map(
          (a, i) =>
            `${i + 1}. ${a.task} — PIC: ${a.pic || '[Belum ditentukan]'} — Tenggat: ${a.deadline || '[Belum ditentukan]'}`
        )
      : ['1. [Tindak lanjut belum diisi]'];

  return [
    '[KOP INSTANSI / ORGANISASI — BELUM DIISI]',
    '',
    `Nomor   : [Nomor Surat — Belum Diisi]`,
    `Lampiran: -`,
    `Perihal : ${kindLabels[kind]} — ${agenda}`,
    '',
    `Yth. [Nama / Jabatan Penerima — Belum Diisi]`,
    `di Tempat`,
    '',
    'Dengan hormat,',
    kind === 'undangan'
      ? `Sehubungan dengan agenda "${agenda}", kami mengundang Bapak/Ibu untuk hadir pada kegiatan yang direncanakan pada ${meeting.date || '[Tanggal Belum Diisi]'} pukul ${meeting.startTime || '[Waktu Belum Diisi]'} bertempat di ${meeting.location || '[Lokasi Belum Diisi]'}.`
      : `Menindaklanjuti kegiatan "${agenda}" yang telah dilaksanakan pada ${meeting.date || '[Tanggal Belum Diisi]'} di ${meeting.location || '[Lokasi Belum Diisi]'}, bersama ini kami sampaikan catatan dan tindak lanjut sebagai berikut:`,
    '',
    ...tindakLanjutLines,
    '',
    'Demikian disampaikan untuk menjadi perhatian dan ditindaklanjuti sebagaimana mestinya.',
    '',
    `${meeting.location || '[Kota]'}, ${meeting.date || '[Tanggal]'}`,
    '[Jabatan Penandatangan — Belum Diisi]',
    '',
    '',
    '[Nama Pejabat & Tanda Tangan — Belum Diisi]',
    '',
    'Catatan: Draf template lokal. Nomor surat, nama pejabat, dan tanda tangan tidak dibuat otomatis.',
  ].join('\n');
}

export function generateTemplatePresentation(meeting: MeetingRecord): PresentationSlide[] {
  const title = meeting.title || 'Rapat Tanpa Judul';
  return [
    {
      slideNumber: 1,
      title,
      bullets: [
        `Kategori: ${meeting.category}`,
        `Tanggal: ${meeting.date || 'Belum diisi'}`,
        `Lokasi: ${meeting.location || 'Belum diisi'}`,
      ],
    },
    {
      slideNumber: 2,
      title: 'Agenda & Latar Belakang',
      bullets: [
        meeting.activityName || title,
        meeting.notes.trim() || 'Catatan agenda belum diisi',
      ],
    },
    {
      slideNumber: 3,
      title: 'Pokok Pembahasan',
      bullets:
        meeting.transcriptSegments.length > 0
          ? meeting.transcriptSegments.slice(0, 4).map((s) => `${s.speaker}: ${s.text}`)
          : ['Belum ada poin pembahasan dari transkrip'],
    },
    {
      slideNumber: 4,
      title: 'Keputusan & Kesepakatan',
      bullets:
        meeting.decisions.length > 0
          ? meeting.decisions.map((d) => d.decision)
          : ['Belum ditemukan keputusan yang dinyatakan secara jelas.'],
    },
    {
      slideNumber: 5,
      title: 'Rencana Tindak Lanjut',
      bullets:
        meeting.actionItems.length > 0
          ? meeting.actionItems.map(
              (a) => `${a.task} (${a.pic || 'PIC belum ditentukan'} · ${a.deadline || 'Tenggat belum ditentukan'})`
            )
          : ['Belum ada tindak lanjut yang dicatat'],
    },
  ];
}

export function searchTranscriptLocal(
  meeting: MeetingRecord,
  query: string
): TranscriptSegment[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const tokens = q.split(/\s+/).filter(Boolean);
  return meeting.transcriptSegments.filter((seg) => {
    const hay = `${seg.speaker} ${seg.text} ${seg.note || ''}`.toLowerCase();
    return tokens.every((t) => hay.includes(t));
  });
}

export function searchAllMeetings(
  meetings: MeetingRecord[],
  query: string,
  categoryFilter: string
): MeetingRecord[] {
  const q = query.trim().toLowerCase();
  return meetings.filter((m) => {
    if (categoryFilter && categoryFilter !== 'Semua' && m.category !== categoryFilter) {
      return false;
    }
    if (!q) return true;

    const transcriptText = m.transcriptSegments.map((s) => `${s.speaker} ${s.text}`).join(' ');
    const notulenText = m.notulen
      ? [
          m.notulen.tujuanRapat,
          m.notulen.ringkasanPembahasan,
          m.notulen.pokokPembahasan.join(' '),
          m.notulen.keputusanDanKesepakatan.join(' '),
          m.notulen.kesimpulan,
        ].join(' ')
      : '';
    const decisionsText = m.decisions.map((d) => `${d.decision} ${d.notes}`).join(' ');
    const actionsText = m.actionItems
      .map((a) => `${a.task} ${a.pic} ${a.deadline} ${a.status}`)
      .join(' ');

    const haystack = [
      m.title,
      m.activityName,
      m.category,
      m.location,
      m.notes,
      m.summaryText,
      transcriptText,
      notulenText,
      decisionsText,
      actionsText,
    ]
      .join(' ')
      .toLowerCase();

    return haystack.includes(q);
  });
}

export function buildGoogleSheetsCsvPack(meeting: MeetingRecord): {
  sheet1Info: string[][];
  sheet2Actions: string[][];
  sheet3Decisions: string[][];
  sheet4Topics: string[][];
} {
  const info = meeting.notulen?.informasiKegiatan;
  const sheet1Info: string[][] = [
    ['Field', 'Nilai'],
    ['Judul Rapat', meeting.title || 'Belum diisi'],
    ['Nama Kegiatan', info?.namaKegiatan || meeting.activityName || 'Belum diisi'],
    ['Kategori', meeting.category || 'Lainnya'],
    ['Tanggal', info?.tanggal || meeting.date || 'Belum diisi'],
    ['Waktu', info?.waktu || meeting.startTime || 'Belum diisi'],
    ['Lokasi', info?.lokasi || meeting.location || 'Belum diisi'],
    ['Durasi', formatDurationHMS(meeting.durationSeconds)],
    ['Pimpinan', info?.pimpinan || 'Belum diisi'],
    ['Notulis', info?.notulis || 'Belum diisi'],
    ['Peserta', info?.peserta || 'Belum diisi'],
  ];

  const sheet2Actions: string[][] = [
    ['No', 'Tugas / Tindak Lanjut', 'PIC', 'Tenggat', 'Status'],
    ...(meeting.actionItems.length > 0
      ? meeting.actionItems.map((a, i) => [
          String(i + 1),
          a.task || 'Belum diisi',
          a.pic || 'Belum ditentukan',
          a.deadline || 'Belum ditentukan',
          a.status,
        ])
      : [['1', 'Belum ada tindak lanjut', '-', '-', 'Belum Dimulai']]),
  ];

  const sheet3Decisions: string[][] = [
    ['No', 'Keputusan', 'Keterangan'],
    ...(meeting.decisions.length > 0
      ? meeting.decisions.map((d, i) => [
          String(i + 1),
          d.decision,
          d.notes || '-',
        ])
      : [['1', 'Belum ditemukan keputusan yang dinyatakan secara jelas.', '-']]),
  ];

  const topics: DiscussionTopic[] =
    meeting.discussionTopics.length > 0
      ? meeting.discussionTopics
      : (meeting.notulen?.pokokPembahasan || []).map((p, idx) => ({
          id: `topic_${idx}`,
          topic: `Pokok ${idx + 1}`,
          summary: p,
        }));

  const sheet4Topics: string[][] = [
    ['No', 'Topik', 'Ringkasan'],
    ...(topics.length > 0
      ? topics.map((t, i) => [String(i + 1), t.topic, t.summary])
      : [['1', 'Pembahasan Umum', meeting.summaryText || 'Belum ada ringkasan pembahasan.']]),
  ];

  return {
    sheet1Info,
    sheet2Actions,
    sheet3Decisions,
    sheet4Topics,
  };
}

export function validateBackupPayload(
  raw: unknown
): { valid: true; payload: BackupPayload } | { valid: false; error: string } {
  if (!raw || typeof raw !== 'object') {
    return { valid: false, error: 'File backup bukan objek JSON yang valid.' };
  }
  const obj = raw as Record<string, unknown>;
  if (typeof obj.schemaVersion !== 'number' || obj.schemaVersion < 1) {
    return { valid: false, error: 'Versi skema backup tidak dikenali atau hilang.' };
  }
  if (!Array.isArray(obj.meetings)) {
    return { valid: false, error: 'Struktur daftar rapat ("meetings") tidak ditemukan.' };
  }
  for (let i = 0; i < obj.meetings.length; i += 1) {
    const m = obj.meetings[i] as Record<string, unknown>;
    if (!m || typeof m.id !== 'string' || typeof m.title !== 'string') {
      return {
        valid: false,
        error: `Data rapat pada indeks ke-${i + 1} tidak memiliki id atau judul yang valid.`,
      };
    }
    if (!Array.isArray(m.transcriptSegments)) {
      return {
        valid: false,
        error: `Data transkrip pada rapat "${m.title}" tidak valid.`,
      };
    }
  }

  const safeSettings = {
    ...DEFAULT_SETTINGS,
    ...(obj.settings && typeof obj.settings === 'object' ? obj.settings : {}),
  };

  return {
    valid: true,
    payload: {
      schemaVersion: obj.schemaVersion,
      appName: typeof obj.appName === 'string' ? obj.appName : 'Smart Voice Meeting Notes AI',
      exportedAt: typeof obj.exportedAt === 'string' ? obj.exportedAt : new Date().toISOString(),
      includesAudio: Boolean(obj.includesAudio),
      settings: safeSettings,
      meetings: obj.meetings as MeetingRecord[],
      audioFiles: Array.isArray(obj.audioFiles)
        ? (obj.audioFiles as BackupPayload['audioFiles'])
        : undefined,
    },
  };
}

export function createSampleDemoMeeting(): MeetingRecord {
  const now = new Date();
  const dateStr = now.toISOString().slice(0, 10);
  const startStr = '09:00';
  const id = generateId('demo');

  const segments: TranscriptSegment[] = [
    {
      id: generateId('seg'),
      timestampSeconds: 12,
      speaker: 'Pembicara 1',
      text: 'Selamat pagi Bapak dan Ibu, kita mulai rapat koordinasi pendampingan digitalisasi sekolah hari ini.',
      isImportant: false,
    },
    {
      id: generateId('seg'),
      timestampSeconds: 48,
      speaker: 'Pembicara 2',
      text: 'Prioritas bulan ini adalah memastikan inventarisasi akun belajar dan penataan arsip notulen rapat berjalan rapi di setiap unit.',
      isImportant: true,
    },
    {
      id: generateId('seg'),
      timestampSeconds: 115,
      speaker: 'Pembicara 1',
      text: 'Baik, kita sepakati bersama bahwa seluruh tim mulai mendokumentasikan rapat menggunakan template notulen standar mulai minggu depan.',
      isImportant: true,
    },
    {
      id: generateId('seg'),
      timestampSeconds: 174,
      speaker: 'Pembicara 2',
      text: 'Untuk jadwal pendampingan teknis gelombang kedua masih menunggu konfirmasi jadwal kepala sekolah.',
      isUnclear: true,
      note: 'Perlu konfirmasi tanggal pasti dari bagian tata usaha.',
    },
  ];

  const decisions: DecisionItem[] = [
    {
      id: generateId('dec'),
      decision: 'Seluruh tim mulai mendokumentasikan rapat dengan format notulen standar mulai minggu depan.',
      notes: 'Disepakati pada menit 00:01:55.',
    },
  ];

  const actionItems: ActionItem[] = [
    {
      id: generateId('act'),
      task: 'Inventarisasi akun digital dan kesiapan arsip unit sekolah',
      pic: 'Tim Pendampingan',
      deadline: 'Akhir bulan ini',
      status: 'Proses',
    },
    {
      id: generateId('act'),
      task: 'Konfirmasi jadwal pendampingan teknis gelombang kedua',
      pic: 'Belum ditentukan',
      deadline: 'Belum ditentukan',
      status: 'Belum Dimulai',
    },
  ];

  const record: MeetingRecord = {
    id,
    title: 'Contoh Rapat Koordinasi Digitalisasi Sekolah',
    activityName: 'Pendampingan Digitalisasi & Tata Kelola Arsip',
    category: 'Pendampingan Digitalisasi',
    date: dateStr,
    startTime: startStr,
    location: 'Ruang Rapat Utama (Data Contoh Lokal)',
    notes: 'Contoh data rapat lokal untuk menguji transkrip, notulen, pencarian, ekspor DOCX/CSV, dan asisten rapat tanpa mikrofon.',
    durationSeconds: 215,
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
    recordingState: 'manual_entry',
    transcriptionStatus: 'manual',
    documentStatus: 'template_lokal',
    hasAudio: false,
    audioMimeType: '',
    audioByteSize: 0,
    audioChunkCount: 0,
    transcriptSegments: segments,
    notulen: null,
    summaryText:
      'Rapat koordinasi membahas prioritas inventarisasi akun belajar, penataan arsip notulen rapat standar, serta penjadwalan pendampingan teknis gelombang kedua.',
    decisions,
    actionItems,
    discussionTopics: [
      {
        id: generateId('top'),
        topic: 'Standardisasi Arsip Notulen',
        summary: 'Penerapan format notulen standar untuk seluruh unit mulai minggu depan.',
      },
      {
        id: generateId('top'),
        topic: 'Jadwal Pendampingan Gelombang Kedua',
        summary: 'Menunggu konfirmasi jadwal resmi dari kepala sekolah dan tata usaha.',
      },
    ],
    reportOutput: null,
    letterKind: 'tindak_lanjut',
    letterOutput: '',
    ideasOutput: [
      'Menyusun panduan ringkas 1 halaman penggunaan perekam rapat untuk operator sekolah.',
      'Menjadwalkan uji coba ekspor laporan bulanan dalam format DOCX dan CSV.',
    ],
    presentationOutline: [],
  };

  record.notulen = generateTemplateNotulen(record);
  record.reportOutput = generateTemplateReport(record);
  record.presentationOutline = generateTemplatePresentation(record);
  record.letterOutput = generateTemplateLetter(record, 'tindak_lanjut');

  return record;
}
