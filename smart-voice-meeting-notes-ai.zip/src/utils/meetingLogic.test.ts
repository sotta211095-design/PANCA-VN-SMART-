import test from 'node:test';
import assert from 'node:assert/strict';
import { formatDurationHMS, formatFileSize, sanitizeFilename } from './formatters';
import {
  buildGoogleSheetsCsvPack,
  createSampleDemoMeeting,
  formatNotulenMarkdownText,
  formatTranscriptText,
  generateTemplateNotulen,
  parseTranscriptLines,
  searchAllMeetings,
  searchTranscriptLocal,
  validateBackupPayload,
} from './meetingLogic';

test('formatDurationHMS formats seconds into HH:MM:SS', () => {
  assert.equal(formatDurationHMS(0), '00:00:00');
  assert.equal(formatDurationHMS(12), '00:00:12');
  assert.equal(formatDurationHMS(3665), '01:01:05');
});

test('formatFileSize and sanitizeFilename behave deterministically', () => {
  assert.equal(formatFileSize(0), '0 B');
  assert.equal(formatFileSize(1536), '1.5 KB');
  assert.equal(sanitizeFilename('Rapat Koordinasi #1!'), 'rapat-koordinasi-1');
});

test('formatTranscriptText omits timestamp when null and preserves real timestamps', () => {
  const formatted = formatTranscriptText([
    { id: '1', timestampSeconds: 12, speaker: 'Pembicara 1', text: 'Selamat pagi.' },
    { id: '2', timestampSeconds: null, speaker: 'Pembicara 2', text: 'Tanpa timestamp.', isImportant: true },
  ]);
  assert.equal(
    formatted,
    '[00:00:12] Pembicara 1: Selamat pagi.\nPembicara 2: [PENTING] Tanpa timestamp.'
  );
});

test('parseTranscriptLines round-trips timestamps, speakers, and markers', () => {
  const raw = '[00:01:05] Pembicara 2: [PENTING] Target minggu depan.\nPembicara 1: [TIDAK JELAS] Suara pelan.';
  const parsed = parseTranscriptLines(raw);
  assert.equal(parsed.length, 2);
  assert.equal(parsed[0].timestampSeconds, 65);
  assert.equal(parsed[0].speaker, 'Pembicara 2');
  assert.equal(parsed[0].isImportant, true);
  assert.equal(parsed[0].text, 'Target minggu depan.');
  assert.equal(parsed[1].timestampSeconds, null);
  assert.equal(parsed[1].isUnclear, true);
});

test('generateTemplateNotulen never fabricates missing fields or decisions', () => {
  const demo = createSampleDemoMeeting();
  demo.decisions = [];
  demo.location = '';
  const notulen = generateTemplateNotulen(demo);
  assert.equal(notulen.source, 'template');
  assert.equal(notulen.informasiKegiatan.lokasi, 'Belum diisi');
  assert.equal(
    notulen.keputusanDanKesepakatan[0],
    'Belum ditemukan keputusan yang dinyatakan secara jelas.'
  );
  const text = formatNotulenMarkdownText(notulen, demo.actionItems);
  assert.ok(text.includes('NOTULEN RAPAT'));
  assert.ok(text.includes('I. Catatan Penyusunan'));
});

test('searchTranscriptLocal and searchAllMeetings find matching records accurately', () => {
  const demo = createSampleDemoMeeting();
  const hits = searchTranscriptLocal(demo, 'inventarisasi');
  assert.equal(hits.length, 1);
  assert.equal(hits[0].timestampSeconds, 48);

  const meetings = searchAllMeetings([demo], 'digitalisasi', 'Pendampingan Digitalisasi');
  assert.equal(meetings.length, 1);

  const filteredOut = searchAllMeetings([demo], 'digitalisasi', 'Workshop');
  assert.equal(filteredOut.length, 0);
});

test('buildGoogleSheetsCsvPack produces 4 structured sheets', () => {
  const demo = createSampleDemoMeeting();
  const pack = buildGoogleSheetsCsvPack(demo);
  assert.equal(pack.sheet1Info[0][0], 'Field');
  assert.equal(pack.sheet2Actions[0][1], 'Tugas / Tindak Lanjut');
  assert.equal(pack.sheet3Decisions[0][1], 'Keputusan');
  assert.equal(pack.sheet4Topics[0][1], 'Topik');
});

test('validateBackupPayload rejects malformed JSON and accepts valid backup', () => {
  const invalid = validateBackupPayload({ foo: 'bar' });
  assert.equal(invalid.valid, false);

  const demo = createSampleDemoMeeting();
  const valid = validateBackupPayload({
    schemaVersion: 1,
    appName: 'Smart Voice Meeting Notes AI',
    exportedAt: new Date().toISOString(),
    includesAudio: false,
    meetings: [demo],
  });
  assert.equal(valid.valid, true);
});
