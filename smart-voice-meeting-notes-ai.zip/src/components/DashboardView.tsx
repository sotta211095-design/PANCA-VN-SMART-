import React from 'react';
import {
  ArrowRight,
  DatabaseBackup,
  FileText,
  FolderClock,
  MessageSquareText,
  Mic,
  Sparkles,
} from 'lucide-react';
import { MeetingRecord, NavigationTab } from '../types/meeting';
import { formatDateID, formatDurationHuman } from '../utils/formatters';

interface DashboardViewProps {
  meetings: MeetingRecord[];
  onNavigate: (tab: NavigationTab) => void;
  onOpenMeeting: (id: string) => void;
  onCreateDemoMeeting: () => void;
  hasAiKey: boolean;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  meetings,
  onNavigate,
  onOpenMeeting,
  onCreateDemoMeeting,
  hasAiKey,
}) => {
  const totalMeetings = meetings.length;
  const totalDurationSeconds = meetings.reduce((acc, m) => acc + (m.durationSeconds || 0), 0);
  const totalDocuments = meetings.filter(
    (m) =>
      m.notulen !== null ||
      m.summaryText.trim().length > 0 ||
      m.reportOutput !== null ||
      m.letterOutput.trim().length > 0
  ).length;
  const lastMeeting = meetings[0] || null;
  const recentMeetings = meetings.slice(0, 4);
  const recentDocuments = meetings
    .filter((m) => m.notulen !== null || m.summaryText.trim().length > 0)
    .slice(0, 3);

  return (
    <div className="space-y-8">
      {/* Primary Hero Card: REKAM RAPAT BARU */}
      <section className="relative overflow-hidden rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 dark:border-slate-800/90 dark:bg-gradient-to-br dark:from-[#131A26] dark:via-[#111927] dark:to-[#0E1722]">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-2xl space-y-3">
            <p className="text-xs font-medium tracking-wide text-emerald-600 dark:text-emerald-400">
              Smart Voice Meeting Notes AI
            </p>
            <h2 className="font-display text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl dark:text-slate-50 [text-wrap:balance]">
              Rekam Rapat Baru
            </h2>
            <p className="text-sm leading-relaxed text-slate-600 sm:text-base dark:text-slate-300">
              Rekam rapat, diskusi, pelatihan, atau pertemuan Anda. Biarkan aplikasi membantu
              menyusun dokumentasi dengan lebih rapi.
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => onNavigate('recorder')}
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-emerald-600 px-5 text-sm font-semibold text-white transition-colors hover:bg-emerald-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-500"
              >
                <Mic className="h-4 w-4" aria-hidden="true" />
                <span>Mulai Rekam</span>
              </button>
              {totalMeetings === 0 && (
                <button
                  type="button"
                  onClick={onCreateDemoMeeting}
                  className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-300 bg-slate-50 px-4 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  <FileText className="h-4 w-4" aria-hidden="true" />
                  <span>Muat Contoh Rapat (Demo)</span>
                </button>
              )}
            </div>
          </div>

          <div className="flex flex-col gap-2 border-t border-slate-200/80 pt-4 text-xs text-slate-600 lg:w-72 lg:border-t-0 lg:border-l lg:border-slate-200/80 lg:pt-0 lg:pl-6 dark:border-slate-800 dark:text-slate-300">
            <span className="font-semibold text-slate-900 dark:text-slate-100">
              Status Penyimpanan &amp; AI
            </span>
            <p className="leading-relaxed">
              Semua rekaman audio dan catatan disimpan lokal di IndexedDB browser Anda tanpa
              memerlukan server atau langganan.
            </p>
            <p className="pt-1 text-slate-500 dark:text-slate-400">
              Gemini AI:{' '}
              <span className={hasAiKey ? 'text-emerald-600 dark:text-emerald-400 font-medium' : ''}>
                {hasAiKey ? 'Terhubung di sesi ini' : 'Opsional (belum diisi)'}
              </span>
            </p>
          </div>
        </div>
      </section>

      {/* Real Metrics Row */}
      <section aria-label="Statistik rapat lokal">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800/90 dark:bg-[#131A26]/85">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Rapat</p>
            <p className="mt-2 font-display text-2xl font-bold tabular-nums text-slate-900 dark:text-slate-50">
              {totalMeetings}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Tersimpan di perangkat
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800/90 dark:bg-[#131A26]/85">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Durasi</p>
            <p className="mt-2 font-display text-2xl font-bold tabular-nums text-slate-900 dark:text-slate-50">
              {formatDurationHuman(totalDurationSeconds)}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Akumulasi rekaman
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800/90 dark:bg-[#131A26]/85">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Dokumen</p>
            <p className="mt-2 font-display text-2xl font-bold tabular-nums text-slate-900 dark:text-slate-50">
              {totalDocuments}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Notulen & ringkasan
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800/90 dark:bg-[#131A26]/85">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Rapat Terakhir</p>
            <p className="mt-2 truncate font-display text-base font-semibold text-slate-900 dark:text-slate-50">
              {lastMeeting ? lastMeeting.title : 'Belum ada'}
            </p>
            <p className="mt-1 truncate text-xs text-slate-500 dark:text-slate-400">
              {lastMeeting ? formatDateID(lastMeeting.date) : 'Mulai rekam rapat pertama'}
            </p>
          </div>
        </div>
      </section>

      {/* Two-column Workspace Cards: Riwayat & Dokumen Terakhir */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Riwayat Rapat */}
        <section className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800/90 dark:bg-[#131A26]/85">
          <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2.5">
              <FolderClock className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
              <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Riwayat Rapat Terbaru
              </h3>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('history')}
              className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 hover:text-emerald-500 dark:text-emerald-400"
            >
              <span>Lihat semua</span>
              <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
            </button>
          </div>

          {recentMeetings.length === 0 ? (
            <div className="py-10 text-center">
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                Belum ada rapat tersimpan
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Tekan &ldquo;Mulai Rekam&rdquo; untuk merekam rapat atau muat contoh rapat untuk mencoba fitur.
              </p>
            </div>
          ) : (
            <ul className="divide-y divide-slate-100 dark:divide-slate-800/80">
              {recentMeetings.map((m) => (
                <li key={m.id}>
                  <button
                    type="button"
                    onClick={() => onOpenMeeting(m.id)}
                    className="flex w-full items-center justify-between gap-4 py-3.5 text-left transition-colors hover:bg-slate-50/80 dark:hover:bg-slate-800/30 rounded-lg px-2 -mx-2"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-slate-900 dark:text-slate-100">
                        {m.title}
                      </p>
                      <p className="mt-0.5 truncate text-xs text-slate-500 dark:text-slate-400">
                        {m.category} · {formatDateID(m.date)} ·{' '}
                        <span className="tabular-nums">{formatDurationHuman(m.durationSeconds)}</span>
                      </p>
                    </div>
                    <ArrowRight className="h-4 w-4 shrink-0 text-slate-400" aria-hidden="true" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Dokumen Terakhir */}
        <section className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800/90 dark:bg-[#131A26]/85">
          <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2.5">
              <FileText className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
              <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Dokumen Terakhir
              </h3>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('history')}
              className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 hover:text-emerald-500 dark:text-emerald-400"
            >
              <span>Kelola dokumen</span>
              <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
            </button>
          </div>

          {recentDocuments.length === 0 ? (
            <div className="py-10 text-center">
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                Belum ada notulen atau ringkasan
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Buka rapat yang tersimpan lalu klik &ldquo;Generate Notulen&rdquo; untuk menyusun dokumen.
              </p>
            </div>
          ) : (
            <ul className="divide-y divide-slate-100 dark:divide-slate-800/80">
              {recentDocuments.map((m) => (
                <li key={m.id}>
                  <button
                    type="button"
                    onClick={() => onOpenMeeting(m.id)}
                    className="flex w-full items-center justify-between gap-4 py-3.5 text-left transition-colors hover:bg-slate-50/80 dark:hover:bg-slate-800/30 rounded-lg px-2 -mx-2"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-slate-900 dark:text-slate-100">
                        Notulen — {m.title}
                      </p>
                      <p className="mt-0.5 truncate text-xs text-slate-500 dark:text-slate-400">
                        {m.documentStatus === 'ai_draft'
                          ? 'Draf Gemini AI'
                          : 'Template Lokal'}{' '}
                        · {m.actionItems.length} tindak lanjut · {m.decisions.length} keputusan
                      </p>
                    </div>
                    <ArrowRight className="h-4 w-4 shrink-0 text-slate-400" aria-hidden="true" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* Bottom Action Row: AI Meeting Assistant & Backup Data */}
      <div className="grid gap-6 md:grid-cols-2">
        <section className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800/90 dark:bg-[#131A26]/85">
          <div>
            <div className="flex items-center gap-2.5">
              <MessageSquareText className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
              <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                AI Meeting Assistant
              </h3>
            </div>
            <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400">
              Tanyakan poin penting, keputusan, PIC, atau cari kutipan spesifik dari transkrip
              rapat. Tersedia pencarian lokal meski tanpa API Key.
            </p>
          </div>
          <div className="mt-5 flex items-center justify-between gap-4">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {hasAiKey ? 'Siap menjawab dengan Gemini AI' : 'Mode Pencarian Transkrip Lokal'}
            </span>
            <button
              type="button"
              onClick={() => onNavigate('assistant')}
              className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-slate-100 px-4 text-xs font-semibold text-slate-800 hover:bg-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
            >
              <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Buka Asisten</span>
            </button>
          </div>
        </section>

        <section className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800/90 dark:bg-[#131A26]/85">
          <div>
            <div className="flex items-center gap-2.5">
              <DatabaseBackup className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
              <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Backup & Pemulihan Data
              </h3>
            </div>
            <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400">
              Data lokal tidak otomatis tersinkron antarperangkat. Unduh file backup JSON (dengan
              atau tanpa audio) agar arsip rapat Anda selalu aman.
            </p>
          </div>
          <div className="mt-5 flex items-center justify-between gap-4">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Format JSON tervalidasi
            </span>
            <button
              type="button"
              onClick={() => onNavigate('settings')}
              className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-slate-100 px-4 text-xs font-semibold text-slate-800 hover:bg-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
            >
              <DatabaseBackup className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Kelola Backup</span>
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};
