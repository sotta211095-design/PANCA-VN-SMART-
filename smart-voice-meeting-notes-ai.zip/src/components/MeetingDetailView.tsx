import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Check,
  Copy,
  Download,
  ExternalLink,
  FileSpreadsheet,
  FileText,
  Flag,
  HelpCircle,
  Plus,
  Printer,
  RefreshCw,
  Search,
  Sparkles,
  Trash2,
  Volume2,
} from 'lucide-react';
import {
  ActionItem,
  AppSettings,
  DecisionItem,
  LetterKind,
  MeetingRecord,
  NotulenData,
  TranscriptSegment,
} from '../types/meeting';
import { formatDateID, formatDurationHMS, formatFileSize, generateId } from '../utils/formatters';
import {
  formatNotulenMarkdownText,
  formatTranscriptText,
  generateTemplateLetter,
  generateTemplateNotulen,
  generateTemplatePresentation,
  generateTemplateReport,
  generateTemplateSummary,
  parseTranscriptLines,
} from '../utils/meetingLogic';
import {
  assembleMeetingAudio,
  deleteAudioChunksForMeeting,
  getAudioChunksForMeeting,
} from '../services/storage';
import {
  generateNotulenWithGemini,
  generateOtherAiOutput,
  transcribeAudioChunksWithGemini,
} from '../services/geminiClient';
import {
  exportAsCSV,
  exportAsDOCX,
  exportAsHTML,
  exportAsPrintPDF,
  exportAsTXT,
} from '../services/exportService';
import {
  hasGoogleSessionToken,
  saveMeetingToGoogleDocs,
  saveMeetingToGoogleSheets,
} from '../services/googleIntegration';

interface MeetingDetailViewProps {
  meeting: MeetingRecord;
  settings: AppSettings;
  hasAiKey: boolean;
  onUpdateMeeting: (updated: MeetingRecord) => Promise<void>;
  onBack: () => void;
  onAskAssistant: (meetingId: string) => void;
  onToast: (type: 'info' | 'success' | 'warning' | 'error', title: string, desc?: string) => void;
}

type DetailSubTab = 'transcript' | 'notulen' | 'outputs' | 'export';
type OutputKindTab =
  | 'ringkasan'
  | 'keputusan'
  | 'tindak_lanjut'
  | 'laporan'
  | 'surat'
  | 'ide'
  | 'presentasi';

export const MeetingDetailView: React.FC<MeetingDetailViewProps> = ({
  meeting,
  settings,
  hasAiKey,
  onUpdateMeeting,
  onBack,
  onAskAssistant,
  onToast,
}) => {
  const [subTab, setSubTab] = useState<DetailSubTab>('transcript');
  const [outputTab, setOutputTab] = useState<OutputKindTab>('ringkasan');
  const [saveState, setSaveState] = useState<'saved' | 'saving' | 'error'>('saved');

  // Audio playback URL
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioLoadError, setAudioLoadError] = useState<string | null>(null);

  // Transcript editor states
  const [transcriptSearch, setTranscriptSearch] = useState('');
  const [rawEditMode, setRawEditMode] = useState(false);
  const [rawTranscriptDraft, setRawTranscriptDraft] = useState('');
  const [copied, setCopied] = useState(false);

  // AI Transcription progress
  const [isTranscribingAI, setIsTranscribingAI] = useState(false);
  const [transcribeProgress, setTranscribeProgress] = useState<{
    done: number;
    total: number;
    failed: number[];
  } | null>(null);

  // AI / Template generation loading states
  const [isGeneratingNotulen, setIsGeneratingNotulen] = useState(false);
  const [isGeneratingOutput, setIsGeneratingOutput] = useState(false);
  const [isExportingGoogle, setIsExportingGoogle] = useState<'docs' | 'sheets' | null>(null);

  const autosaveTimerRef = useRef<number | null>(null);

  useEffect(() => {
    setRawTranscriptDraft(formatTranscriptText(meeting.transcriptSegments));
  }, [meeting.id]);

  useEffect(() => {
    let activeUrl: string | null = null;
    let cancelled = false;

    const loadAudio = async () => {
      setAudioUrl(null);
      setAudioLoadError(null);
      if (!meeting.hasAudio) return;
      try {
        const assembled = await assembleMeetingAudio(meeting.id, meeting.audioMimeType);
        if (cancelled) return;
        if (assembled.blob && assembled.byteSize > 0) {
          activeUrl = URL.createObjectURL(assembled.blob);
          setAudioUrl(activeUrl);
        } else {
          setAudioLoadError('File audio tidak ditemukan di penyimpanan lokal.');
        }
      } catch (err) {
        if (!cancelled) {
          setAudioLoadError(
            err instanceof Error ? err.message : 'Gagal memuat audio dari IndexedDB.'
          );
        }
      }
    };

    loadAudio();

    return () => {
      cancelled = true;
      if (activeUrl) URL.revokeObjectURL(activeUrl);
    };
  }, [meeting.id, meeting.hasAudio, meeting.audioMimeType]);

  const scheduleAutosave = (updated: MeetingRecord) => {
    setSaveState('saving');
    if (autosaveTimerRef.current !== null) {
      clearTimeout(autosaveTimerRef.current);
    }
    autosaveTimerRef.current = window.setTimeout(async () => {
      try {
        await onUpdateMeeting(updated);
        setSaveState('saved');
      } catch (err) {
        setSaveState('error');
        onToast(
          'error',
          'Autosave gagal',
          err instanceof Error ? err.message : 'Gagal menyimpan perubahan ke IndexedDB.'
        );
      }
    }, 350);
  };

  const updateSegmentsAndSave = (
    segments: TranscriptSegment[],
    newStatus?: MeetingRecord['transcriptionStatus']
  ) => {
    const updated: MeetingRecord = {
      ...meeting,
      transcriptSegments: segments,
      transcriptionStatus:
        newStatus ||
        (segments.length > 0 && meeting.transcriptionStatus === 'belum_ada'
          ? 'manual'
          : meeting.transcriptionStatus),
    };
    setRawTranscriptDraft(formatTranscriptText(segments));
    scheduleAutosave(updated);
  };

  const filteredSegments = useMemo(() => {
    const q = transcriptSearch.trim().toLowerCase();
    if (!q) return meeting.transcriptSegments;
    return meeting.transcriptSegments.filter(
      (s) =>
        s.text.toLowerCase().includes(q) ||
        s.speaker.toLowerCase().includes(q) ||
        (s.note && s.note.toLowerCase().includes(q))
    );
  }, [meeting.transcriptSegments, transcriptSearch]);

  const handleDeleteAudioOnly = async () => {
    try {
      await deleteAudioChunksForMeeting(meeting.id);
      if (audioUrl) URL.revokeObjectURL(audioUrl);
      setAudioUrl(null);
      await onUpdateMeeting({
        ...meeting,
        hasAudio: false,
        audioByteSize: 0,
        audioChunkCount: 0,
      });
      onToast('success', 'Audio rekaman dihapus', 'Transkrip dan dokumen rapat tetap tersimpan.');
    } catch (err) {
      onToast(
        'error',
        'Gagal menghapus audio',
        err instanceof Error ? err.message : 'Kesalahan IndexedDB.'
      );
    }
  };

  const handleTranscribeAudioWithGemini = async () => {
    if (!hasAiKey) {
      onToast('warning', 'API Key Gemini belum diatur', 'Masukkan API Key di menu Pengaturan.');
      return;
    }
    setIsTranscribingAI(true);
    setTranscribeProgress({ done: 0, total: 1, failed: [] });

    try {
      const chunks = await getAudioChunksForMeeting(meeting.id);
      if (chunks.length === 0) {
        throw new Error('Potongan audio tidak ditemukan di IndexedDB.');
      }

      const result = await transcribeAudioChunksWithGemini({
        chunks,
        language: settings.speechLanguage,
        onProgress: (p) => {
          setTranscribeProgress({
            done: p.completedSegments,
            total: p.totalSegments,
            failed: p.failedSegments,
          });
        },
      });

      const updated: MeetingRecord = {
        ...meeting,
        transcriptSegments: result.segments,
        transcriptionStatus: result.isComplete ? 'ai_selesai' : 'ai_sebagian',
      };

      await onUpdateMeeting(updated);
      setRawTranscriptDraft(formatTranscriptText(result.segments));

      if (result.isComplete) {
        if (settings.autoDeleteAudioAfterTranscript) {
          await deleteAudioChunksForMeeting(meeting.id);
          await onUpdateMeeting({
            ...updated,
            hasAudio: false,
            audioByteSize: 0,
            audioChunkCount: 0,
          });
          onToast(
            'success',
            'Transkripsi AI selesai & audio dihapus',
            'Sesuai pengaturan privasi hapus audio otomatis.'
          );
        } else {
          onToast('success', 'Transkripsi Gemini AI selesai');
        }
      } else {
        onToast(
          'warning',
          'Transkripsi selesai sebagian',
          `Segmen gagal: ${result.failedIndexes.join(', ')}. Periksa kuota/koneksi lalu coba ulang.`
        );
      }
    } catch (err) {
      onToast(
        'error',
        'Transkripsi AI gagal',
        err instanceof Error ? err.message : 'Kesalahan layanan Gemini AI.'
      );
    } finally {
      setIsTranscribingAI(false);
    }
  };

  const handleGenerateNotulen = async () => {
    setIsGeneratingNotulen(true);
    try {
      if (hasAiKey && meeting.transcriptSegments.length > 0) {
        const res = await generateNotulenWithGemini(meeting, settings.geminiModel);
        await onUpdateMeeting({
          ...meeting,
          notulen: res.notulen,
          decisions: res.decisions.length > 0 ? res.decisions : meeting.decisions,
          actionItems: res.actionItems.length > 0 ? res.actionItems : meeting.actionItems,
          discussionTopics:
            res.discussionTopics.length > 0 ? res.discussionTopics : meeting.discussionTopics,
          summaryText: res.summaryText || meeting.summaryText,
          documentStatus: 'ai_draft',
        });
        onToast('success', 'Notulen AI berhasil disusun', 'Silakan periksa kembali isi dokumen.');
      } else {
        const template = generateTemplateNotulen(meeting);
        await onUpdateMeeting({
          ...meeting,
          notulen: template,
          documentStatus: 'template_lokal',
        });
        onToast(
          'info',
          'Template Notulen Lokal dibuat',
          hasAiKey
            ? 'Transkrip masih kosong, dibuat template editable.'
            : 'API Key belum diisi — dibuat draf template lokal non-AI.'
        );
      }
    } catch (err) {
      onToast(
        'error',
        'Gagal menyusun notulen AI',
        err instanceof Error ? err.message : 'Kesalahan layanan AI.'
      );
    } finally {
      setIsGeneratingNotulen(false);
    }
  };

  const handleGenerateOtherOutput = async (kind: 'ringkasan' | 'laporan' | 'surat' | 'ide' | 'presentasi') => {
    setIsGeneratingOutput(true);
    try {
      if (hasAiKey && meeting.transcriptSegments.length > 0) {
        const res = await generateOtherAiOutput({
          meeting,
          kind,
          letterKind: meeting.letterKind,
          model: settings.geminiModel,
        });
        if (res.kind === 'ringkasan') {
          await onUpdateMeeting({ ...meeting, summaryText: res.summaryText, documentStatus: 'ai_draft' });
        } else if (res.kind === 'laporan') {
          await onUpdateMeeting({ ...meeting, reportOutput: res.report, documentStatus: 'ai_draft' });
        } else if (res.kind === 'surat') {
          await onUpdateMeeting({ ...meeting, letterOutput: res.letter, documentStatus: 'ai_draft' });
        } else if (res.kind === 'ide') {
          await onUpdateMeeting({ ...meeting, ideasOutput: res.ideas, documentStatus: 'ai_draft' });
        } else if (res.kind === 'presentasi') {
          await onUpdateMeeting({ ...meeting, presentationOutline: res.slides, documentStatus: 'ai_draft' });
        }
        onToast('success', `Draf ${kind} AI disusun`);
      } else {
        if (kind === 'ringkasan') {
          await onUpdateMeeting({
            ...meeting,
            summaryText: generateTemplateSummary(meeting),
            documentStatus: meeting.documentStatus === 'belum_ada' ? 'template_lokal' : meeting.documentStatus,
          });
        } else if (kind === 'laporan') {
          await onUpdateMeeting({
            ...meeting,
            reportOutput: generateTemplateReport(meeting),
            documentStatus: meeting.documentStatus === 'belum_ada' ? 'template_lokal' : meeting.documentStatus,
          });
        } else if (kind === 'surat') {
          await onUpdateMeeting({
            ...meeting,
            letterOutput: generateTemplateLetter(meeting, meeting.letterKind),
            documentStatus: meeting.documentStatus === 'belum_ada' ? 'template_lokal' : meeting.documentStatus,
          });
        } else if (kind === 'ide') {
          const highlights = meeting.transcriptSegments
            .filter((s) => s.isImportant)
            .map((s) => `Tindak lanjuti poin: ${s.text}`);
          await onUpdateMeeting({
            ...meeting,
            ideasOutput:
              highlights.length > 0
                ? highlights
                : ['Belum ada ide dari transkrip — tandai segmen [PENTING] atau isi manual.'],
          });
        } else if (kind === 'presentasi') {
          await onUpdateMeeting({
            ...meeting,
            presentationOutline: generateTemplatePresentation(meeting),
          });
        }
        onToast('info', `Template lokal ${kind} dibuat`, 'Dapat Anda sunting sesuai kebutuhan.');
      }
    } catch (err) {
      onToast(
        'error',
        `Gagal menyusun ${kind}`,
        err instanceof Error ? err.message : 'Terjadi kesalahan.'
      );
    } finally {
      setIsGeneratingOutput(false);
    }
  };

  const handleCopyTranscript = async () => {
    const text = formatTranscriptText(meeting.transcriptSegments);
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
      onToast('success', 'Transkrip disalin ke clipboard');
    } catch {
      onToast('error', 'Gagal menyalin ke clipboard');
    }
  };

  const handleGoogleDocsSave = async () => {
    setIsExportingGoogle('docs');
    try {
      const res = await saveMeetingToGoogleDocs(meeting, settings.googleClientId);
      await onUpdateMeeting({ ...meeting, googleDocsUrl: res.url });
      onToast('success', 'Tersimpan ke Google Docs', 'Tautan dokumen siap dibuka.');
    } catch (err) {
      onToast(
        'error',
        'Google Docs belum dapat digunakan',
        err instanceof Error ? err.message : 'Gunakan alternatif unduh DOCX / HTML.'
      );
    } finally {
      setIsExportingGoogle(null);
    }
  };

  const handleGoogleSheetsSave = async () => {
    setIsExportingGoogle('sheets');
    try {
      const res = await saveMeetingToGoogleSheets(meeting, settings.googleClientId);
      await onUpdateMeeting({ ...meeting, googleSheetsUrl: res.url });
      onToast('success', 'Tersimpan ke Google Sheets', '4 sheet data rapat berhasil dibuat.');
    } catch (err) {
      onToast(
        'error',
        'Google Sheets belum dapat digunakan',
        err instanceof Error ? err.message : 'Gunakan alternatif unduh CSV.'
      );
    } finally {
      setIsExportingGoogle(null);
    }
  };

  const currentNotulen: NotulenData = meeting.notulen || generateTemplateNotulen(meeting);
  const updateNotulenField = (next: NotulenData) => {
    scheduleAutosave({
      ...meeting,
      notulen: next,
      documentStatus:
        meeting.documentStatus === 'belum_ada' ? 'template_lokal' : meeting.documentStatus,
    });
  };

  const googleConnected = Boolean(settings.googleClientId.trim()) && hasGoogleSessionToken();

  return (
    <div className="space-y-6">
      {/* Header Summary Bar */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 dark:border-slate-800/90 dark:bg-[#131A26]/85">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="space-y-1.5 min-w-0">
            <button
              type="button"
              onClick={onBack}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 hover:text-emerald-500 dark:text-emerald-400"
            >
              <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Kembali ke Riwayat</span>
            </button>
            <h2 className="font-display text-xl font-bold text-slate-900 dark:text-slate-50 truncate">
              {meeting.title}
            </h2>
            <p className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500 dark:text-slate-400">
              <span>{meeting.category}</span>
              <span aria-hidden="true">·</span>
              <span>{formatDateID(meeting.date)}</span>
              {meeting.location && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{meeting.location}</span>
                </>
              )}
              <span aria-hidden="true">·</span>
              <span className="font-mono-tabular">{formatDurationHMS(meeting.durationSeconds)}</span>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {saveState === 'saving'
                ? 'Menyimpan otomatis...'
                : saveState === 'error'
                  ? 'Gagal menyimpan'
                  : 'Tersimpan di IndexedDB'}
            </span>
            <button
              type="button"
              onClick={() => onAskAssistant(meeting.id)}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <Sparkles className="h-3.5 w-3.5 text-emerald-500" aria-hidden="true" />
              <span>Tanya Rapat</span>
            </button>
          </div>
        </div>

        {/* Workspace Sub-Navigation */}
        <div
          role="tablist"
          aria-label="Bagian dokumen rapat"
          className="mt-5 flex flex-wrap gap-1.5 rounded-xl bg-slate-100 p-1 dark:bg-[#0B0F17]"
        >
          {[
            { id: 'transcript' as DetailSubTab, label: 'Audio & Transkrip' },
            { id: 'notulen' as DetailSubTab, label: 'Notulen Rapat (A–I)' },
            { id: 'outputs' as DetailSubTab, label: 'Ringkasan & Output Lain' },
            { id: 'export' as DetailSubTab, label: 'Ekspor & Google' },
          ].map((tab) => (
            <button
              key={tab.id}
              role="tab"
              type="button"
              aria-selected={subTab === tab.id}
              onClick={() => setSubTab(tab.id)}
              className={`rounded-lg px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                subTab === tab.id
                  ? 'bg-white text-slate-900 shadow-sm dark:bg-[#182233] dark:text-emerald-300'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </section>

      {/* TAB 1: AUDIO & TRANSKRIP */}
      {subTab === 'transcript' && (
        <div className="space-y-6">
          {/* Audio Player + Optional AI Transcription */}
          {meeting.hasAudio && (
            <section className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800/90 dark:bg-[#131A26]/85">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Volume2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                    <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                      Rekaman Audio Lokal ({formatFileSize(meeting.audioByteSize)})
                    </h3>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Disusun dari {meeting.audioChunkCount} potongan di IndexedDB ({meeting.audioMimeType || 'audio/webm'}).
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    disabled={isTranscribingAI}
                    onClick={handleTranscribeAudioWithGemini}
                    className="inline-flex h-10 items-center gap-2 rounded-xl bg-emerald-600 px-4 text-xs font-semibold text-white hover:bg-emerald-500 disabled:opacity-50"
                  >
                    <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>
                      {isTranscribingAI
                        ? 'Mentranskrip...'
                        : hasAiKey
                          ? 'Transkrip Audio via Gemini AI'
                          : 'Transkrip AI (Butuh API Key)'}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={handleDeleteAudioOnly}
                    className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-300 px-3.5 text-xs font-medium text-rose-600 hover:bg-rose-500/10 dark:border-slate-700 dark:text-rose-400"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Hapus Audio Saja</span>
                  </button>
                </div>
              </div>

              {audioUrl && (
                <audio controls src={audioUrl} className="mt-4 w-full" />
              )}
              {audioLoadError && (
                <p className="mt-3 text-xs text-amber-600 dark:text-amber-400">{audioLoadError}</p>
              )}

              {transcribeProgress && isTranscribingAI && (
                <div className="mt-4 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs text-emerald-800 dark:text-emerald-200">
                  Memproses segmen audio {transcribeProgress.done} dari {transcribeProgress.total}...
                </div>
              )}
            </section>
          )}

          {/* Transcript Editor */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800/90 dark:bg-[#131A26]/85">
            <div className="flex flex-col gap-3 border-b border-slate-100 pb-4 sm:flex-row sm:items-center sm:justify-between dark:border-slate-800">
              <div>
                <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  Transkrip Rapat
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Label pembicara dan timestamp hanya ditampilkan jika tersedia; dapat disunting kapan saja.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (rawEditMode) {
                      const parsed = parseTranscriptLines(rawTranscriptDraft);
                      updateSegmentsAndSave(parsed, 'manual');
                    } else {
                      setRawTranscriptDraft(formatTranscriptText(meeting.transcriptSegments));
                    }
                    setRawEditMode((v) => !v);
                  }}
                  className="rounded-xl border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  {rawEditMode ? 'Simpan & Mode Baris' : 'Mode Teks Mentah'}
                </button>
                <button
                  type="button"
                  onClick={handleCopyTranscript}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>Salin</span>
                </button>
                <button
                  type="button"
                  onClick={() => exportAsTXT(meeting, 'transcript')}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  <Download className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>TXT</span>
                </button>
              </div>
            </div>

            {!rawEditMode && (
              <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="relative flex-1">
                  <Search
                    className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                    aria-hidden="true"
                  />
                  <input
                    type="search"
                    value={transcriptSearch}
                    onChange={(e) => setTranscriptSearch(e.target.value)}
                    placeholder="Cari kata atau nama pembicara di transkrip..."
                    aria-label="Cari di transkrip"
                    className="w-full rounded-xl border border-slate-300 bg-white py-2 pl-9 pr-3 text-xs text-slate-900 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const next: TranscriptSegment[] = [
                      ...meeting.transcriptSegments,
                      {
                        id: generateId('seg'),
                        timestampSeconds: null,
                        speaker: 'Pembicara 1',
                        text: '',
                      },
                    ];
                    updateSegmentsAndSave(next, 'manual');
                  }}
                  className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-emerald-600 px-3.5 text-xs font-semibold text-white hover:bg-emerald-500"
                >
                  <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Tambah Baris Transkrip</span>
                </button>
              </div>
            )}

            {rawEditMode ? (
              <div className="mt-4">
                <textarea
                  rows={14}
                  value={rawTranscriptDraft}
                  onChange={(e) => setRawTranscriptDraft(e.target.value)}
                  placeholder="[00:00:12] Pembicara 1: Selamat pagi, kita mulai rapat hari ini."
                  aria-label="Editor transkrip teks mentah"
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 p-4 font-mono text-xs leading-relaxed text-slate-900 focus:border-emerald-500 focus:outline-none dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
                />
                <p className="mt-2 text-[11px] text-slate-500 dark:text-slate-400">
                  Klik &ldquo;Simpan &amp; Mode Baris&rdquo; untuk menerapkan perubahan ke penyimpanan lokal.
                </p>
              </div>
            ) : filteredSegments.length === 0 ? (
              <div className="py-10 text-center">
                <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                  {meeting.transcriptSegments.length === 0
                    ? 'Transkrip masih kosong'
                    : 'Tidak ada baris transkrip yang cocok'}
                </p>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  Klik &ldquo;Tambah Baris Transkrip&rdquo; untuk mengetik manual, atau gunakan
                  Gemini AI jika tersedia.
                </p>
              </div>
            ) : (
              <div className="mt-4 space-y-3">
                {filteredSegments.map((seg) => (
                  <div
                    key={seg.id}
                    className={`rounded-xl border p-3.5 ${
                      seg.isImportant
                        ? 'border-emerald-500/40 bg-emerald-500/5'
                        : seg.isUnclear
                          ? 'border-amber-500/40 bg-amber-500/5'
                          : 'border-slate-200 bg-slate-50/70 dark:border-slate-800 dark:bg-[#0B0F17]/70'
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {seg.timestampSeconds !== null && (
                          <span className="font-mono-tabular text-xs font-medium text-emerald-600 dark:text-emerald-400">
                            [{formatDurationHMS(seg.timestampSeconds)}]
                          </span>
                        )}
                        <input
                          type="text"
                          value={seg.speaker}
                          aria-label="Label pembicara"
                          onChange={(e) => {
                            const next = meeting.transcriptSegments.map((item) =>
                              item.id === seg.id ? { ...item, speaker: e.target.value } : item
                            );
                            updateSegmentsAndSave(next, 'manual');
                          }}
                          className="w-32 rounded-lg border border-slate-200 bg-white px-2 py-1 text-xs font-semibold text-slate-800 dark:border-slate-700 dark:bg-[#131A26] dark:text-slate-200"
                        />
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            const next = meeting.transcriptSegments.map((item) =>
                              item.id === seg.id ? { ...item, isImportant: !item.isImportant } : item
                            );
                            updateSegmentsAndSave(next);
                          }}
                          title="Tandai penting"
                          aria-label="Tandai baris penting"
                          className={`inline-flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium ${
                            seg.isImportant
                              ? 'bg-emerald-600 text-white'
                              : 'border border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-400'
                          }`}
                        >
                          <Flag className="h-3 w-3" aria-hidden="true" />
                          <span>Penting</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            const next = meeting.transcriptSegments.map((item) =>
                              item.id === seg.id ? { ...item, isUnclear: !item.isUnclear } : item
                            );
                            updateSegmentsAndSave(next);
                          }}
                          title="Tandai tidak jelas"
                          aria-label="Tandai bagian tidak jelas"
                          className={`inline-flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium ${
                            seg.isUnclear
                              ? 'bg-amber-600 text-white'
                              : 'border border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-400'
                          }`}
                        >
                          <HelpCircle className="h-3 w-3" aria-hidden="true" />
                          <span>Tidak Jelas</span>
                        </button>

                        <button
                          type="button"
                          aria-label="Hapus baris transkrip"
                          onClick={() => {
                            const next = meeting.transcriptSegments.filter((item) => item.id !== seg.id);
                            updateSegmentsAndSave(next);
                          }}
                          className="rounded-lg p-1 text-slate-400 hover:bg-rose-500/10 hover:text-rose-500"
                        >
                          <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                      </div>
                    </div>

                    <textarea
                      rows={2}
                      value={seg.text}
                      aria-label="Isi teks transkrip"
                      onChange={(e) => {
                        const next = meeting.transcriptSegments.map((item) =>
                          item.id === seg.id ? { ...item, text: e.target.value } : item
                        );
                        updateSegmentsAndSave(next, 'manual');
                      }}
                      placeholder="Tulis ucapan pembicara..."
                      className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-emerald-500 focus:outline-none dark:border-slate-800 dark:bg-[#131A26] dark:text-slate-100"
                    />

                    <input
                      type="text"
                      value={seg.note || ''}
                      aria-label="Catatan tambahan baris"
                      onChange={(e) => {
                        const next = meeting.transcriptSegments.map((item) =>
                          item.id === seg.id ? { ...item, note: e.target.value } : item
                        );
                        updateSegmentsAndSave(next);
                      }}
                      placeholder="Catatan koreksi / konteks tambahan (opsional)..."
                      className="mt-1.5 w-full rounded-lg border border-transparent bg-transparent px-2 py-1 text-xs text-slate-500 placeholder:text-slate-400 focus:border-slate-300 focus:bg-white focus:outline-none dark:text-slate-400 dark:focus:border-slate-700 dark:focus:bg-[#131A26]"
                    />
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}

      {/* TAB 2: NOTULEN RAPAT (A-I) */}
      {subTab === 'notulen' && (
        <section className="rounded-2xl border border-slate-200 bg-white p-6 space-y-6 dark:border-slate-800/90 dark:bg-[#131A26]/85">
          <div className="flex flex-col gap-3 border-b border-slate-100 pb-4 sm:flex-row sm:items-center sm:justify-between dark:border-slate-800">
            <div>
              <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                NOTULEN RAPAT (Format A–I)
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {meeting.notulen?.source === 'ai'
                  ? 'Disusun dengan Gemini AI — harap periksa kebenaran fakta sebelum disahkan.'
                  : 'Template lokal terstruktur — lengkapi atau gunakan Gemini AI jika tersedia.'}
              </p>
            </div>
            <button
              type="button"
              disabled={isGeneratingNotulen}
              onClick={handleGenerateNotulen}
              className="inline-flex h-10 items-center gap-2 rounded-xl bg-emerald-600 px-4 text-xs font-semibold text-white hover:bg-emerald-500 disabled:opacity-50"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isGeneratingNotulen ? 'animate-spin' : ''}`} aria-hidden="true" />
              <span>
                {isGeneratingNotulen
                  ? 'Menyusun Notulen...'
                  : hasAiKey
                    ? 'Generate Notulen (Gemini AI)'
                    : 'Generate Notulen (Template Lokal)'}
              </span>
            </button>
          </div>

          {/* A. Informasi Kegiatan */}
          <div className="space-y-3">
            <h4 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
              A. Informasi Kegiatan
            </h4>
            <div className="grid gap-3 sm:grid-cols-2">
              {(
                [
                  ['namaKegiatan', 'Nama Kegiatan'],
                  ['tanggal', 'Tanggal'],
                  ['waktu', 'Waktu'],
                  ['lokasi', 'Lokasi'],
                  ['agenda', 'Agenda'],
                  ['peserta', 'Peserta'],
                  ['pimpinan', 'Pimpinan Rapat'],
                  ['notulis', 'Notulis'],
                ] as const
              ).map(([fieldKey, label]) => (
                <div key={fieldKey}>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                    {label}
                  </label>
                  <input
                    type="text"
                    value={currentNotulen.informasiKegiatan[fieldKey]}
                    onChange={(e) =>
                      updateNotulenField({
                        ...currentNotulen,
                        informasiKegiatan: {
                          ...currentNotulen.informasiKegiatan,
                          [fieldKey]: e.target.value,
                        },
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* B. Tujuan Rapat */}
          <div>
            <label className="block font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
              B. Tujuan Rapat
            </label>
            <textarea
              rows={2}
              value={currentNotulen.tujuanRapat}
              onChange={(e) =>
                updateNotulenField({ ...currentNotulen, tujuanRapat: e.target.value })
              }
              className="mt-2 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
            />
          </div>

          {/* C. Ringkasan Pembahasan */}
          <div>
            <label className="block font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
              C. Ringkasan Pembahasan
            </label>
            <textarea
              rows={4}
              value={currentNotulen.ringkasanPembahasan}
              onChange={(e) =>
                updateNotulenField({ ...currentNotulen, ringkasanPembahasan: e.target.value })
              }
              className="mt-2 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
            />
          </div>

          {/* D. Pokok Pembahasan */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                D. Pokok Pembahasan
              </h4>
              <button
                type="button"
                onClick={() =>
                  updateNotulenField({
                    ...currentNotulen,
                    pokokPembahasan: [...currentNotulen.pokokPembahasan, ''],
                  })
                }
                className="text-xs font-medium text-emerald-600 hover:text-emerald-500 dark:text-emerald-400"
              >
                + Tambah Pokok
              </button>
            </div>
            {currentNotulen.pokokPembahasan.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400">Belum diisi</p>
            ) : (
              <div className="space-y-2">
                {currentNotulen.pokokPembahasan.map((item, idx) => (
                  <div key={idx} className="flex gap-2">
                    <input
                      type="text"
                      value={item}
                      onChange={(e) => {
                        const next = [...currentNotulen.pokokPembahasan];
                        next[idx] = e.target.value;
                        updateNotulenField({ ...currentNotulen, pokokPembahasan: next });
                      }}
                      className="flex-1 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
                    />
                    <button
                      type="button"
                      aria-label={`Hapus pokok ${idx + 1}`}
                      onClick={() =>
                        updateNotulenField({
                          ...currentNotulen,
                          pokokPembahasan: currentNotulen.pokokPembahasan.filter((_, i) => i !== idx),
                        })
                      }
                      className="rounded-xl border border-slate-300 px-2.5 text-rose-500 hover:bg-rose-500/10 dark:border-slate-700"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* E. Keputusan dan Kesepakatan */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                E. Keputusan dan Kesepakatan
              </h4>
              <button
                type="button"
                onClick={() =>
                  updateNotulenField({
                    ...currentNotulen,
                    keputusanDanKesepakatan: [...currentNotulen.keputusanDanKesepakatan, ''],
                  })
                }
                className="text-xs font-medium text-emerald-600 hover:text-emerald-500 dark:text-emerald-400"
              >
                + Tambah Keputusan
              </button>
            </div>
            <div className="space-y-2">
              {currentNotulen.keputusanDanKesepakatan.map((item, idx) => (
                <div key={idx} className="flex gap-2">
                  <input
                    type="text"
                    value={item}
                    onChange={(e) => {
                      const next = [...currentNotulen.keputusanDanKesepakatan];
                      next[idx] = e.target.value;
                      updateNotulenField({ ...currentNotulen, keputusanDanKesepakatan: next });
                    }}
                    className="flex-1 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
                  />
                  <button
                    type="button"
                    aria-label={`Hapus keputusan ${idx + 1}`}
                    onClick={() =>
                      updateNotulenField({
                        ...currentNotulen,
                        keputusanDanKesepakatan: currentNotulen.keputusanDanKesepakatan.filter(
                          (_, i) => i !== idx
                        ),
                      })
                    }
                    className="rounded-xl border border-slate-300 px-2.5 text-rose-500 hover:bg-rose-500/10 dark:border-slate-700"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* F. Tindak Lanjut Table */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                F. Tindak Lanjut
              </h4>
              <button
                type="button"
                onClick={() =>
                  scheduleAutosave({
                    ...meeting,
                    actionItems: [
                      ...meeting.actionItems,
                      {
                        id: generateId('act'),
                        task: '',
                        pic: 'Belum ditentukan',
                        deadline: 'Belum ditentukan',
                        status: 'Belum Dimulai',
                      },
                    ],
                  })
                }
                className="text-xs font-medium text-emerald-600 hover:text-emerald-500 dark:text-emerald-400"
              >
                + Tambah Tindak Lanjut
              </button>
            </div>
            <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 dark:bg-[#0B0F17] dark:text-slate-400">
                  <tr>
                    <th className="px-3 py-2.5 font-semibold">No</th>
                    <th className="px-3 py-2.5 font-semibold">Tindak Lanjut</th>
                    <th className="px-3 py-2.5 font-semibold">PIC</th>
                    <th className="px-3 py-2.5 font-semibold">Tenggat</th>
                    <th className="px-3 py-2.5 font-semibold">Status</th>
                    <th className="px-3 py-2.5 font-semibold">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {meeting.actionItems.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-3 py-4 text-center text-slate-500">
                        Belum ada tindak lanjut yang dicatat.
                      </td>
                    </tr>
                  ) : (
                    meeting.actionItems.map((row, idx) => (
                      <tr key={row.id}>
                        <td className="px-3 py-2 font-mono-tabular">{idx + 1}</td>
                        <td className="px-3 py-2 min-w-[200px]">
                          <input
                            type="text"
                            value={row.task}
                            aria-label={`Tugas tindak lanjut ${idx + 1}`}
                            onChange={(e) => {
                              const next = meeting.actionItems.map((a) =>
                                a.id === row.id ? { ...a, task: e.target.value } : a
                              );
                              scheduleAutosave({ ...meeting, actionItems: next });
                            }}
                            className="w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs dark:border-slate-700 dark:bg-[#0B0F17]"
                          />
                        </td>
                        <td className="px-3 py-2 min-w-[130px]">
                          <input
                            type="text"
                            value={row.pic}
                            aria-label={`PIC tindak lanjut ${idx + 1}`}
                            onChange={(e) => {
                              const next = meeting.actionItems.map((a) =>
                                a.id === row.id ? { ...a, pic: e.target.value } : a
                              );
                              scheduleAutosave({ ...meeting, actionItems: next });
                            }}
                            className="w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs dark:border-slate-700 dark:bg-[#0B0F17]"
                          />
                        </td>
                        <td className="px-3 py-2 min-w-[120px]">
                          <input
                            type="text"
                            value={row.deadline}
                            aria-label={`Tenggat tindak lanjut ${idx + 1}`}
                            onChange={(e) => {
                              const next = meeting.actionItems.map((a) =>
                                a.id === row.id ? { ...a, deadline: e.target.value } : a
                              );
                              scheduleAutosave({ ...meeting, actionItems: next });
                            }}
                            className="w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs dark:border-slate-700 dark:bg-[#0B0F17]"
                          />
                        </td>
                        <td className="px-3 py-2">
                          <select
                            value={row.status}
                            aria-label={`Status tindak lanjut ${idx + 1}`}
                            onChange={(e) => {
                              const next = meeting.actionItems.map((a) =>
                                a.id === row.id
                                  ? { ...a, status: e.target.value as ActionItem['status'] }
                                  : a
                              );
                              scheduleAutosave({ ...meeting, actionItems: next });
                            }}
                            className="rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-xs dark:border-slate-700 dark:bg-[#0B0F17]"
                          >
                            <option value="Belum Dimulai">Belum Dimulai</option>
                            <option value="Proses">Proses</option>
                            <option value="Selesai">Selesai</option>
                          </select>
                        </td>
                        <td className="px-3 py-2">
                          <button
                            type="button"
                            aria-label={`Hapus baris tindak lanjut ${idx + 1}`}
                            onClick={() =>
                              scheduleAutosave({
                                ...meeting,
                                actionItems: meeting.actionItems.filter((a) => a.id !== row.id),
                              })
                            }
                            className="text-rose-500 hover:text-rose-400"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* G, H, I */}
          <div className="grid gap-4">
            <div>
              <label className="block font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                G. Kendala dan Catatan Penting
              </label>
              <textarea
                rows={2}
                value={currentNotulen.kendalaDanCatatan}
                onChange={(e) =>
                  updateNotulenField({ ...currentNotulen, kendalaDanCatatan: e.target.value })
                }
                className="mt-2 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm dark:border-slate-700 dark:bg-[#0B0F17]"
              />
            </div>
            <div>
              <label className="block font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                H. Kesimpulan
              </label>
              <textarea
                rows={2}
                value={currentNotulen.kesimpulan}
                onChange={(e) =>
                  updateNotulenField({ ...currentNotulen, kesimpulan: e.target.value })
                }
                className="mt-2 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm dark:border-slate-700 dark:bg-[#0B0F17]"
              />
            </div>
            <div>
              <label className="block font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                I. Catatan Penyusunan
              </label>
              <div className="mt-2 rounded-xl border border-slate-200 bg-slate-50 p-3.5 text-xs leading-relaxed text-slate-600 dark:border-slate-800 dark:bg-[#0B0F17] dark:text-slate-400">
                {currentNotulen.catatanPenyusunan}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* TAB 3: OUTPUT AI LAIN */}
      {subTab === 'outputs' && (
        <section className="rounded-2xl border border-slate-200 bg-white p-6 space-y-5 dark:border-slate-800/90 dark:bg-[#131A26]/85">
          <div className="flex flex-wrap gap-1.5 border-b border-slate-100 pb-4 dark:border-slate-800">
            {[
              { id: 'ringkasan' as OutputKindTab, label: 'Ringkasan' },
              { id: 'keputusan' as OutputKindTab, label: 'Keputusan' },
              { id: 'tindak_lanjut' as OutputKindTab, label: 'Tindak Lanjut' },
              { id: 'laporan' as OutputKindTab, label: 'Laporan' },
              { id: 'surat' as OutputKindTab, label: 'Surat Resmi' },
              { id: 'ide' as OutputKindTab, label: 'Ide & Usulan' },
              { id: 'presentasi' as OutputKindTab, label: 'Materi Presentasi' },
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setOutputTab(item.id)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
                  outputTab === item.id
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {outputTab === 'ringkasan' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-sm font-semibold">Ringkasan Pembahasan</h3>
                <button
                  type="button"
                  disabled={isGeneratingOutput}
                  onClick={() => handleGenerateOtherOutput('ringkasan')}
                  className="rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-500 disabled:opacity-50"
                >
                  {hasAiKey ? 'Susun Ringkasan AI' : 'Buat Ringkasan Lokal'}
                </button>
              </div>
              <textarea
                rows={8}
                value={meeting.summaryText}
                onChange={(e) => scheduleAutosave({ ...meeting, summaryText: e.target.value })}
                placeholder="Ringkasan rapat..."
                className="w-full rounded-xl border border-slate-300 bg-white p-3.5 text-sm dark:border-slate-700 dark:bg-[#0B0F17]"
              />
            </div>
          )}

          {outputTab === 'keputusan' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-sm font-semibold">Daftar Keputusan Resmi</h3>
                <button
                  type="button"
                  onClick={() =>
                    scheduleAutosave({
                      ...meeting,
                      decisions: [
                        ...meeting.decisions,
                        { id: generateId('dec'), decision: '', notes: '' },
                      ],
                    })
                  }
                  className="rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-500"
                >
                  + Tambah Keputusan
                </button>
              </div>
              {meeting.decisions.length === 0 ? (
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Belum ditemukan keputusan yang dinyatakan secara jelas.
                </p>
              ) : (
                <div className="space-y-2.5">
                  {meeting.decisions.map((d: DecisionItem, idx) => (
                    <div
                      key={d.id}
                      className="grid gap-2 rounded-xl border border-slate-200 p-3 sm:grid-cols-12 dark:border-slate-800"
                    >
                      <input
                        type="text"
                        value={d.decision}
                        placeholder={`Keputusan ${idx + 1}`}
                        onChange={(e) =>
                          scheduleAutosave({
                            ...meeting,
                            decisions: meeting.decisions.map((item) =>
                              item.id === d.id ? { ...item, decision: e.target.value } : item
                            ),
                          })
                        }
                        className="sm:col-span-7 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-[#0B0F17]"
                      />
                      <input
                        type="text"
                        value={d.notes}
                        placeholder="Keterangan / dasar keputusan"
                        onChange={(e) =>
                          scheduleAutosave({
                            ...meeting,
                            decisions: meeting.decisions.map((item) =>
                              item.id === d.id ? { ...item, notes: e.target.value } : item
                            ),
                          })
                        }
                        className="sm:col-span-4 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-[#0B0F17]"
                      />
                      <button
                        type="button"
                        aria-label={`Hapus keputusan ${idx + 1}`}
                        onClick={() =>
                          scheduleAutosave({
                            ...meeting,
                            decisions: meeting.decisions.filter((item) => item.id !== d.id),
                          })
                        }
                        className="sm:col-span-1 flex items-center justify-center text-rose-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {outputTab === 'tindak_lanjut' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-sm font-semibold">
                  Daftar Tindak Lanjut (Tugas, PIC, Tenggat, Status)
                </h3>
                <button
                  type="button"
                  onClick={() => exportAsCSV(meeting, 'actions')}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:border-slate-700 dark:text-slate-200"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Unduh CSV</span>
                </button>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Sunting langsung tabel tindak lanjut pada tab &ldquo;Notulen Rapat (A–I)&rdquo; bagian F.
              </p>
              <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-[#0B0F17]">
                    <tr>
                      <th className="px-3 py-2">No</th>
                      <th className="px-3 py-2">Tugas</th>
                      <th className="px-3 py-2">PIC</th>
                      <th className="px-3 py-2">Tenggat</th>
                      <th className="px-3 py-2">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {meeting.actionItems.map((a, idx) => (
                      <tr key={a.id}>
                        <td className="px-3 py-2 font-mono-tabular">{idx + 1}</td>
                        <td className="px-3 py-2">{a.task || 'Belum diisi'}</td>
                        <td className="px-3 py-2">{a.pic}</td>
                        <td className="px-3 py-2">{a.deadline}</td>
                        <td className="px-3 py-2">{a.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {outputTab === 'laporan' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-sm font-semibold">Laporan Kegiatan</h3>
                <button
                  type="button"
                  disabled={isGeneratingOutput}
                  onClick={() => handleGenerateOtherOutput('laporan')}
                  className="rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-500 disabled:opacity-50"
                >
                  {hasAiKey ? 'Susun Laporan AI' : 'Buat Template Laporan'}
                </button>
              </div>
              {(() => {
                const rep = meeting.reportOutput || generateTemplateReport(meeting);
                const fields: Array<[keyof typeof rep, string]> = [
                  ['pendahuluan', '1. Pendahuluan'],
                  ['tujuan', '2. Tujuan'],
                  ['pelaksanaan', '3. Pelaksanaan'],
                  ['pembahasan', '4. Pembahasan'],
                  ['hasil', '5. Hasil'],
                  ['kesimpulan', '6. Kesimpulan'],
                  ['tindakLanjut', '7. Tindak Lanjut'],
                ];
                return fields.map(([key, label]) => (
                  <div key={key}>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                      {label}
                    </label>
                    <textarea
                      rows={2}
                      value={rep[key]}
                      onChange={(e) =>
                        scheduleAutosave({
                          ...meeting,
                          reportOutput: { ...rep, [key]: e.target.value },
                        })
                      }
                      className="mt-1 w-full rounded-xl border border-slate-300 bg-white p-2.5 text-xs dark:border-slate-700 dark:bg-[#0B0F17]"
                    />
                  </div>
                ));
              })()}
            </div>
          )}

          {outputTab === 'surat' && (
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <label htmlFor="letter-kind" className="text-xs font-semibold">
                    Jenis Surat:
                  </label>
                  <select
                    id="letter-kind"
                    value={meeting.letterKind}
                    onChange={(e) =>
                      scheduleAutosave({
                        ...meeting,
                        letterKind: e.target.value as LetterKind,
                      })
                    }
                    className="rounded-xl border border-slate-300 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-[#0B0F17]"
                  >
                    <option value="tindak_lanjut">Surat Tindak Lanjut</option>
                    <option value="undangan">Surat Undangan</option>
                    <option value="permohonan">Surat Permohonan</option>
                    <option value="tugas">Surat Tugas</option>
                    <option value="internal">Surat Internal / Nota Dinas</option>
                  </select>
                </div>
                <button
                  type="button"
                  disabled={isGeneratingOutput}
                  onClick={() => handleGenerateOtherOutput('surat')}
                  className="rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-500 disabled:opacity-50"
                >
                  {hasAiKey ? 'Susun Draf Surat AI' : 'Buat Template Surat'}
                </button>
              </div>
              <textarea
                rows={12}
                value={
                  meeting.letterOutput || generateTemplateLetter(meeting, meeting.letterKind)
                }
                onChange={(e) => scheduleAutosave({ ...meeting, letterOutput: e.target.value })}
                className="w-full rounded-xl border border-slate-300 bg-white p-3.5 font-mono text-xs leading-relaxed dark:border-slate-700 dark:bg-[#0B0F17]"
              />
            </div>
          )}

          {outputTab === 'ide' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-sm font-semibold">Ide & Peluang Tindak Lanjut</h3>
                <button
                  type="button"
                  disabled={isGeneratingOutput}
                  onClick={() => handleGenerateOtherOutput('ide')}
                  className="rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-500 disabled:opacity-50"
                >
                  {hasAiKey ? 'Ekstrak Ide dengan AI' : 'Ambil dari Poin Penting'}
                </button>
              </div>
              <ul className="list-disc space-y-2 pl-5 text-sm text-slate-700 dark:text-slate-300">
                {(meeting.ideasOutput.length > 0
                  ? meeting.ideasOutput
                  : ['Belum ada daftar ide. Klik tombol di atas atau tandai baris transkrip penting.']
                ).map((idea, idx) => (
                  <li key={idx}>{idea}</li>
                ))}
              </ul>
            </div>
          )}

          {outputTab === 'presentasi' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-sm font-semibold">Outline Materi Presentasi</h3>
                <button
                  type="button"
                  disabled={isGeneratingOutput}
                  onClick={() => handleGenerateOtherOutput('presentasi')}
                  className="rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-500 disabled:opacity-50"
                >
                  {hasAiKey ? 'Susun Outline AI' : 'Buat Outline Lokal'}
                </button>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                {(meeting.presentationOutline.length > 0
                  ? meeting.presentationOutline
                  : generateTemplatePresentation(meeting)
                ).map((slide) => (
                  <div
                    key={slide.slideNumber}
                    className="rounded-xl border border-slate-200 p-4 dark:border-slate-800 dark:bg-[#0B0F17]/60"
                  >
                    <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                      Slide {slide.slideNumber}
                    </p>
                    <p className="mt-0.5 font-display text-sm font-semibold">{slide.title}</p>
                    <ul className="mt-2 list-disc space-y-1 pl-4 text-xs text-slate-600 dark:text-slate-300">
                      {slide.bullets.map((b, i) => (
                        <li key={i}>{b}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>
      )}

      {/* TAB 4: EKSPOR & GOOGLE DOCS/SHEETS */}
      {subTab === 'export' && (
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Local Client-Side Exports */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4 dark:border-slate-800/90 dark:bg-[#131A26]/85">
            <div>
              <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Ekspor Dokumen Lokal (Tanpa Server)
              </h3>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Seluruh file dibuat langsung di browser Anda dan siap dibagikan atau diarsipkan.
              </p>
            </div>

            <div className="grid gap-2.5 sm:grid-cols-2">
              <button
                type="button"
                onClick={async () => {
                  try {
                    await exportAsDOCX(meeting);
                    onToast('success', 'DOCX berhasil dibuat');
                  } catch (err) {
                    onToast(
                      'error',
                      'Ekspor DOCX gagal',
                      err instanceof Error ? err.message : 'Gagal membuat DOCX.'
                    );
                  }
                }}
                className="flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-3 text-xs font-semibold text-white hover:bg-emerald-500"
              >
                <FileText className="h-4 w-4 shrink-0" />
                <span>Unduh DOCX (Word)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const res = exportAsPrintPDF(meeting);
                  if (!res.ok && res.error) onToast('warning', 'Cetak PDF', res.error);
                }}
                className="flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-3 text-xs font-semibold text-slate-800 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
              >
                <Printer className="h-4 w-4 shrink-0" />
                <span>Cetak / Simpan PDF</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  exportAsHTML(meeting);
                  onToast('success', 'File HTML diunduh');
                }}
                className="flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-200"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Unduh HTML Rapi</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  exportAsTXT(meeting, 'all');
                  onToast('success', 'TXT Paket Lengkap diunduh');
                }}
                className="flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-200"
              >
                <Download className="h-3.5 w-3.5" />
                <span>TXT (Notulen + Transkrip)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  exportAsCSV(meeting, 'actions');
                  onToast('success', 'CSV Tindak Lanjut diunduh');
                }}
                className="flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-200"
              >
                <FileSpreadsheet className="h-3.5 w-3.5" />
                <span>CSV Tindak Lanjut</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  exportAsCSV(meeting, 'sheets-pack');
                  onToast('success', 'CSV 4 Sheet Lengkap diunduh');
                }}
                className="flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-200"
              >
                <FileSpreadsheet className="h-3.5 w-3.5" />
                <span>CSV 4-Sheet Rapat</span>
              </button>
            </div>

            <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-[11px] text-slate-600 dark:border-slate-800 dark:bg-[#0B0F17] dark:text-slate-400">
              Preview teks Notulen cepat: {formatNotulenMarkdownText(currentNotulen, meeting.actionItems).length} karakter.
            </div>
          </section>

          {/* Optional Google Docs & Sheets */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4 dark:border-slate-800/90 dark:bg-[#131A26]/85">
            <div>
              <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Google Docs &amp; Google Sheets (Opsional)
              </h3>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Status:{' '}
                <strong className={googleConnected ? 'text-emerald-600 dark:text-emerald-400' : ''}>
                  {settings.googleClientId.trim()
                    ? googleConnected
                      ? 'Sesi OAuth Aktif'
                      : 'Client ID Terpasang (Siap Otorisasi)'
                    : 'Belum Terhubung'}
                </strong>
              </p>
            </div>

            {!settings.googleClientId.trim() && (
              <div className="flex items-start gap-2.5 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3.5 text-xs text-amber-900 dark:text-amber-200">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                <span>
                  Integrasi Google Docs/Sheets bersifat opsional dan belum dikonfigurasi. Untuk
                  mengaktifkannya di aplikasi statis, masukkan Google OAuth Client ID Anda di menu
                  Pengaturan, atau langsung gunakan ekspor DOCX dan CSV di sebelah kiri.
                </span>
              </div>
            )}

            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 p-3.5 dark:border-slate-800">
                <div>
                  <p className="text-xs font-semibold">Simpan ke Google Docs</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Membuat Google Doc berisi Notulen A–I. Alternatif: Unduh DOCX / HTML.
                  </p>
                </div>
                <button
                  type="button"
                  disabled={isExportingGoogle !== null || !settings.googleClientId.trim()}
                  onClick={handleGoogleDocsSave}
                  className="rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-40 dark:bg-slate-700 dark:hover:bg-slate-600"
                >
                  {isExportingGoogle === 'docs' ? 'Mengirim...' : 'Simpan ke Google Docs'}
                </button>
              </div>
              {meeting.googleDocsUrl && (
                <a
                  href={meeting.googleDocsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 hover:underline dark:text-emerald-400"
                >
                  <span>Buka Google Docs yang dibuat</span>
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              )}

              <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 p-3.5 dark:border-slate-800">
                <div>
                  <p className="text-xs font-semibold">Simpan ke Google Sheets (4 Sheet)</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Informasi Rapat · Tindak Lanjut · Keputusan · Pembahasan. Alternatif: CSV.
                  </p>
                </div>
                <button
                  type="button"
                  disabled={isExportingGoogle !== null || !settings.googleClientId.trim()}
                  onClick={handleGoogleSheetsSave}
                  className="rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-40 dark:bg-slate-700 dark:hover:bg-slate-600"
                >
                  {isExportingGoogle === 'sheets' ? 'Mengirim...' : 'Simpan ke Google Sheets'}
                </button>
              </div>
              {meeting.googleSheetsUrl && (
                <a
                  href={meeting.googleSheetsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 hover:underline dark:text-emerald-400"
                >
                  <span>Buka Google Sheets yang dibuat</span>
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              )}
            </div>
          </section>
        </div>
      )}
    </div>
  );
};
