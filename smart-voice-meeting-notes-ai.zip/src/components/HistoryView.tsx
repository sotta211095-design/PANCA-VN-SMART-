import React, { useMemo, useState } from 'react';
import { Download, FolderOpen, Search, Trash2 } from 'lucide-react';
import { AppSettings, DEFAULT_CATEGORIES, MeetingRecord } from '../types/meeting';
import { formatDateID, formatDurationHMS, formatFileSize } from '../utils/formatters';
import { searchAllMeetings } from '../utils/meetingLogic';
import { exportAsDOCX } from '../services/exportService';

interface HistoryViewProps {
  meetings: MeetingRecord[];
  settings: AppSettings;
  onOpenMeeting: (id: string) => void;
  onDeleteMeeting: (id: string) => Promise<void>;
  onNavigateRecorder: () => void;
  onToast: (type: 'info' | 'success' | 'warning' | 'error', title: string, desc?: string) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  meetings,
  settings,
  onOpenMeeting,
  onDeleteMeeting,
  onNavigateRecorder,
  onToast,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('Semua');
  const [pendingDelete, setPendingDelete] = useState<MeetingRecord | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const categories = useMemo(
    () => ['Semua', ...Array.from(new Set([...DEFAULT_CATEGORIES, ...(settings.customCategories || [])]))],
    [settings.customCategories]
  );

  const filtered = useMemo(
    () => searchAllMeetings(meetings, searchQuery, categoryFilter),
    [meetings, searchQuery, categoryFilter]
  );

  const transcriptionLabel = (status: MeetingRecord['transcriptionStatus']) => {
    switch (status) {
      case 'ai_selesai':
        return 'Transkrip AI Selesai';
      case 'ai_sebagian':
        return 'Transkrip AI Sebagian';
      case 'draft_browser':
        return 'Draf Browser';
      case 'manual':
        return 'Manual / Edit';
      default:
        return 'Belum Ditranskrip';
    }
  };

  const documentLabel = (status: MeetingRecord['documentStatus']) => {
    switch (status) {
      case 'ai_draft':
        return 'Dokumen AI';
      case 'template_lokal':
        return 'Template Lokal';
      default:
        return 'Belum Ada Dokumen';
    }
  };

  const handleConfirmDelete = async () => {
    if (!pendingDelete) return;
    setIsDeleting(true);
    try {
      await onDeleteMeeting(pendingDelete.id);
      onToast('success', 'Rapat dihapus', pendingDelete.title);
      setPendingDelete(null);
    } catch (err) {
      onToast(
        'error',
        'Gagal menghapus rapat',
        err instanceof Error ? err.message : 'Terjadi kesalahan IndexedDB.'
      );
    } finally {
      setIsDeleting(false);
    }
  };

  const handleQuickExportDocx = async (m: MeetingRecord) => {
    try {
      await exportAsDOCX(m);
      onToast('success', 'DOCX diunduh', m.title);
    } catch (err) {
      onToast(
        'error',
        'Ekspor gagal',
        err instanceof Error ? err.message : 'Gagal membuat file DOCX.'
      );
    }
  };

  return (
    <div className="space-y-6">
      {/* Search & Category Filter Bar */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800/90 dark:bg-[#131A26]/85">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari judul, transkrip, notulen, ringkasan, keputusan, atau tindak lanjut..."
              aria-label="Cari riwayat rapat"
              className="w-full rounded-xl border border-slate-300 bg-white py-2.5 pl-10 pr-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-500 focus:outline-none dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
            />
          </div>
          <select
            aria-label="Filter kategori rapat"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-emerald-500 focus:outline-none sm:w-56 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
        <p className="mt-2.5 text-xs text-slate-500 dark:text-slate-400">
          Menampilkan <strong className="tabular-nums text-slate-700 dark:text-slate-200">{filtered.length}</strong> dari{' '}
          <span className="tabular-nums">{meetings.length}</span> rapat tersimpan
        </p>
      </section>

      {/* Meetings List */}
      {filtered.length === 0 ? (
        <section className="rounded-2xl border border-slate-200 bg-white p-10 text-center dark:border-slate-800/90 dark:bg-[#131A26]/85">
          <p className="text-base font-semibold text-slate-800 dark:text-slate-200">
            {meetings.length === 0
              ? 'Belum ada rapat dalam riwayat'
              : 'Tidak ada rapat yang cocok dengan pencarian Anda'}
          </p>
          <p className="mt-1.5 text-xs text-slate-500 dark:text-slate-400">
            {meetings.length === 0
              ? 'Mulai rekam rapat baru atau buat catatan manual untuk menyimpannya di sini.'
              : 'Coba ubah kata kunci atau pilih kategori "Semua".'}
          </p>
          {meetings.length === 0 && (
            <button
              type="button"
              onClick={onNavigateRecorder}
              className="mt-4 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-emerald-500"
            >
              Rekam Rapat Pertama
            </button>
          )}
        </section>
      ) : (
        <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-slate-800/90 dark:bg-[#131A26]/85">
          <ul className="divide-y divide-slate-100 dark:divide-slate-800/80">
            {filtered.map((m) => (
              <li
                key={m.id}
                className="flex flex-col gap-4 p-5 transition-colors hover:bg-slate-50/70 sm:flex-row sm:items-center sm:justify-between dark:hover:bg-slate-800/25"
              >
                <div className="min-w-0 flex-1 space-y-1">
                  <button
                    type="button"
                    onClick={() => onOpenMeeting(m.id)}
                    className="block truncate text-left font-display text-base font-semibold text-slate-900 hover:text-emerald-600 dark:text-slate-100 dark:hover:text-emerald-400"
                  >
                    {m.title}
                  </button>
                  <p className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500 dark:text-slate-400">
                    <span>{formatDateID(m.date)}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-tabular">{formatDurationHMS(m.durationSeconds)}</span>
                    <span aria-hidden="true">·</span>
                    <span>{m.category}</span>
                    {m.hasAudio && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">Audio {formatFileSize(m.audioByteSize)}</span>
                      </>
                    )}
                  </p>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    {transcriptionLabel(m.transcriptionStatus)} · {documentLabel(m.documentStatus)}
                  </p>
                </div>

                <div className="flex shrink-0 flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onOpenMeeting(m.id)}
                    className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-emerald-600 px-3.5 text-xs font-semibold text-white hover:bg-emerald-500"
                  >
                    <FolderOpen className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Buka</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickExportDocx(m)}
                    aria-label={`Ekspor DOCX ${m.title}`}
                    className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                  >
                    <Download className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>DOCX</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPendingDelete(m)}
                    aria-label={`Hapus rapat ${m.title}`}
                    className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-slate-300 text-rose-600 hover:bg-rose-500/10 dark:border-slate-700 dark:text-rose-400"
                  >
                    <Trash2 className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* Delete Confirmation Modal */}
      {pendingDelete && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-[#131A26]">
            <h2
              id="delete-modal-title"
              className="font-display text-base font-semibold text-slate-900 dark:text-slate-100"
            >
              Hapus Rapat Secara Permanen?
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
              Anda akan menghapus <strong>{pendingDelete.title}</strong> beserta audio rekaman,
              transkrip, dan dokumen terkait dari IndexedDB perangkat ini. Tindakan ini tidak
              dapat dibatalkan.
            </p>
            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setPendingDelete(null)}
                className="rounded-xl border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleConfirmDelete}
                className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-500 disabled:opacity-60"
              >
                {isDeleting ? 'Menghapus...' : 'Ya, Hapus Rapat'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
