import React from 'react';
import { ShieldCheck, Trash2 } from 'lucide-react';
import { GEMINI_SECURITY_WARNING } from '../services/geminiClient';

interface PrivacyViewProps {
  onNavigateSettings: () => void;
}

export const PrivacyView: React.FC<PrivacyViewProps> = ({ onNavigateSettings }) => {
  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 dark:border-slate-800/90 dark:bg-[#131A26]/85">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600/15 text-emerald-600 dark:text-emerald-400">
            <ShieldCheck className="h-5 w-5" aria-hidden="true" />
          </div>
          <div>
            <h2 className="font-display text-xl font-bold text-slate-900 dark:text-slate-50">
              Keamanan, Privasi, dan Transparansi Data
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Penjelasan jujur mengenai di mana audio dan dokumen Anda diproses
            </p>
          </div>
        </div>

        <div className="mt-6 space-y-5 text-sm leading-relaxed text-slate-700 dark:text-slate-300">
          <section className="space-y-1.5 border-b border-slate-100 pb-4 dark:border-slate-800">
            <h3 className="font-display font-semibold text-slate-900 dark:text-slate-100">
              1. Penyimpanan Lokal (IndexedDB)
            </h3>
            <p>
              Seluruh rekaman audio, transkrip, notulen, ringkasan, keputusan, tindak lanjut, dan
              pengaturan Anda disimpan langsung di penyimpanan lokal browser (IndexedDB) pada
              perangkat ini. Aplikasi ini tidak memiliki server backend yang menyimpan rekaman Anda.
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Catatan penting: Data lokal tidak otomatis tersinkron antarperangkat dan dapat hilang
              jika data situs browser dihapus. Gunakan fitur Backup Data secara berkala.
            </p>
          </section>

          <section className="space-y-1.5 border-b border-slate-100 pb-4 dark:border-slate-800">
            <h3 className="font-display font-semibold text-slate-900 dark:text-slate-100">
              2. Transkripsi Browser (Web Speech API)
            </h3>
            <p>
              Jika Anda mengaktifkan mode transkripsi langsung (Web Speech API /
              SpeechRecognition), beberapa browser (seperti Google Chrome) dapat mengirimkan aliran
              suara ke layanan pengenalan suara milik penyedia browser tersebut untuk mengubah suara
              menjadi teks. Aplikasi tidak mengklaim bahwa mode ini selalu berjalan 100% offline.
            </p>
          </section>

          <section className="space-y-1.5 border-b border-slate-100 pb-4 dark:border-slate-800">
            <h3 className="font-display font-semibold text-slate-900 dark:text-slate-100">
              3. Penggunaan AI Opsional (Gemini API) & Risiko API Key
            </h3>
            <p>
              Aplikasi inti tetap berfungsi penuh tanpa API Key. Apabila Anda memasukkan API Key
              Gemini dan secara sadar menekan tombol transkripsi AI, generate notulen AI, atau Tanya
              Rapat AI, audio atau teks transkrip yang dipilih akan dikirim langsung dari browser ke
              layanan Google Gemini API. Aplikasi tidak pernah mengunggah audio secara otomatis.
            </p>
            <div className="mt-2 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3.5 text-xs text-amber-900 dark:text-amber-200">
              {GEMINI_SECURITY_WARNING}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              API Key Anda hanya disimpan di memori sesi (RAM tab saat ini) dan tidak ditulis secara
              permanen ke IndexedDB atau localStorage, sehingga Anda perlu memasukkannya kembali
              setelah memuat ulang halaman.
            </p>
          </section>

          <section className="space-y-1.5 border-b border-slate-100 pb-4 dark:border-slate-800">
            <h3 className="font-display font-semibold text-slate-900 dark:text-slate-100">
              4. Integrasi Opsional Google Docs & Google Sheets
            </h3>
            <p>
              Integrasi ke Google Docs atau Google Sheets bersifat opsional menggunakan OAuth
              Client ID yang Anda konfigurasi sendiri dengan izin minimal (<code>drive.file</code>).
              Token akses hanya disimpan di memori sesi. Jika tidak dikonfigurasi, gunakan ekspor
              DOCX, HTML, atau CSV secara offline.
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="font-display font-semibold text-slate-900 dark:text-slate-100">
              5. Kontrol Penuh Pengguna
            </h3>
            <p>
              Anda memegang kendali penuh untuk menghapus rekaman audio setelah transkripsi selesai,
              mengunduh salinan backup JSON, atau menghapus seluruh data lokal kapan saja.
            </p>
            <div className="pt-2">
              <button
                type="button"
                onClick={onNavigateSettings}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-slate-100 px-4 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              >
                <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Kelola Backup, Retensi Audio & Hapus Data di Pengaturan</span>
              </button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
