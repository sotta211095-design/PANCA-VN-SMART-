import React, { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  DatabaseBackup,
  Eye,
  EyeOff,
  KeyRound,
  Moon,
  Sun,
  Trash2,
  Upload,
} from 'lucide-react';
import { AppSettings, BackupPayload } from '../types/meeting';
import { formatFileSize } from '../utils/formatters';
import { validateBackupPayload } from '../utils/meetingLogic';
import {
  buildBackupPayload,
  clearAllLocalData,
  restoreBackupPayload,
  StorageEstimateInfo,
} from '../services/storage';
import {
  clearSessionGeminiKey,
  GEMINI_MODELS,
  GEMINI_SECURITY_WARNING,
  getSessionGeminiKey,
  hasSessionGeminiKey,
  setSessionGeminiKey,
  testGeminiConnection,
} from '../services/geminiClient';
import {
  clearGoogleSessionToken,
  hasGoogleSessionToken,
} from '../services/googleIntegration';
import { downloadJsonFile } from '../services/exportService';

interface SettingsViewProps {
  settings: AppSettings;
  storageInfo: StorageEstimateInfo;
  meetingCount: number;
  onSaveSettings: (next: AppSettings) => Promise<void>;
  onRefreshAll: () => Promise<void>;
  onAiKeyChanged: (active: boolean) => void;
  onToast: (type: 'info' | 'success' | 'warning' | 'error', title: string, desc?: string) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  storageInfo,
  meetingCount,
  onSaveSettings,
  onRefreshAll,
  onAiKeyChanged,
  onToast,
}) => {
  const [apiKeyInput, setApiKeyInput] = useState(getSessionGeminiKey());
  const [showKey, setShowKey] = useState(false);
  const [testingAi, setTestingAi] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [newCatInput, setNewCatInput] = useState('');

  // Backup & Restore state
  const [backupIncludeAudio, setBackupIncludeAudio] = useState(true);
  const [estimatedBackupSize, setEstimatedBackupSize] = useState<number | null>(null);
  const [isBuildingBackup, setIsBuildingBackup] = useState(false);
  const [pendingRestore, setPendingRestore] = useState<BackupPayload | null>(null);
  const [restoreMode, setRestoreMode] = useState<'merge' | 'replace'>('merge');
  const [isRestoring, setIsRestoring] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const restoreInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    let cancelled = false;
    const estimate = async () => {
      try {
        const res = await buildBackupPayload({
          includeAudio: backupIncludeAudio,
          settings,
        });
        if (!cancelled) setEstimatedBackupSize(res.estimatedBytes);
      } catch {
        if (!cancelled) setEstimatedBackupSize(null);
      }
    };
    estimate();
    return () => {
      cancelled = true;
    };
  }, [backupIncludeAudio, meetingCount, settings]);

  const handleSaveSessionKey = () => {
    setSessionGeminiKey(apiKeyInput);
    const active = hasSessionGeminiKey();
    onAiKeyChanged(active);
    setTestResult(null);
    onToast(
      active ? 'success' : 'info',
      active ? 'API Key aktif di memori sesi' : 'API Key kosong',
      active
        ? 'Hanya tersimpan di RAM tab ini dan otomatis terhapus saat halaman dimuat ulang.'
        : undefined
    );
  };

  const handleClearKey = () => {
    clearSessionGeminiKey();
    setApiKeyInput('');
    setTestResult(null);
    onAiKeyChanged(false);
    onToast('info', 'API Key dihapus dari memori sesi');
  };

  const handleTestConnection = async () => {
    setTestingAi(true);
    setTestResult(null);
    const res = await testGeminiConnection(apiKeyInput, settings.geminiModel);
    setTestingAi(false);
    setTestResult({ ok: res.ok, msg: res.message });
    if (res.ok) {
      setSessionGeminiKey(apiKeyInput);
      onAiKeyChanged(true);
    }
  };

  const handleDownloadBackup = async () => {
    setIsBuildingBackup(true);
    try {
      const { payload, estimatedBytes } = await buildBackupPayload({
        includeAudio: backupIncludeAudio,
        settings,
      });
      const stamp = new Date().toISOString().slice(0, 10);
      const suffix = payload.includesAudio ? 'lengkap-audio' : 'metadata-dokumen';
      downloadJsonFile(payload, `backup-smart-voice-notes-${stamp}-${suffix}.json`);
      onToast(
        'success',
        'Backup diunduh',
        `${payload.meetings.length} rapat (${formatFileSize(estimatedBytes)})${
          !payload.includesAudio ? ' · Audio tidak disertakan' : ''
        }`
      );
    } catch (err) {
      onToast(
        'error',
        'Backup gagal',
        err instanceof Error ? err.message : 'Gagal membuat file backup.'
      );
    } finally {
      setIsBuildingBackup(false);
    }
  };

  const handleRestoreFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const check = validateBackupPayload(parsed);
      if (check.valid === false) {
        onToast('error', 'Format backup tidak valid', check.error);
        return;
      }
      setPendingRestore(check.payload);
    } catch {
      onToast('error', 'File bukan JSON yang valid', 'Pastikan Anda memilih file backup .json dari aplikasi ini.');
    }
  };

  const handleConfirmRestore = async () => {
    if (!pendingRestore) return;
    setIsRestoring(true);
    try {
      const res = await restoreBackupPayload(pendingRestore, restoreMode);
      await onRefreshAll();
      setPendingRestore(null);
      onToast(
        'success',
        'Restore berhasil',
        `${res.restoredMeetings} rapat dan ${res.restoredAudio} rekaman audio dipulihkan.`
      );
    } catch (err) {
      onToast(
        'error',
        'Restore gagal',
        err instanceof Error ? err.message : 'Gagal memulihkan data ke IndexedDB.'
      );
    } finally {
      setIsRestoring(false);
    }
  };

  const handleClearAll = async () => {
    try {
      await clearAllLocalData();
      clearSessionGeminiKey();
      clearGoogleSessionToken();
      onAiKeyChanged(false);
      await onRefreshAll();
      setShowClearConfirm(false);
      onToast('success', 'Seluruh data lokal dihapus');
    } catch (err) {
      onToast(
        'error',
        'Gagal menghapus data',
        err instanceof Error ? err.message : 'Kesalahan IndexedDB.'
      );
    }
  };

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      {/* Appearance, Language & Audio Preferences */}
      <section className="rounded-2xl border border-slate-200 bg-white p-6 space-y-5 dark:border-slate-800/90 dark:bg-[#131A26]/85">
        <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
          Tampilan, Bahasa &amp; Penyimpanan Audio
        </h2>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <span className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Tema Aplikasi
            </span>
            <div className="mt-2 flex gap-2">
              <button
                type="button"
                onClick={() => onSaveSettings({ ...settings, theme: 'dark' })}
                className={`flex flex-1 items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-xs font-semibold ${
                  settings.theme === 'dark'
                    ? 'border-emerald-500 bg-emerald-600/15 text-emerald-700 dark:text-emerald-300'
                    : 'border-slate-300 text-slate-700 dark:border-slate-700 dark:text-slate-300'
                }`}
              >
                <Moon className="h-4 w-4" />
                <span>Gelap</span>
              </button>
              <button
                type="button"
                onClick={() => onSaveSettings({ ...settings, theme: 'light' })}
                className={`flex flex-1 items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-xs font-semibold ${
                  settings.theme === 'light'
                    ? 'border-emerald-500 bg-emerald-600/15 text-emerald-700 dark:text-emerald-300'
                    : 'border-slate-300 text-slate-700 dark:border-slate-700 dark:text-slate-300'
                }`}
              >
                <Sun className="h-4 w-4" />
                <span>Terang</span>
              </button>
            </div>
          </div>

          <div>
            <label
              htmlFor="set-speech-lang"
              className="block text-xs font-medium text-slate-600 dark:text-slate-400"
            >
              Bahasa Utama Transkripsi
            </label>
            <select
              id="set-speech-lang"
              value={settings.speechLanguage}
              onChange={(e) =>
                onSaveSettings({
                  ...settings,
                  speechLanguage: e.target.value as AppSettings['speechLanguage'],
                })
              }
              className="mt-2 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
            >
              <option value="id-ID">Bahasa Indonesia (id-ID)</option>
              <option value="en-US">English (en-US)</option>
              <option value="ms-MY">Bahasa Melayu (ms-MY)</option>
            </select>
          </div>
        </div>

        <label className="flex items-start gap-3 rounded-xl border border-slate-200 p-4 dark:border-slate-800">
          <input
            type="checkbox"
            checked={settings.autoDeleteAudioAfterTranscript}
            onChange={(e) =>
              onSaveSettings({
                ...settings,
                autoDeleteAudioAfterTranscript: e.target.checked,
              })
            }
            className="mt-0.5 h-4 w-4 accent-emerald-600"
          />
          <div className="text-xs">
            <span className="font-semibold text-slate-900 dark:text-slate-100">
              Hapus audio otomatis setelah transkripsi AI selesai penuh
            </span>
            <p className="mt-0.5 text-slate-500 dark:text-slate-400">
              Menghemat ruang IndexedDB perangkat jika Anda hanya membutuhkan teks transkrip dan
              notulen.
            </p>
          </div>
        </label>

        {/* Custom Categories */}
        <div className="space-y-2 border-t border-slate-100 pt-4 dark:border-slate-800">
          <span className="block text-xs font-medium text-slate-700 dark:text-slate-300">
            Kategori Rapat Kustom
          </span>
          <div className="flex gap-2">
            <input
              type="text"
              value={newCatInput}
              onChange={(e) => setNewCatInput(e.target.value)}
              placeholder="Tambah kategori baru..."
              aria-label="Tambah kategori kustom"
              className="flex-1 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-[#0B0F17]"
            />
            <button
              type="button"
              onClick={() => {
                const trimmed = newCatInput.trim();
                if (!trimmed) return;
                const next = Array.from(new Set([...settings.customCategories, trimmed]));
                onSaveSettings({ ...settings, customCategories: next });
                setNewCatInput('');
                onToast('success', 'Kategori ditambahkan', trimmed);
              }}
              className="rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-500"
            >
              Tambah
            </button>
          </div>
          {settings.customCategories.length > 0 && (
            <div className="flex flex-wrap gap-2 pt-1 text-xs text-slate-600 dark:text-slate-300">
              {settings.customCategories.map((c) => (
                <span key={c} className="inline-flex items-center gap-1.5">
                  <span>{c}</span>
                  <button
                    type="button"
                    aria-label={`Hapus kategori ${c}`}
                    onClick={() =>
                      onSaveSettings({
                        ...settings,
                        customCategories: settings.customCategories.filter((x) => x !== c),
                      })
                    }
                    className="text-rose-500 hover:text-rose-400"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Storage Quota Indicator */}
        {storageInfo.supported && (
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-[#0B0F17]">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-700 dark:text-slate-300">
                Kapasitas IndexedDB Browser
              </span>
              <span className="font-mono-tabular text-slate-600 dark:text-slate-400">
                {formatFileSize(storageInfo.usageBytes)} / {formatFileSize(storageInfo.quotaBytes)} (
                {storageInfo.percentUsed.toFixed(1)}%)
              </span>
            </div>
            <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
              <div
                className={`h-full ${
                  storageInfo.isNearLimit ? 'bg-amber-500' : 'bg-emerald-500'
                }`}
                style={{ width: `${Math.max(2, storageInfo.percentUsed)}%` }}
              />
            </div>
          </div>
        )}
      </section>

      {/* AI Settings (Optional Gemini API Key in Session Memory Only) */}
      <section className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4 dark:border-slate-800/90 dark:bg-[#131A26]/85">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <KeyRound className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              AI Settings — Gemini API (Opsional)
            </h2>
          </div>
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
            {hasSessionGeminiKey() ? 'Aktif di Memori Sesi' : 'Tidak Terhubung'}
          </span>
        </div>

        <div className="rounded-xl border border-amber-500/35 bg-amber-500/10 p-3.5 text-xs leading-relaxed text-amber-900 dark:text-amber-200">
          {GEMINI_SECURITY_WARNING}
        </div>

        <p className="text-xs text-slate-500 dark:text-slate-400">
          API Key hanya disimpan sementara di memori sesi tab (RAM), tidak pernah ditulis ke
          IndexedDB, localStorage, atau file kode. Aplikasi inti tetap berjalan penuh tanpa API Key.
        </p>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label
              htmlFor="gemini-key-input"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300"
            >
              Gemini API Key (Sesi Saat Ini)
            </label>
            <div className="mt-1.5 flex gap-2">
              <div className="relative flex-1">
                <input
                  id="gemini-key-input"
                  type={showKey ? 'text' : 'password'}
                  value={apiKeyInput}
                  onChange={(e) => setApiKeyInput(e.target.value)}
                  placeholder="Tempel API Key Gemini Anda (opsional)..."
                  autoComplete="off"
                  className="w-full rounded-xl border border-slate-300 bg-white py-2 pl-3 pr-9 text-xs text-slate-900 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
                />
                <button
                  type="button"
                  onClick={() => setShowKey((v) => !v)}
                  aria-label={showKey ? 'Sembunyikan API Key' : 'Tampilkan API Key'}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
          </div>

          <div>
            <label
              htmlFor="gemini-model-select"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300"
            >
              Model Teks / Notulen
            </label>
            <select
              id="gemini-model-select"
              value={settings.geminiModel}
              onChange={(e) => onSaveSettings({ ...settings, geminiModel: e.target.value })}
              className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
            >
              {GEMINI_MODELS.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleSaveSessionKey}
            className="rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-500"
          >
            Aktifkan di Sesi Ini
          </button>
          <button
            type="button"
            disabled={testingAi}
            onClick={handleTestConnection}
            className="rounded-xl border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 disabled:opacity-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            {testingAi ? 'Menguji...' : 'Uji Koneksi'}
          </button>
          {hasSessionGeminiKey() && (
            <button
              type="button"
              onClick={handleClearKey}
              className="rounded-xl border border-rose-500/40 px-4 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-500/10 dark:text-rose-400"
            >
              Hapus API Key
            </button>
          )}
        </div>

        {testResult && (
          <div
            role="status"
            className={`flex items-center gap-2 rounded-xl p-3 text-xs ${
              testResult.ok
                ? 'border border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                : 'border border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300'
            }`}
          >
            {testResult.ok ? (
              <CheckCircle2 className="h-4 w-4 shrink-0" />
            ) : (
              <AlertTriangle className="h-4 w-4 shrink-0" />
            )}
            <span>{testResult.msg}</span>
          </div>
        )}
      </section>

      {/* Optional Google OAuth Client ID */}
      <section className="rounded-2xl border border-slate-200 bg-white p-6 space-y-3 dark:border-slate-800/90 dark:bg-[#131A26]/85">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Integrasi Google Docs &amp; Sheets (Opsional)
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            {hasGoogleSessionToken()
              ? 'Terhubung di Sesi Ini'
              : settings.googleClientId
                ? 'Client ID Terkonfigurasi'
                : 'Belum Terhubung'}
          </span>
        </div>
        <p className="text-xs leading-relaxed text-slate-500 dark:text-slate-400">
          Untuk GitHub Pages statis tanpa backend, masukkan OAuth 2.0 Web Client ID Anda sendiri
          (dengan Authorized JavaScript Origin URL GitHub Pages Anda). Aplikasi hanya meminta izin
          minimal (<code>drive.file</code>) dan token tidak disimpan permanen. Tanpa ini, gunakan
          ekspor DOCX dan CSV.
        </p>
        <div className="flex flex-wrap gap-2">
          <input
            type="text"
            value={settings.googleClientId}
            onChange={(e) => onSaveSettings({ ...settings, googleClientId: e.target.value })}
            placeholder="xxxx.apps.googleusercontent.com (opsional)"
            aria-label="Google OAuth Client ID"
            className="flex-1 min-w-[220px] rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-xs dark:border-slate-700 dark:bg-[#0B0F17]"
          />
          {hasGoogleSessionToken() && (
            <button
              type="button"
              onClick={() => {
                clearGoogleSessionToken();
                onToast('info', 'Sesi OAuth Google diputus');
              }}
              className="rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-medium dark:border-slate-700"
            >
              Putus Sesi Google
            </button>
          )}
        </div>
      </section>

      {/* Backup & Restore */}
      <section className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4 dark:border-slate-800/90 dark:bg-[#131A26]/85">
        <div className="flex items-center gap-2">
          <DatabaseBackup className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Backup &amp; Restore Data Lokal
          </h2>
        </div>

        <div className="flex flex-col gap-3 rounded-xl border border-slate-200 p-4 sm:flex-row sm:items-center sm:justify-between dark:border-slate-800">
          <div className="space-y-1 text-xs">
            <label className="flex items-center gap-2 font-semibold text-slate-800 dark:text-slate-200">
              <input
                type="checkbox"
                checked={backupIncludeAudio}
                onChange={(e) => setBackupIncludeAudio(e.target.checked)}
                className="h-4 w-4 accent-emerald-600"
              />
              <span>Sertakan Rekaman Audio dalam File Backup</span>
            </label>
            <p className="text-slate-500 dark:text-slate-400">
              {backupIncludeAudio
                ? 'Backup lengkap mencakup metadata, transkrip, dokumen, dan audio.'
                : 'Hanya metadata, transkrip, notulen, dan dokumen (audio tidak disertakan).'}
            </p>
            <p className="font-mono-tabular text-slate-600 dark:text-slate-300">
              Perkiraan ukuran:{' '}
              {estimatedBackupSize !== null ? formatFileSize(estimatedBackupSize) : 'Menghitung...'}
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              disabled={isBuildingBackup}
              onClick={handleDownloadBackup}
              className="rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-emerald-500 disabled:opacity-50"
            >
              {isBuildingBackup ? 'Menyiapkan...' : 'Backup Data (JSON)'}
            </button>
            <button
              type="button"
              onClick={() => restoreInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Upload className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Restore Data</span>
            </button>
            <input
              ref={restoreInputRef}
              type="file"
              accept="application/json,.json"
              onChange={handleRestoreFileSelected}
              className="hidden"
            />
          </div>
        </div>
      </section>

      {/* Danger Zone: Clear Local Data */}
      <section className="rounded-2xl border border-rose-500/30 bg-white p-6 dark:bg-[#131A26]/85">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="font-display text-sm font-semibold text-rose-600 dark:text-rose-400">
              Hapus Seluruh Data Lokal
            </h2>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Menghapus seluruh rapat, potongan audio, transkrip, dan pengaturan di IndexedDB perangkat ini.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowClearConfirm(true)}
            className="inline-flex items-center gap-2 rounded-xl border border-rose-500/50 px-4 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-500/10 dark:text-rose-400"
          >
            <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Hapus Semua Data</span>
          </button>
        </div>
      </section>

      {/* Restore Confirmation Modal */}
      {pendingRestore && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="restore-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-[#131A26]">
            <h3
              id="restore-modal-title"
              className="font-display text-base font-semibold text-slate-900 dark:text-slate-100"
            >
              Konfirmasi Pemulihan Data (Restore)
            </h3>
            <p className="mt-2 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
              File backup valid berisi <strong>{pendingRestore.meetings.length}</strong> rapat
              {pendingRestore.includesAudio
                ? ` dan ${pendingRestore.audioFiles?.length || 0} rekaman audio.`
                : ' (tanpa file audio).'}
            </p>
            <div className="mt-4 space-y-2 text-xs">
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="restore-mode"
                  checked={restoreMode === 'merge'}
                  onChange={() => setRestoreMode('merge')}
                />
                <span>Gabungkan / perbarui rapat yang ada (aman)</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="restore-mode"
                  checked={restoreMode === 'replace'}
                  onChange={() => setRestoreMode('replace')}
                />
                <span>Ganti seluruh data lokal saat ini dengan isi backup</span>
              </label>
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <button
                type="button"
                disabled={isRestoring}
                onClick={() => setPendingRestore(null)}
                className="rounded-xl border border-slate-300 px-4 py-2 text-xs font-semibold dark:border-slate-700"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isRestoring}
                onClick={handleConfirmRestore}
                className="rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-500 disabled:opacity-50"
              >
                {isRestoring ? 'Memulihkan...' : 'Pulihkan Sekarang'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear All Data Confirmation Modal */}
      {showClearConfirm && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="clear-all-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-[#131A26]">
            <h3
              id="clear-all-title"
              className="font-display text-base font-semibold text-rose-600 dark:text-rose-400"
            >
              Hapus Semua Data di Perangkat Ini?
            </h3>
            <p className="mt-2 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
              Seluruh {meetingCount} rapat, audio, transkrip, dan dokumen akan dihapus permanen dari
              IndexedDB. Pastikan Anda sudah mengunduh backup terlebih dahulu.
            </p>
            <div className="mt-6 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowClearConfirm(false)}
                className="rounded-xl border border-slate-300 px-4 py-2 text-xs font-semibold dark:border-slate-700"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleClearAll}
                className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-500"
              >
                Ya, Hapus Semua
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
