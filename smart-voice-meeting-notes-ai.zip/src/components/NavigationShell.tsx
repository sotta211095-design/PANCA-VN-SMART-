import React, { useState } from 'react';
import {
  AudioLines,
  Download,
  FolderClock,
  Home,
  MessageSquareText,
  Mic,
  Settings,
  ShieldCheck,
  WifiOff,
} from 'lucide-react';
import { NavigationTab } from '../types/meeting';
import { formatFileSize } from '../utils/formatters';
import { StorageEstimateInfo } from '../services/storage';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

interface NavigationShellProps {
  activeTab: NavigationTab;
  onNavigate: (tab: NavigationTab) => void;
  storageInfo: StorageEstimateInfo;
  isRecording: boolean;
  recordingDurationText: string;
  hasAiKey: boolean;
  pageTitle: string;
  children: React.ReactNode;
}

export const NavigationShell: React.FC<NavigationShellProps> = ({
  activeTab,
  onNavigate,
  storageInfo,
  isRecording,
  recordingDurationText,
  hasAiKey,
  pageTitle,
  children,
}) => {
  const isOnline = useOnlineStatus();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  const navItems: Array<{ id: NavigationTab; label: string; icon: React.ComponentType<{ className?: string }> }> = [
    { id: 'dashboard', label: 'Beranda', icon: Home },
    { id: 'recorder', label: 'Rekam Rapat', icon: Mic },
    { id: 'history', label: 'Riwayat', icon: FolderClock },
    { id: 'assistant', label: 'Tanya Rapat', icon: MessageSquareText },
    { id: 'settings', label: 'Pengaturan', icon: Settings },
    { id: 'privacy', label: 'Privasi', icon: ShieldCheck },
  ];

  const storageLabel = storageInfo.supported
    ? `Lokal ${formatFileSize(storageInfo.usageBytes)}`
    : 'Penyimpanan IndexedDB';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-[#0B0F17] dark:text-[#F1F5F9]">
      {/* Desktop Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-slate-200 bg-white/90 backdrop-blur-md lg:flex dark:border-slate-800/80 dark:bg-[#0F1520]/95 no-print">
        <div className="flex items-center gap-3 px-5 py-5 border-b border-slate-200/80 dark:border-slate-800/80">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-600 text-white">
            <AudioLines className="h-5 w-5" aria-hidden="true" />
          </div>
          <div className="min-w-0">
            <span className="block truncate font-display text-sm font-semibold tracking-tight text-slate-900 dark:text-slate-100">
              Smart Voice Notes
            </span>
            <span className="block truncate text-xs text-slate-500 dark:text-slate-400">
              Dengar · Catat · Rangkum
            </span>
          </div>
        </div>

        <nav aria-label="Navigasi utama" className="flex-1 space-y-1 px-3 py-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive =
              activeTab === item.id || (activeTab === 'detail' && item.id === 'history');
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className={`flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-left text-sm font-medium whitespace-nowrap ${
                  isActive
                    ? 'bg-emerald-600/15 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800/60 dark:hover:text-slate-100'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="border-t border-slate-200/80 p-4 text-xs dark:border-slate-800/80 space-y-2.5">
          <div className="flex items-center justify-between text-slate-600 dark:text-slate-400">
            <span>Penyimpanan</span>
            <span className="font-mono-tabular text-slate-800 dark:text-slate-200">
              {storageLabel}
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-600 dark:text-slate-400">
            <span>Mode AI</span>
            <span className={hasAiKey ? 'text-emerald-600 dark:text-emerald-400 font-medium' : 'text-slate-500 dark:text-slate-400'}>
              {hasAiKey ? 'Sesi Aktif' : 'Opsional (Off)'}
            </span>
          </div>
          {!isInstalled && isInstallable && (
            <button
              type="button"
              onClick={install}
              className="mt-1 flex w-full items-center justify-center gap-2 rounded-xl border border-slate-200 bg-slate-100 px-3 py-2 text-xs font-medium text-slate-800 hover:bg-slate-200 dark:border-slate-700 dark:bg-slate-800/80 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Download className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Pasang Aplikasi (PWA)</span>
            </button>
          )}
          {!isInstalled && isIOS && !isInstallable && (
            <button
              type="button"
              onClick={() => setShowIOSGuide(true)}
              className="mt-1 flex w-full items-center justify-center gap-2 rounded-xl border border-slate-200 bg-slate-100 px-3 py-2 text-xs font-medium text-slate-800 hover:bg-slate-200 dark:border-slate-700 dark:bg-slate-800/80 dark:text-slate-200"
            >
              <Download className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Cara Pasang di iOS</span>
            </button>
          )}
        </div>
      </aside>

      {/* Main Column */}
      <div className="flex min-h-screen flex-col lg:pl-64">
        {/* Top Bar (3 zones: Brand/Context — Status — Primary Action) */}
        <header className="sticky top-0 z-20 flex h-14 items-center justify-between gap-4 border-b border-slate-200/80 bg-white/85 px-4 backdrop-blur-md lg:px-8 dark:border-slate-800/80 dark:bg-[#0B0F17]/85 no-print">
          <div className="flex min-w-0 items-center gap-3">
            <button
              type="button"
              onClick={() => onNavigate('dashboard')}
              className="flex items-center gap-2 text-left lg:hidden"
              aria-label="Kembali ke Beranda"
            >
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-emerald-600 text-white">
                <AudioLines className="h-4 w-4" aria-hidden="true" />
              </span>
            </button>
            <h1 className="truncate font-display text-sm font-semibold text-slate-900 sm:text-base dark:text-slate-100">
              {pageTitle}
            </h1>
          </div>

          <div className="hidden items-center gap-4 text-xs text-slate-500 sm:flex dark:text-slate-400">
            {!isOnline && (
              <span className="inline-flex items-center gap-1.5 text-amber-600 dark:text-amber-400 font-medium">
                <WifiOff className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Offline</span>
              </span>
            )}
            {isRecording ? (
              <span className="inline-flex items-center gap-2 font-mono-tabular font-medium text-rose-600 dark:text-rose-400">
                <span className="h-2 w-2 rounded-full bg-rose-500 animate-pulse" aria-hidden="true" />
                <span>Merekam {recordingDurationText}</span>
              </span>
            ) : (
              <span className="whitespace-nowrap">{storageLabel}</span>
            )}
          </div>

          <div className="flex shrink-0 items-center gap-2">
            <button
              type="button"
              onClick={() => onNavigate('settings')}
              aria-label="Buka Pengaturan"
              className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 lg:hidden dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800/70"
            >
              <Settings className="h-4 w-4" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={() => onNavigate('recorder')}
              className="inline-flex h-10 items-center gap-2 rounded-xl bg-emerald-600 px-4 text-xs font-semibold text-white transition-colors hover:bg-emerald-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-500 whitespace-nowrap shrink-0 sm:text-sm"
            >
              <Mic className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>{isRecording ? 'Lihat Rekaman' : 'Mulai Rekam'}</span>
            </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 pb-24 sm:px-6 lg:px-8 lg:pb-10">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Tab Bar (<= 15% viewport height) */}
      <nav
        aria-label="Navigasi seluler"
        className="fixed bottom-0 left-0 right-0 z-30 grid h-16 grid-cols-4 border-t border-slate-200 bg-white/95 backdrop-blur-md lg:hidden dark:border-slate-800 dark:bg-[#0F1520]/95 no-print"
      >
        {[
          { id: 'dashboard' as NavigationTab, label: 'Beranda', icon: Home },
          { id: 'recorder' as NavigationTab, label: 'Rekam', icon: Mic },
          { id: 'history' as NavigationTab, label: 'Riwayat', icon: FolderClock },
          { id: 'assistant' as NavigationTab, label: 'Tanya AI', icon: MessageSquareText },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive =
            activeTab === tab.id || (activeTab === 'detail' && tab.id === 'history');
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onNavigate(tab.id)}
              className={`flex min-h-[44px] flex-col items-center justify-center gap-1 text-[11px] font-medium transition-colors ${
                isActive
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100'
              }`}
            >
              <Icon className="h-5 w-5" aria-hidden="true" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* iOS Safari Install Guide Modal */}
      {showIOSGuide && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="ios-install-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-[#131A26]">
            <h2
              id="ios-install-title"
              className="font-display text-base font-semibold text-slate-900 dark:text-slate-100"
            >
              Pasang di iPhone / iPad
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
              1. Ketuk tombol <strong>Bagikan (Share)</strong> pada bilah Safari.
              <br />
              2. Gulir ke bawah dan pilih <strong>Tambahkan ke Layar Utama (Add to Home Screen)</strong>.
            </p>
            <button
              type="button"
              onClick={() => setShowIOSGuide(false)}
              className="mt-5 w-full rounded-xl bg-emerald-600 py-2.5 text-sm font-medium text-white hover:bg-emerald-500"
            >
              Tutup
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
