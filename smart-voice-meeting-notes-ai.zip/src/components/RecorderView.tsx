import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  FileAudio,
  FilePlus2,
  Mic,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Square,
  Trash2,
} from 'lucide-react';
import {
  AppSettings,
  DEFAULT_CATEGORIES,
  MeetingRecord,
  TranscriptSegment,
} from '../types/meeting';
import { formatDurationHMS, formatFileSize, generateId } from '../utils/formatters';
import {
  assembleMeetingAudio,
  deleteAudioChunksForMeeting,
  deleteRecordingDraftMeta,
  RecordingDraftMeta,
  saveAudioChunk,
  saveMeeting,
  saveRecordingDraftMeta,
} from '../services/storage';
import {
  detectRecorderCapabilities,
  LiveAudioSession,
  startAudioCapture,
} from '../services/recorder';
import {
  checkSpeechRecognitionSupport,
  SpeechSessionController,
  startBrowserSpeechRecognition,
} from '../services/transcription';

interface RecorderViewProps {
  settings: AppSettings;
  recoverableDrafts: RecordingDraftMeta[];
  onRefreshDrafts: () => Promise<void>;
  onAddCustomCategory: (cat: string) => Promise<void>;
  onMeetingSaved: (meeting: MeetingRecord) => void;
  onRecordingActiveChange: (active: boolean, durationText: string) => void;
  onToast: (type: 'info' | 'success' | 'warning' | 'error', title: string, desc?: string) => void;
}

export const RecorderView: React.FC<RecorderViewProps> = ({
  settings,
  recoverableDrafts,
  onRefreshDrafts,
  onAddCustomCategory,
  onMeetingSaved,
  onRecordingActiveChange,
  onToast,
}) => {
  const now = useMemo(() => new Date(), []);
  const [title, setTitle] = useState('');
  const [activityName, setActivityName] = useState('');
  const [category, setCategory] = useState(DEFAULT_CATEGORIES[0]);
  const [newCategoryInput, setNewCategoryInput] = useState('');
  const [showNewCategory, setShowNewCategory] = useState(false);
  const [date, setDate] = useState(now.toISOString().slice(0, 10));
  const [startTime, setStartTime] = useState(
    now.toTimeString().slice(0, 5)
  );
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');

  const [useWebSpeech, setUseWebSpeech] = useState(true);
  const [speechLang, setSpeechLang] = useState<string>(settings.speechLanguage || 'id-ID');

  const [recStatus, setRecStatus] = useState<'idle' | 'recording' | 'paused' | 'saving'>('idle');
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [chunkCount, setChunkCount] = useState(0);
  const [savedBytes, setSavedBytes] = useState(0);
  const [micError, setMicError] = useState<string | null>(null);
  const [noAudioWarning, setNoAudioWarning] = useState(false);
  const [speechStatus, setSpeechStatus] = useState<string>('Siap');
  const [interimText, setInterimText] = useState('');
  const [liveSegments, setLiveSegments] = useState<TranscriptSegment[]>([]);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioSessionRef = useRef<LiveAudioSession | null>(null);
  const speechSessionRef = useRef<SpeechSessionController | null>(null);
  const activeMeetingIdRef = useRef<string>('');
  const elapsedRef = useRef<number>(0);
  const chunkCountRef = useRef<number>(0);
  const savedBytesRef = useRef<number>(0);
  const animFrameRef = useRef<number | null>(null);
  const timerIntervalRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const recorderCaps = useMemo(() => detectRecorderCapabilities(), []);
  const speechCaps = useMemo(() => checkSpeechRecognitionSupport(), []);
  const allCategories = useMemo(
    () => Array.from(new Set([...DEFAULT_CATEGORIES, ...(settings.customCategories || [])])),
    [settings.customCategories]
  );

  useEffect(() => {
    const isActive = recStatus === 'recording' || recStatus === 'paused';
    onRecordingActiveChange(isActive, formatDurationHMS(elapsedSeconds));
  }, [recStatus, elapsedSeconds, onRecordingActiveChange]);

  // Warn before leaving page while active recording exists
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (recStatus === 'recording' || recStatus === 'paused') {
        e.preventDefault();
        e.returnValue =
          'Rekaman rapat masih berlangsung. Keluar sekarang dapat menghentikan proses perekaman.';
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [recStatus]);

  // Clean up on unmount if still active
  useEffect(() => {
    return () => {
      if (timerIntervalRef.current !== null) clearInterval(timerIntervalRef.current);
      if (animFrameRef.current !== null) cancelAnimationFrame(animFrameRef.current);
      speechSessionRef.current?.stop();
      audioSessionRef.current?.cleanup();
    };
  }, []);

  const drawVisualizer = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    const session = audioSessionRef.current;
    const freqData = session && recStatus === 'recording' ? session.getFrequencyData() : new Uint8Array(0);
    if (session && recStatus === 'recording') {
      session.getSignalPeak();
    }

    const barCount = 42;
    const gap = 4;
    const barWidth = Math.max(3, (width - gap * (barCount - 1)) / barCount);

    for (let i = 0; i < barCount; i += 1) {
      let amplitude = 0.06;
      if (freqData.length > 0 && recStatus === 'recording') {
        const binIdx = Math.min(freqData.length - 1, Math.floor((i / barCount) * freqData.length));
        amplitude = Math.max(0.06, freqData[binIdx] / 255);
      }
      const barH = Math.max(4, amplitude * (height - 12));
      const x = i * (barWidth + gap);
      const y = (height - barH) / 2;

      ctx.fillStyle =
        recStatus === 'recording'
          ? amplitude > 0.28
            ? '#10B981'
            : '#059669'
          : recStatus === 'paused'
            ? '#D97706'
            : '#334155';

      ctx.beginPath();
      ctx.roundRect(x, y, barWidth, barH, 3);
      ctx.fill();
    }

    if (recStatus === 'recording' || recStatus === 'paused') {
      animFrameRef.current = requestAnimationFrame(drawVisualizer);
    }
  };

  useEffect(() => {
    drawVisualizer();
    if (recStatus === 'recording' || recStatus === 'paused') {
      animFrameRef.current = requestAnimationFrame(drawVisualizer);
    }
    return () => {
      if (animFrameRef.current !== null) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
    };
  }, [recStatus]);

  const startTimer = () => {
    if (timerIntervalRef.current !== null) clearInterval(timerIntervalRef.current);
    timerIntervalRef.current = window.setInterval(() => {
      elapsedRef.current += 1;
      setElapsedSeconds(elapsedRef.current);

      if (
        elapsedRef.current === 8 &&
        audioSessionRef.current &&
        !audioSessionRef.current.hasDetectedSignal()
      ) {
        setNoAudioWarning(true);
      } else if (
        audioSessionRef.current &&
        audioSessionRef.current.hasDetectedSignal()
      ) {
        setNoAudioWarning(false);
      }
    }, 1000);
  };

  const stopTimer = () => {
    if (timerIntervalRef.current !== null) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
  };

  const handleAddCategory = async () => {
    const trimmed = newCategoryInput.trim();
    if (!trimmed) return;
    await onAddCustomCategory(trimmed);
    setCategory(trimmed);
    setNewCategoryInput('');
    setShowNewCategory(false);
    onToast('success', 'Kategori ditambahkan', trimmed);
  };

  const handleStartRecording = async () => {
    setMicError(null);
    setNoAudioWarning(false);

    if (!recorderCaps.supported) {
      setMicError(recorderCaps.reason || 'Rekaman tidak didukung oleh browser ini.');
      return;
    }

    const meetingId = generateId('mtg');
    activeMeetingIdRef.current = meetingId;
    elapsedRef.current = 0;
    chunkCountRef.current = 0;
    savedBytesRef.current = 0;
    setElapsedSeconds(0);
    setChunkCount(0);
    setSavedBytes(0);
    setLiveSegments([]);
    setInterimText('');

    const effectiveTitle =
      title.trim() || `Rapat ${date} ${startTime}`;

    try {
      const session = await startAudioCapture({
        timesliceMs: 4000,
        onChunk: async (blob, seq) => {
          await saveAudioChunk({
            id: `${meetingId}_${seq}`,
            meetingId,
            seq,
            blob,
            size: blob.size,
            mimeType: blob.type || session.mimeType,
            createdAt: Date.now(),
          });
          chunkCountRef.current += 1;
          savedBytesRef.current += blob.size;
          setChunkCount(chunkCountRef.current);
          setSavedBytes(savedBytesRef.current);
          await saveRecordingDraftMeta({
            meetingId,
            title: effectiveTitle,
            activityName: activityName.trim(),
            category,
            date,
            startTime,
            location: location.trim(),
            notes: notes.trim(),
            mimeType: session.mimeType,
            durationSeconds: elapsedRef.current,
            chunkCount: chunkCountRef.current,
            byteSize: savedBytesRef.current,
            updatedAt: new Date().toISOString(),
          });
        },
        onError: (msg) => {
          setMicError(msg);
          onToast('error', 'Kendala Rekaman', msg);
        },
      });

      audioSessionRef.current = session;
      setRecStatus('recording');
      startTimer();

      if (useWebSpeech && speechCaps.supported) {
        const speechCtrl = startBrowserSpeechRecognition({
          language: speechLang,
          onInterim: (txt) => setInterimText(txt),
          onFinal: (txt) => {
            setLiveSegments((prev) => [
              ...prev,
              {
                id: generateId('seg'),
                timestampSeconds: elapsedRef.current,
                speaker: 'Pembicara 1',
                text: txt,
              },
            ]);
          },
          onStatusChange: (st) => {
            const labels: Record<string, string> = {
              listening: `Mendengarkan (${speechLang})`,
              paused: 'Transkripsi dijeda',
              restarting: 'Menyambung ulang...',
              stopped: 'Berhenti',
              error: 'Gagal',
            };
            setSpeechStatus(labels[st] || st);
          },
          onError: (msg) => {
            onToast('warning', 'Info Transkripsi Browser', msg);
          },
        });
        speechSessionRef.current = speechCtrl;
      } else {
        setSpeechStatus(
          useWebSpeech ? 'Tidak didukung browser' : 'Mode Audio Saja'
        );
      }

      onToast('info', 'Perekaman dimulai', 'Audio disimpan bertahap ke IndexedDB.');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Gagal memulai mikrofon.';
      setMicError(msg);
      onToast('error', 'Mikrofon tidak dapat diakses', msg);
    }
  };

  const handlePause = () => {
    if (recStatus !== 'recording' || !audioSessionRef.current) return;
    if (audioSessionRef.current.recorder.state === 'recording') {
      audioSessionRef.current.recorder.pause();
    }
    speechSessionRef.current?.pause();
    stopTimer();
    setRecStatus('paused');
  };

  const handleResume = () => {
    if (recStatus !== 'paused' || !audioSessionRef.current) return;
    if (audioSessionRef.current.recorder.state === 'paused') {
      audioSessionRef.current.recorder.resume();
    }
    speechSessionRef.current?.resume();
    startTimer();
    setRecStatus('recording');
  };

  const handleStopAndSave = async () => {
    if (recStatus !== 'recording' && recStatus !== 'paused') return;
    setRecStatus('saving');
    stopTimer();
    speechSessionRef.current?.stop();
    speechSessionRef.current = null;

    const session = audioSessionRef.current;
    const meetingId = activeMeetingIdRef.current;
    const detectedSignal = session ? session.hasDetectedSignal() : false;

    if (session) {
      await new Promise<void>((resolve) => {
        const rec = session.recorder;
        if (rec.state === 'inactive') {
          resolve();
          return;
        }
        const onStop = () => {
          rec.removeEventListener('stop', onStop);
          setTimeout(resolve, 250);
        };
        rec.addEventListener('stop', onStop);
        try {
          rec.requestData();
        } catch {
          // ignore
        }
        rec.stop();
      });
      session.cleanup();
      audioSessionRef.current = null;
    }

    try {
      const assembled = await assembleMeetingAudio(
        meetingId,
        session?.mimeType || 'audio/webm'
      );

      if (!assembled.blob || assembled.byteSize === 0) {
        setRecStatus('idle');
        setMicError(
          'Perangkat tidak menghasilkan data audio apa pun. Pastikan mikrofon berfungsi sebelum merekam.'
        );
        return;
      }

      if (!detectedSignal && elapsedRef.current >= 5) {
        onToast(
          'warning',
          'Sinyal suara sangat lemah / senyap',
          'Rekaman tersimpan, tetapi mikrofon tampak tidak menangkap suara yang jelas.'
        );
      }

      const finalTitle = title.trim() || `Rapat ${date} ${startTime}`;
      const record: MeetingRecord = {
        id: meetingId,
        title: finalTitle,
        activityName: activityName.trim(),
        category,
        date,
        startTime,
        location: location.trim(),
        notes: notes.trim(),
        durationSeconds: elapsedRef.current,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        recordingState: 'completed',
        transcriptionStatus: liveSegments.length > 0 ? 'draft_browser' : 'belum_ada',
        documentStatus: 'belum_ada',
        hasAudio: true,
        audioMimeType: assembled.mimeType,
        audioByteSize: assembled.byteSize,
        audioChunkCount: assembled.chunkCount,
        transcriptionSegmentsBackup: undefined,
        transcriptSegments: liveSegments,
        notulen: null,
        summaryText: '',
        decisions: [],
        actionItems: [],
        discussionTopics: [],
        reportOutput: null,
        letterKind: 'tindak_lanjut',
        letterOutput: '',
        ideasOutput: [],
        presentationOutline: [],
      } as MeetingRecord;

      const saved = await saveMeeting(record);
      await deleteRecordingDraftMeta(meetingId);
      await onRefreshDrafts();
      setRecStatus('idle');
      onToast('success', 'Rekaman rapat tersimpan', `${saved.title} (${formatFileSize(saved.audioByteSize)})`);
      onMeetingSaved(saved);
    } catch (err) {
      setRecStatus('idle');
      const msg = err instanceof Error ? err.message : 'Gagal menyimpan rekaman ke IndexedDB.';
      setMicError(msg);
      onToast('error', 'Penyimpanan gagal', msg);
    }
  };

  const handleCreateManualMeeting = async () => {
    const finalTitle = title.trim();
    if (!finalTitle) {
      setMicError('Masukkan Judul Rapat terlebih dahulu sebelum membuat catatan rapat.');
      return;
    }

    try {
      const id = generateId('mtg');
      const record: MeetingRecord = {
        id,
        title: finalTitle,
        activityName: activityName.trim(),
        category,
        date,
        startTime,
        location: location.trim(),
        notes: notes.trim(),
        durationSeconds: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        recordingState: 'manual_entry',
        transcriptionStatus: 'manual',
        documentStatus: 'belum_ada',
        hasAudio: false,
        audioMimeType: '',
        audioByteSize: 0,
        audioChunkCount: 0,
        transcriptSegments: [],
        notulen: null,
        summaryText: '',
        decisions: [],
        actionItems: [],
        discussionTopics: [],
        reportOutput: null,
        letterKind: 'tindak_lanjut',
        letterOutput: '',
        ideasOutput: [],
        presentationOutline: [],
      };
      const saved = await saveMeeting(record);
      onToast('success', 'Catatan rapat dibuat', 'Anda dapat mengetik transkrip atau menyusun notulen sekarang.');
      onMeetingSaved(saved);
    } catch (err) {
      onToast(
        'error',
        'Gagal membuat rapat',
        err instanceof Error ? err.message : 'Transaksi IndexedDB gagal.'
      );
    }
  };

  const handleAudioFileUpload = async (ev: React.ChangeEvent<HTMLInputElement>) => {
    const file = ev.target.files?.[0];
    ev.target.value = '';
    if (!file) return;

    if (!file.type.startsWith('audio/') && !file.name.match(/\.(mp3|wav|m4a|webm|ogg)$/i)) {
      onToast('error', 'Format file tidak didukung', 'Pilih file audio (MP3, WAV, M4A, OGG, atau WEBM).');
      return;
    }

    try {
      const id = generateId('mtg');
      const mimeType = file.type || 'audio/webm';
      await saveAudioChunk({
        id: `${id}_0`,
        meetingId: id,
        seq: 0,
        blob: file,
        size: file.size,
        mimeType,
        createdAt: Date.now(),
      });

      const record: MeetingRecord = {
        id,
        title: title.trim() || file.name.replace(/\.[^.]+$/, ''),
        activityName: activityName.trim(),
        category,
        date,
        startTime,
        location: location.trim(),
        notes: notes.trim(),
        durationSeconds: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        recordingState: 'completed',
        transcriptionStatus: 'belum_ada',
        documentStatus: 'belum_ada',
        hasAudio: true,
        audioMimeType: mimeType,
        audioByteSize: file.size,
        audioChunkCount: 1,
        transcriptSegments: [],
        notulen: null,
        summaryText: '',
        decisions: [],
        actionItems: [],
        discussionTopics: [],
        reportOutput: null,
        letterKind: 'tindak_lanjut',
        letterOutput: '',
        ideasOutput: [],
        presentationOutline: [],
      };

      const saved = await saveMeeting(record);
      onToast('success', 'File audio diimpor', `${file.name} (${formatFileSize(file.size)}) tersimpan lokal.`);
      onMeetingSaved(saved);
    } catch (err) {
      onToast(
        'error',
        'Impor audio gagal',
        err instanceof Error ? err.message : 'Gagal menyimpan file audio ke IndexedDB.'
      );
    }
  };

  const handleRecoverDraft = async (draft: RecordingDraftMeta) => {
    try {
      const assembled = await assembleMeetingAudio(draft.meetingId, draft.mimeType);
      if (!assembled.blob || assembled.byteSize === 0) {
        await deleteRecordingDraftMeta(draft.meetingId);
        await onRefreshDrafts();
        onToast('warning', 'Draft kosong', 'Tidak ada chunk audio yang tersisa untuk dipulihkan.');
        return;
      }

      const recovered: MeetingRecord = {
        id: draft.meetingId,
        title: draft.title || 'Rekaman Dipulihkan',
        activityName: draft.activityName,
        category: draft.category || 'Lainnya',
        date: draft.date,
        startTime: draft.startTime,
        location: draft.location,
        notes: draft.notes,
        durationSeconds: draft.durationSeconds,
        createdAt: draft.updatedAt,
        updatedAt: new Date().toISOString(),
        recordingState: 'recovered',
        transcriptionStatus: 'belum_ada',
        documentStatus: 'belum_ada',
        hasAudio: true,
        audioMimeType: assembled.mimeType,
        audioByteSize: assembled.byteSize,
        audioChunkCount: assembled.chunkCount,
        transcriptSegments: [],
        notulen: null,
        summaryText: '',
        decisions: [],
        actionItems: [],
        discussionTopics: [],
        reportOutput: null,
        letterKind: 'tindak_lanjut',
        letterOutput: '',
        ideasOutput: [],
        presentationOutline: [],
      };

      const saved = await saveMeeting(recovered);
      await deleteRecordingDraftMeta(draft.meetingId);
      await onRefreshDrafts();
      onToast('success', 'Rekaman berhasil dipulihkan', saved.title);
      onMeetingSaved(saved);
    } catch (err) {
      onToast(
        'error',
        'Pemulihan gagal',
        err instanceof Error ? err.message : 'Gagal menyusun ulang audio draft.'
      );
    }
  };

  const handleDiscardDraft = async (draftId: string) => {
    await deleteAudioChunksForMeeting(draftId);
    await deleteRecordingDraftMeta(draftId);
    await onRefreshDrafts();
    onToast('info', 'Draft rekaman dihapus');
  };

  const isLocked = recStatus !== 'idle';

  return (
    <div className="space-y-6">
      {/* Crash / Unfinished Chunk Recovery Banner */}
      {recoverableDrafts.length > 0 && (
        <section className="rounded-2xl border border-amber-500/35 bg-amber-500/10 p-5">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-amber-700 dark:text-amber-300 font-semibold text-sm">
                <RotateCcw className="h-4 w-4" aria-hidden="true" />
                <span>Ditemukan {recoverableDrafts.length} rekaman belum selesai di IndexedDB</span>
              </div>
              <p className="text-xs text-amber-800/90 dark:text-amber-200/90">
                Sesi sebelumnya terhenti sebelum disimpan. Anda dapat memulihkan potongan audio
                yang sudah terekam.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {recoverableDrafts.map((d) => (
                <div key={d.meetingId} className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleRecoverDraft(d)}
                    className="rounded-xl bg-amber-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-amber-500"
                  >
                    Pulihkan &ldquo;{d.title}&rdquo; ({formatFileSize(d.byteSize)})
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDiscardDraft(d.meetingId)}
                    aria-label={`Buang draft ${d.title}`}
                    className="rounded-xl border border-amber-600/40 p-2 text-amber-700 hover:bg-amber-500/20 dark:text-amber-300"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Main Split Grid: Metadata Form + Studio Recorder Panel */}
      <div className="grid gap-6 lg:grid-cols-12">
        {/* Left: Meeting Info Form */}
        <section className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-5 dark:border-slate-800/90 dark:bg-[#131A26]/85">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Informasi Rapat & Kegiatan
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Lengkapi detail dasar untuk memudahkan penyusunan notulen dan pencarian riwayat.
          </p>

          <div className="mt-5 space-y-4">
            <div>
              <label
                htmlFor="rec-title"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Judul Rapat / Agenda Utama
              </label>
              <input
                id="rec-title"
                type="text"
                value={title}
                disabled={isLocked}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Misal: Rapat Evaluasi Digitalisasi Sekolah"
                className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-500 focus:outline-none disabled:opacity-60 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
              />
            </div>

            <div>
              <label
                htmlFor="rec-activity"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Nama Kegiatan (Opsional)
              </label>
              <input
                id="rec-activity"
                type="text"
                value={activityName}
                disabled={isLocked}
                onChange={(e) => setActivityName(e.target.value)}
                placeholder="Misal: Pendampingan Implementasi Kurikulum"
                className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-500 focus:outline-none disabled:opacity-60 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
              />
            </div>

            <div>
              <div className="flex items-center justify-between">
                <label
                  htmlFor="rec-category"
                  className="block text-xs font-medium text-slate-700 dark:text-slate-300"
                >
                  Kategori Kegiatan
                </label>
                {!isLocked && (
                  <button
                    type="button"
                    onClick={() => setShowNewCategory((v) => !v)}
                    className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 hover:text-emerald-500 dark:text-emerald-400"
                  >
                    <Plus className="h-3 w-3" aria-hidden="true" />
                    <span>Tambah Kategori</span>
                  </button>
                )}
              </div>
              <select
                id="rec-category"
                value={category}
                disabled={isLocked}
                onChange={(e) => setCategory(e.target.value)}
                className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-emerald-500 focus:outline-none disabled:opacity-60 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
              >
                {allCategories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>

              {showNewCategory && !isLocked && (
                <div className="mt-2 flex gap-2">
                  <input
                    type="text"
                    value={newCategoryInput}
                    onChange={(e) => setNewCategoryInput(e.target.value)}
                    placeholder="Nama kategori baru"
                    aria-label="Nama kategori baru"
                    className="flex-1 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
                  />
                  <button
                    type="button"
                    onClick={handleAddCategory}
                    className="rounded-xl bg-emerald-600 px-3 py-2 text-xs font-semibold text-white hover:bg-emerald-500"
                  >
                    Simpan
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label
                  htmlFor="rec-date"
                  className="block text-xs font-medium text-slate-700 dark:text-slate-300"
                >
                  Tanggal
                </label>
                <input
                  id="rec-date"
                  type="date"
                  value={date}
                  disabled={isLocked}
                  onChange={(e) => setDate(e.target.value)}
                  className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-emerald-500 focus:outline-none disabled:opacity-60 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
                />
              </div>
              <div>
                <label
                  htmlFor="rec-time"
                  className="block text-xs font-medium text-slate-700 dark:text-slate-300"
                >
                  Waktu Mulai
                </label>
                <input
                  id="rec-time"
                  type="time"
                  value={startTime}
                  disabled={isLocked}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-emerald-500 focus:outline-none disabled:opacity-60 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="rec-location"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Lokasi / Tautan Rapat
              </label>
              <input
                id="rec-location"
                type="text"
                value={location}
                disabled={isLocked}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Misal: Ruang Aula / Google Meet"
                className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-500 focus:outline-none disabled:opacity-60 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
              />
            </div>

            <div>
              <label
                htmlFor="rec-notes"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Catatan Awal / Tujuan Singkat
              </label>
              <textarea
                id="rec-notes"
                rows={3}
                value={notes}
                disabled={isLocked}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Catatan singkat agenda atau peserta..."
                className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-500 focus:outline-none disabled:opacity-60 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
              />
            </div>
          </div>
        </section>

        {/* Right: Audio Capture, Visualizer, Controls & Live Transcript */}
        <section className="flex flex-col gap-6 lg:col-span-7">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800/90 dark:bg-[#131A26]/85">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  Studio Rekaman Audio
                </h2>
                <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  {recStatus === 'recording'
                    ? 'Mikrofon aktif · Potongan audio disimpan bertahap ke IndexedDB'
                    : recStatus === 'paused'
                      ? 'Rekaman dijeda sementara'
                      : recStatus === 'saving'
                        ? 'Menyusun dan menyimpan rekaman...'
                        : 'Siap merekam via MediaRecorder API'}
                </p>
              </div>
              <div
                aria-label="Durasi rekaman"
                className="font-mono-tabular text-2xl font-semibold tracking-tight text-slate-900 sm:text-3xl dark:text-slate-50"
              >
                {formatDurationHMS(elapsedSeconds)}
              </div>
            </div>

            {/* Real Web Audio API Visualizer Canvas */}
            <div className="mt-5 rounded-xl border border-slate-200 bg-slate-950 p-4 dark:border-slate-800">
              <canvas
                ref={canvasRef}
                data-testid="audio-visualizer"
                width={560}
                height={96}
                className="h-24 w-full"
              />
              <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                <span>
                  Chunk tersimpan: <strong className="font-mono-tabular text-slate-200">{chunkCount}</strong>{' '}
                  · Ukuran: <strong className="font-mono-tabular text-slate-200">{formatFileSize(savedBytes)}</strong>
                </span>
                <span>
                  Transkripsi Browser: <strong className="text-slate-200">{speechStatus}</strong>
                </span>
              </div>
            </div>

            {/* Error / Permission / Silence Alerts */}
            {micError && (
              <div
                role="alert"
                className="mt-4 flex items-start gap-2.5 rounded-xl border border-rose-500/30 bg-rose-500/10 p-3.5 text-xs text-rose-800 dark:text-rose-200"
              >
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-rose-500" aria-hidden="true" />
                <span>{micError}</span>
              </div>
            )}

            {noAudioWarning && recStatus === 'recording' && (
              <div
                role="status"
                className="mt-4 flex items-start gap-2.5 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3.5 text-xs text-amber-800 dark:text-amber-200"
              >
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" aria-hidden="true" />
                <span>
                  Belum terdeteksi sinyal suara dari mikrofon. Periksa apakah mikrofon Anda
                  terpasang, tidak di-mute, atau pilih input mikrofon yang benar pada perangkat.
                </span>
              </div>
            )}

            {/* Speech Mode Toggle */}
            <div className="mt-5 flex flex-col gap-3 rounded-xl border border-slate-200/80 bg-slate-50/70 p-4 sm:flex-row sm:items-center sm:justify-between dark:border-slate-800 dark:bg-[#0B0F17]/60">
              <div className="space-y-0.5">
                <label className="flex items-center gap-2 text-xs font-medium text-slate-800 dark:text-slate-200">
                  <input
                    type="checkbox"
                    checked={useWebSpeech}
                    disabled={isLocked || !speechCaps.supported}
                    onChange={(e) => setUseWebSpeech(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300 accent-emerald-600"
                  />
                  <span>Aktifkan Transkripsi Langsung (Web Speech API)</span>
                </label>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  {speechCaps.supported
                    ? 'Mengubah suara menjadi teks bertahap saat merekam (memerlukan layanan browser).'
                    : speechCaps.reason}
                </p>
              </div>
              {speechCaps.supported && useWebSpeech && (
                <select
                  aria-label="Bahasa transkripsi langsung"
                  value={speechLang}
                  disabled={isLocked}
                  onChange={(e) => setSpeechLang(e.target.value)}
                  className="rounded-xl border border-slate-300 bg-white px-3 py-1.5 text-xs text-slate-800 dark:border-slate-700 dark:bg-[#131A26] dark:text-slate-200"
                >
                  <option value="id-ID">Bahasa Indonesia (id-ID)</option>
                  <option value="en-US">English (en-US)</option>
                  <option value="ms-MY">Bahasa Melayu (ms-MY)</option>
                </select>
              )}
            </div>

            {/* Primary Recorder Action Buttons */}
            <div className="mt-5 flex flex-wrap items-center gap-3">
              {recStatus === 'idle' && (
                <>
                  <button
                    type="button"
                    onClick={handleStartRecording}
                    className="inline-flex h-11 items-center gap-2 rounded-xl bg-emerald-600 px-5 text-sm font-semibold text-white transition-colors hover:bg-emerald-500"
                  >
                    <Mic className="h-4 w-4" aria-hidden="true" />
                    <span>Mulai Rekam</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-200 dark:hover:bg-slate-800"
                  >
                    <FileAudio className="h-4 w-4" aria-hidden="true" />
                    <span>Impor File Audio</span>
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="audio/*,.mp3,.wav,.m4a,.webm,.ogg"
                    onChange={handleAudioFileUpload}
                    className="hidden"
                  />

                  <button
                    type="button"
                    onClick={handleCreateManualMeeting}
                    className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-200 dark:hover:bg-slate-800"
                  >
                    <FilePlus2 className="h-4 w-4" aria-hidden="true" />
                    <span>Buat Catatan Tanpa Audio</span>
                  </button>
                </>
              )}

              {recStatus === 'recording' && (
                <>
                  <button
                    type="button"
                    onClick={handlePause}
                    className="inline-flex h-11 items-center gap-2 rounded-xl border border-amber-500/40 bg-amber-500/15 px-5 text-sm font-semibold text-amber-700 hover:bg-amber-500/25 dark:text-amber-300"
                  >
                    <Pause className="h-4 w-4" aria-hidden="true" />
                    <span>Jeda</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleStopAndSave}
                    className="inline-flex h-11 items-center gap-2 rounded-xl bg-rose-600 px-5 text-sm font-semibold text-white hover:bg-rose-500"
                  >
                    <Square className="h-4 w-4" aria-hidden="true" />
                    <span>Selesai & Simpan</span>
                  </button>
                </>
              )}

              {recStatus === 'paused' && (
                <>
                  <button
                    type="button"
                    onClick={handleResume}
                    className="inline-flex h-11 items-center gap-2 rounded-xl bg-emerald-600 px-5 text-sm font-semibold text-white hover:bg-emerald-500"
                  >
                    <Play className="h-4 w-4" aria-hidden="true" />
                    <span>Lanjutkan</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleStopAndSave}
                    className="inline-flex h-11 items-center gap-2 rounded-xl bg-rose-600 px-5 text-sm font-semibold text-white hover:bg-rose-500"
                  >
                    <Square className="h-4 w-4" aria-hidden="true" />
                    <span>Selesai & Simpan</span>
                  </button>
                </>
              )}

              {recStatus === 'saving' && (
                <p className="text-sm font-medium text-emerald-600 dark:text-emerald-400">
                  Menyusun potongan audio dan menyimpan ke IndexedDB...
                </p>
              )}
            </div>

            <p className="mt-4 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
              Batas durasi bergantung pada kapasitas ruang penyimpanan browser dan memori
              perangkat Anda. Potongan audio disimpan bertahap ke IndexedDB untuk mengurangi risiko
              kehilangan data pada rapat panjang.
            </p>
          </div>

          {/* Live Transcript Output Box */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800/90 dark:bg-[#131A26]/85">
            <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
              Pratinjau Transkrip Langsung
            </h3>
            <div className="mt-3 max-h-56 overflow-y-auto rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs leading-relaxed dark:border-slate-800 dark:bg-[#0B0F17]">
              {liveSegments.length === 0 && !interimText ? (
                <p className="text-slate-500 dark:text-slate-400">
                  Hasil transkripsi Web Speech API akan muncul di sini secara bertahap saat Anda
                  merekam. Jika browser tidak mendukungnya, Anda tetap bisa merekam audio dan
                  mengedit transkrip setelahnya.
                </p>
              ) : (
                <div className="space-y-2">
                  {liveSegments.map((seg) => (
                    <p key={seg.id} className="text-slate-800 dark:text-slate-200">
                      <span className="font-mono-tabular text-emerald-600 dark:text-emerald-400">
                        [{formatDurationHMS(seg.timestampSeconds ?? 0)}]
                      </span>{' '}
                      <span className="font-semibold">{seg.speaker}:</span> {seg.text}
                    </p>
                  ))}
                  {interimText && (
                    <p className="italic text-slate-500 dark:text-slate-400">{interimText}</p>
                  )}
                </div>
              )}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
