import React, { useMemo, useState } from 'react';
import { MessageSquareText, Search, Send, Settings } from 'lucide-react';
import { AppSettings, MeetingRecord } from '../types/meeting';
import { formatDateID, formatDurationHMS } from '../utils/formatters';
import { searchTranscriptLocal } from '../utils/meetingLogic';
import { askMeetingAssistant } from '../services/geminiClient';

interface AssistantViewProps {
  meetings: MeetingRecord[];
  settings: AppSettings;
  hasAiKey: boolean;
  initialMeetingId?: string | null;
  onNavigateSettings: () => void;
  onOpenMeeting: (id: string) => void;
}

interface QAMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
}

export const AssistantView: React.FC<AssistantViewProps> = ({
  meetings,
  settings,
  hasAiKey,
  initialMeetingId,
  onNavigateSettings,
  onOpenMeeting,
}) => {
  const [selectedId, setSelectedId] = useState<string>(
    initialMeetingId || meetings[0]?.id || ''
  );
  const [queryInput, setQueryInput] = useState('');
  const [localKeyword, setLocalKeyword] = useState('');
  const [messages, setMessages] = useState<QAMessage[]>([]);
  const [isAsking, setIsAsking] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const selectedMeeting = useMemo(
    () => meetings.find((m) => m.id === selectedId) || meetings[0] || null,
    [meetings, selectedId]
  );

  const localMatches = useMemo(() => {
    if (!selectedMeeting || !localKeyword.trim()) return [];
    return searchTranscriptLocal(selectedMeeting, localKeyword);
  }, [selectedMeeting, localKeyword]);

  const suggestedQuestions = [
    'Apa saja poin penting dalam rapat ini?',
    'Keputusan apa saja yang sudah disepakati?',
    'Siapa saja PIC dan apa tindak lanjutnya?',
    'Apakah ada kendala atau pembahasan anggaran/digitalisasi?',
  ];

  const handleAskAI = async (questionText?: string) => {
    const q = (questionText ?? queryInput).trim();
    if (!q || !selectedMeeting) return;
    setErrorMsg(null);
    setQueryInput('');

    const userMsg: QAMessage = {
      id: `u_${Date.now()}`,
      role: 'user',
      text: q,
    };
    setMessages((prev) => [...prev, userMsg]);
    setIsAsking(true);

    try {
      const answer = await askMeetingAssistant({
        meeting: selectedMeeting,
        question: q,
        model: settings.geminiModel,
      });
      setMessages((prev) => [
        ...prev,
        { id: `a_${Date.now()}`, role: 'assistant', text: answer },
      ]);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Gagal menghubungi Gemini AI.';
      setErrorMsg(msg);
    } finally {
      setIsAsking(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Status & Meeting Selector */}
      <section className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800/90 dark:bg-[#131A26]/85">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
              AI Tanya Rapat & Pencarian Transkrip
            </h2>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              {hasAiKey
                ? `Gemini AI aktif (${settings.geminiModel}) — jawaban hanya berdasar transkrip rapat yang dipilih.`
                : 'AI belum tersedia pada sesi ini. Gunakan pencarian kata kunci lokal pada transkrip di bawah.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <select
              aria-label="Pilih rapat untuk ditanyakan"
              value={selectedMeeting?.id || ''}
              onChange={(e) => {
                setSelectedId(e.target.value);
                setMessages([]);
                setErrorMsg(null);
              }}
              className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-sm text-slate-900 sm:w-72 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
            >
              {meetings.length === 0 ? (
                <option value="">Belum ada rapat tersimpan</option>
              ) : (
                meetings.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.title} ({formatDateID(m.date)})
                  </option>
                ))
              )}
            </select>

            {selectedMeeting && (
              <button
                type="button"
                onClick={() => onOpenMeeting(selectedMeeting.id)}
                className="rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                Buka Dokumen Rapat
              </button>
            )}
          </div>
        </div>
      </section>

      {!selectedMeeting ? (
        <section className="rounded-2xl border border-slate-200 bg-white p-10 text-center dark:border-slate-800/90 dark:bg-[#131A26]/85">
          <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
            Belum ada rapat yang dapat dianalisis
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Rekam atau muat contoh rapat terlebih dahulu di halaman Beranda atau Rekam Rapat.
          </p>
        </section>
      ) : (
        <div className="grid gap-6 lg:grid-cols-12">
          {/* Manual Local Transcript Search (Always Available Offline) */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-5 dark:border-slate-800/90 dark:bg-[#131A26]/85">
            <div className="flex items-center gap-2">
              <Search className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
              <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                Pencarian Manual dalam Transkrip
              </h3>
            </div>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Berjalan 100% lokal tanpa internet dan tanpa API Key.
            </p>

            <div className="mt-4">
              <input
                type="search"
                value={localKeyword}
                onChange={(e) => setLocalKeyword(e.target.value)}
                placeholder="Ketik kata kunci (misal: anggaran, jadwal, PIC)..."
                aria-label="Cari kata kunci dalam transkrip"
                className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-500 focus:outline-none dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
              />
            </div>

            <div className="mt-4 max-h-80 overflow-y-auto space-y-2.5">
              {selectedMeeting.transcriptSegments.length === 0 ? (
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Transkrip pada rapat ini masih kosong.
                </p>
              ) : !localKeyword.trim() ? (
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Masukkan kata kunci untuk menemukan kutipan beserta timestamp dari{' '}
                  <span className="tabular-nums">{selectedMeeting.transcriptSegments.length}</span>{' '}
                  baris transkrip.
                </p>
              ) : localMatches.length === 0 ? (
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Informasi tersebut tidak ditemukan dalam transkrip rapat ini.
                </p>
              ) : (
                localMatches.map((seg) => (
                  <div
                    key={seg.id}
                    className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs dark:border-slate-800 dark:bg-[#0B0F17]"
                  >
                    <p className="font-medium text-slate-700 dark:text-slate-300">
                      {seg.timestampSeconds !== null && (
                        <span className="mr-1.5 font-mono-tabular text-emerald-600 dark:text-emerald-400">
                          [{formatDurationHMS(seg.timestampSeconds)}]
                        </span>
                      )}
                      {seg.speaker}
                    </p>
                    <p className="mt-1 leading-relaxed text-slate-800 dark:text-slate-200">
                      {seg.text}
                    </p>
                  </div>
                ))
              )}
            </div>
          </section>

          {/* Optional AI Meeting Assistant Panel */}
          <section className="flex flex-col rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-7 dark:border-slate-800/90 dark:bg-[#131A26]/85">
            <div className="flex items-center justify-between gap-3 border-b border-slate-100 pb-4 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <MessageSquareText
                  className="h-4 w-4 text-emerald-600 dark:text-emerald-400"
                  aria-hidden="true"
                />
                <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                  Asisten Tanya Rapat (Gemini AI Opsional)
                </h3>
              </div>
              {!hasAiKey && (
                <button
                  type="button"
                  onClick={onNavigateSettings}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  <Settings className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Atur API Key</span>
                </button>
              )}
            </div>

            {!hasAiKey ? (
              <div className="flex flex-1 flex-col items-center justify-center py-10 text-center">
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                  AI Tanya Rapat Belum Tersedia
                </p>
                <p className="mt-1.5 max-w-md text-xs leading-relaxed text-slate-500 dark:text-slate-400">
                  Aplikasi tidak menyertakan chatbot palsu. Untuk menggunakan tanya-jawab AI
                  berbasis transkrip, masukkan API Key Gemini Anda secara opsional di Pengaturan
                  AI, atau gunakan panel Pencarian Manual di sebelah kiri.
                </p>
                <button
                  type="button"
                  onClick={onNavigateSettings}
                  className="mt-4 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-500"
                >
                  Buka Pengaturan AI
                </button>
              </div>
            ) : (
              <>
                <div className="mt-4 flex flex-wrap gap-2">
                  {suggestedQuestions.map((q) => (
                    <button
                      key={q}
                      type="button"
                      disabled={isAsking}
                      onClick={() => handleAskAI(q)}
                      className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-300 dark:hover:bg-slate-800"
                    >
                      {q}
                    </button>
                  ))}
                </div>

                <div className="mt-4 flex-1 space-y-3 overflow-y-auto rounded-xl border border-slate-200 bg-slate-50 p-4 min-h-[220px] max-h-80 dark:border-slate-800 dark:bg-[#0B0F17]">
                  {messages.length === 0 ? (
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Ajukan pertanyaan mengenai keputusan, tugas, PIC, kendala, atau ringkasan
                      dari rapat &ldquo;{selectedMeeting.title}&rdquo;.
                    </p>
                  ) : (
                    messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`rounded-xl p-3 text-xs leading-relaxed ${
                          msg.role === 'user'
                            ? 'ml-8 bg-emerald-600 text-white'
                            : 'mr-4 border border-slate-200 bg-white text-slate-800 dark:border-slate-800 dark:bg-[#131A26] dark:text-slate-200'
                        }`}
                      >
                        <p className="whitespace-pre-wrap">{msg.text}</p>
                      </div>
                    ))
                  )}
                  {isAsking && (
                    <p className="text-xs text-emerald-600 dark:text-emerald-400">
                      Memeriksa transkrip rapat dengan Gemini AI...
                    </p>
                  )}
                  {errorMsg && (
                    <p role="alert" className="text-xs text-rose-600 dark:text-rose-400">
                      {errorMsg}
                    </p>
                  )}
                </div>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleAskAI();
                  }}
                  className="mt-4 flex gap-2"
                >
                  <input
                    type="text"
                    value={queryInput}
                    onChange={(e) => setQueryInput(e.target.value)}
                    placeholder="Tulis pertanyaan tentang isi rapat..."
                    aria-label="Pertanyaan untuk AI Meeting Assistant"
                    className="flex-1 rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-emerald-500 focus:outline-none dark:border-slate-700 dark:bg-[#0B0F17] dark:text-slate-100"
                  />
                  <button
                    type="submit"
                    disabled={isAsking || !queryInput.trim()}
                    aria-label="Kirim pertanyaan"
                    className="inline-flex h-11 items-center gap-2 rounded-xl bg-emerald-600 px-4 text-xs font-semibold text-white hover:bg-emerald-500 disabled:opacity-50"
                  >
                    <Send className="h-4 w-4" aria-hidden="true" />
                    <span>Tanya</span>
                  </button>
                </form>
              </>
            )}
          </section>
        </div>
      )}
    </div>
  );
};
