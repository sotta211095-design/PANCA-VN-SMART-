export interface RecorderCapabilities {
  supported: boolean;
  reason?: string;
  mimeType: string;
}

export function detectRecorderCapabilities(): RecorderCapabilities {
  if (typeof window === 'undefined') {
    return { supported: false, reason: 'Lingkungan bukan browser.', mimeType: '' };
  }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    return {
      supported: false,
      reason:
        'Browser atau konteks saat ini tidak mendukung akses mikrofon (getUserMedia). Pastikan mengakses lewat HTTPS atau localhost.',
      mimeType: '',
    };
  }
  if (typeof MediaRecorder === 'undefined') {
    return {
      supported: false,
      reason: 'Browser ini tidak mendukung MediaRecorder API untuk merekam audio.',
      mimeType: '',
    };
  }

  const candidates = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/mp4',
    'audio/ogg;codecs=opus',
    'audio/ogg',
  ];
  const supportedMime =
    candidates.find((mime) => {
      try {
        return MediaRecorder.isTypeSupported(mime);
      } catch {
        return false;
      }
    }) || '';

  return {
    supported: true,
    mimeType: supportedMime,
  };
}

export function mapMediaErrorToIndonesian(err: unknown): string {
  if (err instanceof DOMException) {
    switch (err.name) {
      case 'NotAllowedError':
      case 'PermissionDeniedError':
        return 'Izin mikrofon ditolak. Buka pengaturan izin situs pada browser Anda untuk mengizinkan akses mikrofon, lalu coba lagi.';
      case 'NotFoundError':
      case 'DevicesNotFoundError':
        return 'Perangkat mikrofon tidak ditemukan. Pastikan mikrofon terpasang atau aktif pada perangkat Anda.';
      case 'NotReadableError':
      case 'TrackStartError':
        return 'Mikrofon sedang digunakan oleh aplikasi lain atau tidak dapat dibaca oleh perangkat keras.';
      case 'OverconstrainedError':
        return 'Konfigurasi audio yang diminta tidak didukung oleh mikrofon perangkat Anda.';
      case 'SecurityError':
        return 'Akses mikrofon diblokir oleh kebijakan keamanan browser (membutuhkan HTTPS atau localhost).';
      default:
        return `Gagal mengakses mikrofon (${err.name}): ${err.message}`;
    }
  }
  return err instanceof Error
    ? err.message
    : 'Terjadi kesalahan saat menginisialisasi mikrofon.';
}

export interface LiveAudioSession {
  stream: MediaStream;
  recorder: MediaRecorder;
  audioContext: AudioContext | null;
  analyser: AnalyserNode | null;
  mimeType: string;
  hasDetectedSignal: () => boolean;
  getSignalPeak: () => number;
  getFrequencyData: () => Uint8Array;
  cleanup: () => void;
}

export async function startAudioCapture(options: {
  onChunk: (blob: Blob, seq: number) => Promise<void> | void;
  onError: (message: string) => void;
  timesliceMs?: number;
}): Promise<LiveAudioSession> {
  const caps = detectRecorderCapabilities();
  if (!caps.supported) {
    throw new Error(caps.reason || 'Rekaman audio tidak didukung pada browser ini.');
  }

  let stream: MediaStream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    });
  } catch (err) {
    throw new Error(mapMediaErrorToIndonesian(err));
  }

  const audioTracks = stream.getAudioTracks();
  if (audioTracks.length === 0) {
    stream.getTracks().forEach((t) => t.stop());
    throw new Error('Perangkat tidak menyediakan track audio aktif.');
  }

  let audioContext: AudioContext | null = null;
  let analyser: AnalyserNode | null = null;
  let freqBuffer = new Uint8Array(64);
  let timeBuffer = new Uint8Array(64);
  let signalDetected = false;

  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioCtx) {
      audioContext = new AudioCtx();
      if (audioContext.state === 'suspended') {
        await audioContext.resume().catch(() => undefined);
      }
      const source = audioContext.createMediaStreamSource(stream);
      analyser = audioContext.createAnalyser();
      analyser.fftSize = 128;
      analyser.smoothingTimeConstant = 0.78;
      source.connect(analyser);
      freqBuffer = new Uint8Array(analyser.frequencyBinCount);
      timeBuffer = new Uint8Array(analyser.fftSize);
    }
  } catch {
    audioContext = null;
    analyser = null;
  }

  const recorderOptions: MediaRecorderOptions = {};
  if (caps.mimeType) {
    recorderOptions.mimeType = caps.mimeType;
  }

  let recorder: MediaRecorder;
  try {
    recorder = new MediaRecorder(stream, recorderOptions);
  } catch {
    recorder = new MediaRecorder(stream);
  }

  const actualMime = recorder.mimeType || caps.mimeType || 'audio/webm';
  let seq = 0;

  recorder.ondataavailable = (ev: BlobEvent) => {
    if (ev.data && ev.data.size > 0) {
      const currentSeq = seq;
      seq += 1;
      Promise.resolve(options.onChunk(ev.data, currentSeq)).catch((err) => {
        options.onError(
          err instanceof Error ? err.message : 'Gagal menyimpan potongan audio ke IndexedDB.'
        );
      });
    }
  };

  recorder.onerror = () => {
    options.onError('Terjadi kesalahan pada MediaRecorder saat merekam audio.');
  };

  recorder.start(options.timesliceMs ?? 4000);

  const getSignalPeak = (): number => {
    if (!analyser) return 0;
    analyser.getByteTimeDomainData(timeBuffer);
    let maxDev = 0;
    for (let i = 0; i < timeBuffer.length; i += 1) {
      const dev = Math.abs(timeBuffer[i] - 128);
      if (dev > maxDev) maxDev = dev;
    }
    const normalized = Math.min(1, maxDev / 64);
    if (normalized > 0.015) {
      signalDetected = true;
    }
    return normalized;
  };

  const getFrequencyData = (): Uint8Array => {
    if (!analyser) return new Uint8Array(0);
    analyser.getByteFrequencyData(freqBuffer);
    return freqBuffer;
  };

  const cleanup = () => {
    try {
      if (recorder.state !== 'inactive') {
        recorder.stop();
      }
    } catch {
      // ignore
    }
    stream.getTracks().forEach((track) => {
      try {
        track.stop();
      } catch {
        // ignore
      }
    });
    if (audioContext && audioContext.state !== 'closed') {
      audioContext.close().catch(() => undefined);
    }
  };

  return {
    stream,
    recorder,
    audioContext,
    analyser,
    mimeType: actualMime,
    hasDetectedSignal: () => signalDetected,
    getSignalPeak,
    getFrequencyData,
    cleanup,
  };
}
