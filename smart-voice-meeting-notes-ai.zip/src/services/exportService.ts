import JSZip from 'jszip';
import { MeetingRecord } from '../types/meeting';
import { formatDurationHMS, sanitizeFilename } from '../utils/formatters';
import {
  buildGoogleSheetsCsvPack,
  formatNotulenMarkdownText,
  formatTranscriptText,
  generateTemplateNotulen,
} from '../utils/meetingLogic';

function triggerBlobDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escapeXml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

export function exportAsTXT(
  meeting: MeetingRecord,
  mode: 'transcript' | 'notulen' | 'all'
): void {
  const baseName = sanitizeFilename(meeting.title || 'rapat');
  const notulen = meeting.notulen || generateTemplateNotulen(meeting);
  const transcriptText = formatTranscriptText(meeting.transcriptSegments);
  const notulenText = formatNotulenMarkdownText(notulen, meeting.actionItems);

  let content = '';
  let suffix = 'dokumen';
  if (mode === 'transcript') {
    content = `TRANSKRIP RAPAT: ${meeting.title}\nTanggal: ${meeting.date} | Durasi: ${formatDurationHMS(
      meeting.durationSeconds
    )}\n\n${transcriptText || 'Transkrip masih kosong.'}`;
    suffix = 'transkrip';
  } else if (mode === 'notulen') {
    content = notulenText;
    suffix = 'notulen';
  } else {
    content = `${notulenText}\n\n============================================================\nLAMPIRAN TRANSKRIP LENGKAP\n============================================================\n\n${
      transcriptText || 'Transkrip masih kosong.'
    }`;
    suffix = 'paket-lengkap';
  }

  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  triggerBlobDownload(blob, `${baseName}-${suffix}.txt`);
}

export function buildMeetingHtmlDocument(meeting: MeetingRecord): string {
  const notulen = meeting.notulen || generateTemplateNotulen(meeting);
  const info = notulen.informasiKegiatan;
  const transcriptText = formatTranscriptText(meeting.transcriptSegments);

  const actionRows =
    meeting.actionItems.length > 0
      ? meeting.actionItems
          .map(
            (a, idx) => `
          <tr>
            <td>${idx + 1}</td>
            <td>${escapeHtml(a.task)}</td>
            <td>${escapeHtml(a.pic || 'Belum ditentukan')}</td>
            <td>${escapeHtml(a.deadline || 'Belum ditentukan')}</td>
            <td>${escapeHtml(a.status)}</td>
          </tr>`
          )
          .join('')
      : `<tr><td colspan="5">Belum ada tindak lanjut yang dicatat.</td></tr>`;

  return `<!doctype html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Notulen — ${escapeHtml(meeting.title)}</title>
  <style>
    body { font-family: 'Segoe UI', Arial, sans-serif; color: #0f172a; line-height: 1.6; max-width: 840px; margin: 40px auto; padding: 0 24px; }
    h1 { font-size: 22px; margin-bottom: 4px; border-bottom: 2px solid #0f172a; padding-bottom: 8px; }
    h2 { font-size: 16px; margin-top: 24px; margin-bottom: 8px; color: #0f172a; }
    .meta { color: #475569; font-size: 13px; margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 13px; }
    th, td { border: 1px solid #cbd5e1; padding: 8px 10px; text-align: left; vertical-align: top; }
    th { background: #f1f5f9; font-weight: 600; }
    pre { background: #f8fafc; border: 1px solid #e2e8f0; padding: 14px; white-space: pre-wrap; font-family: Consolas, monospace; font-size: 12px; }
    .note-box { background: #f8fafc; border: 1px solid #cbd5e1; padding: 12px; font-size: 13px; margin-top: 16px; }
    @media print { body { margin: 16px; } }
  </style>
</head>
<body>
  <h1>NOTULEN RAPAT</h1>
  <div class="meta">${escapeHtml(meeting.title)} · ${escapeHtml(meeting.category)} · Durasi ${formatDurationHMS(
    meeting.durationSeconds
  )}</div>

  <h2>A. Informasi Kegiatan</h2>
  <table>
    <tr><th style="width:200px">Nama Kegiatan</th><td>${escapeHtml(info.namaKegiatan)}</td></tr>
    <tr><th>Tanggal</th><td>${escapeHtml(info.tanggal)}</td></tr>
    <tr><th>Waktu</th><td>${escapeHtml(info.waktu)}</td></tr>
    <tr><th>Lokasi</th><td>${escapeHtml(info.lokasi)}</td></tr>
    <tr><th>Agenda</th><td>${escapeHtml(info.agenda)}</td></tr>
    <tr><th>Peserta</th><td>${escapeHtml(info.peserta)}</td></tr>
    <tr><th>Pimpinan</th><td>${escapeHtml(info.pimpinan)}</td></tr>
    <tr><th>Notulis</th><td>${escapeHtml(info.notulis)}</td></tr>
  </table>

  <h2>B. Tujuan Rapat</h2>
  <p>${escapeHtml(notulen.tujuanRapat)}</p>

  <h2>C. Ringkasan Pembahasan</h2>
  <p style="white-space:pre-wrap">${escapeHtml(notulen.ringkasanPembahasan)}</p>

  <h2>D. Pokok Pembahasan</h2>
  <ul>
    ${
      notulen.pokokPembahasan.length > 0
        ? notulen.pokokPembahasan.map((p) => `<li>${escapeHtml(p)}</li>`).join('')
        : '<li>Belum diisi</li>'
    }
  </ul>

  <h2>E. Keputusan dan Kesepakatan</h2>
  <ul>
    ${notulen.keputusanDanKesepakatan.map((k) => `<li>${escapeHtml(k)}</li>`).join('')}
  </ul>

  <h2>F. Tindak Lanjut</h2>
  <table>
    <thead>
      <tr><th>No</th><th>Tindak Lanjut</th><th>PIC</th><th>Tenggat</th><th>Status</th></tr>
    </thead>
    <tbody>${actionRows}</tbody>
  </table>

  <h2>G. Kendala dan Catatan Penting</h2>
  <p>${escapeHtml(notulen.kendalaDanCatatan)}</p>

  <h2>H. Kesimpulan</h2>
  <p>${escapeHtml(notulen.kesimpulan)}</p>

  <h2>I. Catatan Penyusunan</h2>
  <div class="note-box">${escapeHtml(notulen.catatanPenyusunan)}</div>

  ${
    transcriptText
      ? `<h2>Lampiran Transkrip</h2><pre>${escapeHtml(transcriptText)}</pre>`
      : ''
  }
</body>
</html>`;
}

export function exportAsHTML(meeting: MeetingRecord): void {
  const html = buildMeetingHtmlDocument(meeting);
  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  triggerBlobDownload(blob, `${sanitizeFilename(meeting.title)}-notulen.html`);
}

function toCsvString(rows: string[][]): string {
  const escapeCell = (val: string) => {
    const str = String(val ?? '');
    if (/[",\n\r]/.test(str)) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };
  return '\uFEFF' + rows.map((row) => row.map(escapeCell).join(',')).join('\r\n');
}

export function exportAsCSV(
  meeting: MeetingRecord,
  mode: 'actions' | 'decisions' | 'sheets-pack'
): void {
  const baseName = sanitizeFilename(meeting.title || 'rapat');
  const pack = buildGoogleSheetsCsvPack(meeting);

  if (mode === 'actions') {
    const blob = new Blob([toCsvString(pack.sheet2Actions)], {
      type: 'text/csv;charset=utf-8',
    });
    triggerBlobDownload(blob, `${baseName}-tindak-lanjut.csv`);
    return;
  }

  if (mode === 'decisions') {
    const blob = new Blob([toCsvString(pack.sheet3Decisions)], {
      type: 'text/csv;charset=utf-8',
    });
    triggerBlobDownload(blob, `${baseName}-keputusan.csv`);
    return;
  }

  const combinedRows: string[][] = [
    ['=== SHEET 1: INFORMASI RAPAT ==='],
    ...pack.sheet1Info,
    [''],
    ['=== SHEET 2: TINDAK LANJUT ==='],
    ...pack.sheet2Actions,
    [''],
    ['=== SHEET 3: KEPUTUSAN ==='],
    ...pack.sheet3Decisions,
    [''],
    ['=== SHEET 4: PEMBAHASAN ==='],
    ...pack.sheet4Topics,
  ];
  const blob = new Blob([toCsvString(combinedRows)], { type: 'text/csv;charset=utf-8' });
  triggerBlobDownload(blob, `${baseName}-sheets-lengkap.csv`);
}

function makeDocxParagraph(text: string, opts?: { bold?: boolean; heading?: boolean }): string {
  const runProps = opts?.bold || opts?.heading
    ? `<w:rPr><w:b/>${opts?.heading ? '<w:sz w:val="28"/>' : ''}</w:rPr>`
    : '';
  const spacing = opts?.heading
    ? '<w:pPr><w:spacing w:before="200" w:after="100"/></w:pPr>'
    : '<w:pPr><w:spacing w:after="80"/></w:pPr>';
  return `<w:p>${spacing}<w:r>${runProps}<w:t xml:space="preserve">${escapeXml(
    text
  )}</w:t></w:r></w:p>`;
}

function makeDocxTable(rows: string[][]): string {
  const trXml = rows
    .map((row, rowIdx) => {
      const cells = row
        .map(
          (cell) => `<w:tc>
            <w:tcPr><w:tcBorders>
              <w:top w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>
              <w:left w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>
              <w:bottom w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>
              <w:right w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>
            </w:tcBorders></w:tcPr>
            <w:p><w:r>${
              rowIdx === 0 ? '<w:rPr><w:b/></w:rPr>' : ''
            }<w:t xml:space="preserve">${escapeXml(cell)}</w:t></w:r></w:p>
          </w:tc>`
        )
        .join('');
      return `<w:tr>${cells}</w:tr>`;
    })
    .join('');
  return `<w:tbl><w:tblPr><w:tblW w:w="9000" w:type="dxa"/></w:tblPr>${trXml}</w:tbl>`;
}

export async function exportAsDOCX(meeting: MeetingRecord): Promise<void> {
  const zip = new JSZip();
  const notulen = meeting.notulen || generateTemplateNotulen(meeting);
  const info = notulen.informasiKegiatan;
  const pack = buildGoogleSheetsCsvPack(meeting);

  const bodyParts: string[] = [
    makeDocxParagraph('NOTULEN RAPAT', { heading: true, bold: true }),
    makeDocxParagraph(`${meeting.title} (${meeting.category})`, { bold: true }),
    makeDocxParagraph('A. Informasi Kegiatan', { heading: true, bold: true }),
    makeDocxTable([
      ['Field', 'Keterangan'],
      ['Nama Kegiatan', info.namaKegiatan],
      ['Tanggal', info.tanggal],
      ['Waktu', info.waktu],
      ['Lokasi', info.lokasi],
      ['Agenda', info.agenda],
      ['Peserta', info.peserta],
      ['Pimpinan', info.pimpinan],
      ['Notulis', info.notulis],
    ]),
    makeDocxParagraph('B. Tujuan Rapat', { heading: true, bold: true }),
    makeDocxParagraph(notulen.tujuanRapat),
    makeDocxParagraph('C. Ringkasan Pembahasan', { heading: true, bold: true }),
    ...notulen.ringkasanPembahasan.split(/\r?\n/).map((line) => makeDocxParagraph(line)),
    makeDocxParagraph('D. Pokok Pembahasan', { heading: true, bold: true }),
    ...(notulen.pokokPembahasan.length > 0
      ? notulen.pokokPembahasan.map((p, i) => makeDocxParagraph(`${i + 1}. ${p}`))
      : [makeDocxParagraph('Belum diisi')]),
    makeDocxParagraph('E. Keputusan dan Kesepakatan', { heading: true, bold: true }),
    ...notulen.keputusanDanKesepakatan.map((k, i) => makeDocxParagraph(`${i + 1}. ${k}`)),
    makeDocxParagraph('F. Tindak Lanjut', { heading: true, bold: true }),
    makeDocxTable(pack.sheet2Actions),
    makeDocxParagraph('G. Kendala dan Catatan Penting', { heading: true, bold: true }),
    makeDocxParagraph(notulen.kendalaDanCatatan),
    makeDocxParagraph('H. Kesimpulan', { heading: true, bold: true }),
    makeDocxParagraph(notulen.kesimpulan),
    makeDocxParagraph('I. Catatan Penyusunan', { heading: true, bold: true }),
    makeDocxParagraph(notulen.catatanPenyusunan),
  ];

  const transcriptLines = formatTranscriptText(meeting.transcriptSegments);
  if (transcriptLines) {
    bodyParts.push(makeDocxParagraph('Lampiran Transkrip', { heading: true, bold: true }));
    transcriptLines.split(/\r?\n/).forEach((line) => bodyParts.push(makeDocxParagraph(line)));
  }

  const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>${bodyParts.join('')}<w:sectPr/></w:body>
</w:document>`;

  const contentTypesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`;

  const relsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`;

  zip.file('[Content_Types].xml', contentTypesXml);
  zip.folder('_rels')?.file('.rels', relsXml);
  zip.folder('word')?.file('document.xml', documentXml);

  const blob = await zip.generateAsync({
    type: 'blob',
    mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  });
  triggerBlobDownload(blob, `${sanitizeFilename(meeting.title)}-notulen.docx`);
}

export function exportAsPrintPDF(meeting: MeetingRecord): { ok: boolean; error?: string } {
  // Uses a hidden printable iframe rather than window.open (avoids iframe/popup blockers)
  const html = buildMeetingHtmlDocument(meeting);
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (!doc || !iframe.contentWindow) {
    document.body.removeChild(iframe);
    return {
      ok: false,
      error: 'Browser memblokir dialog cetak. Gunakan tombol Unduh HTML lalu cetak / Simpan sebagai PDF.',
    };
  }

  doc.open();
  doc.write(html);
  doc.close();

  setTimeout(() => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch {
      // ignore
    }
    setTimeout(() => {
      if (iframe.parentNode) {
        iframe.parentNode.removeChild(iframe);
      }
    }, 2000);
  }, 250);

  return { ok: true };
}

export function downloadJsonFile(data: unknown, filename: string): void {
  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: 'application/json;charset=utf-8',
  });
  triggerBlobDownload(blob, filename);
}
