import { MeetingRecord } from '../types/meeting';
import {
  buildGoogleSheetsCsvPack,
  formatNotulenMarkdownText,
  generateTemplateNotulen,
} from '../utils/meetingLogic';

// Session-only OAuth access token (never stored in IndexedDB or localStorage)
let sessionGoogleAccessToken = '';
let sessionGoogleTokenExpiry = 0;

interface GoogleTokenResponse {
  access_token?: string;
  expires_in?: number;
  error?: string;
}

interface GoogleIdentityAccounts {
  oauth2: {
    initTokenClient: (cfg: {
      client_id: string;
      scope: string;
      callback: (resp: GoogleTokenResponse) => void;
    }) => { requestAccessToken: (opts?: { prompt?: string }) => void };
  };
}

export function hasGoogleSessionToken(): boolean {
  return Boolean(sessionGoogleAccessToken) && Date.now() < sessionGoogleTokenExpiry;
}

export function clearGoogleSessionToken(): void {
  sessionGoogleAccessToken = '';
  sessionGoogleTokenExpiry = 0;
}

async function loadGoogleIdentityScript(): Promise<void> {
  const win = window as unknown as { google?: { accounts?: GoogleIdentityAccounts } };
  if (win.google?.accounts?.oauth2) return;

  await new Promise<void>((resolve, reject) => {
    const existing = document.querySelector('script[data-gis-client="true"]');
    if (existing) {
      existing.addEventListener('load', () => resolve());
      existing.addEventListener('error', () =>
        reject(new Error('Gagal memuat Google Identity Services.'))
      );
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    script.dataset.gisClient = 'true';
    script.onload = () => resolve();
    script.onerror = () =>
      reject(
        new Error(
          'Gagal memuat Google Identity Services (offline atau diblokir). Gunakan ekspor DOCX/HTML/CSV.'
        )
      );
    document.head.appendChild(script);
  });
}

export async function authorizeGoogleWorkspaceOptional(clientId: string): Promise<string> {
  const cleanId = clientId.trim();
  if (!cleanId) {
    throw new Error(
      'Google OAuth Client ID belum dikonfigurasi. Isi Client ID di Pengaturan atau gunakan ekspor DOCX/CSV.'
    );
  }
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    throw new Error('Koneksi internet diperlukan untuk autentikasi Google.');
  }

  await loadGoogleIdentityScript();
  const win = window as unknown as { google?: { accounts?: GoogleIdentityAccounts } };
  if (!win.google?.accounts?.oauth2) {
    throw new Error('Google Identity Services tidak tersedia di browser.');
  }

  return new Promise<string>((resolve, reject) => {
    const client = win.google!.accounts!.oauth2.initTokenClient({
      client_id: cleanId,
      scope: 'https://www.googleapis.com/auth/drive.file',
      callback: (resp: GoogleTokenResponse) => {
        if (resp.error || !resp.access_token) {
          reject(
            new Error(
              resp.error
                ? `Autentikasi Google gagal (${resp.error}).`
                : 'Token akses Google tidak diterima.'
            )
          );
          return;
        }
        sessionGoogleAccessToken = resp.access_token;
        sessionGoogleTokenExpiry = Date.now() + ((resp.expires_in ?? 3500) * 1000);
        resolve(resp.access_token);
      },
    });
    client.requestAccessToken({ prompt: 'consent' });
  });
}

export async function saveMeetingToGoogleDocs(
  meeting: MeetingRecord,
  clientId: string
): Promise<{ documentId: string; url: string }> {
  const token = hasGoogleSessionToken()
    ? sessionGoogleAccessToken
    : await authorizeGoogleWorkspaceOptional(clientId);

  const notulen = meeting.notulen || generateTemplateNotulen(meeting);
  const fullText = formatNotulenMarkdownText(notulen, meeting.actionItems);

  const createRes = await fetch('https://docs.googleapis.com/v1/documents', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      title: `Notulen — ${meeting.title || 'Rapat'}`,
    }),
  });

  if (!createRes.ok) {
    throw new Error(
      `Gagal membuat Google Doc (HTTP ${createRes.status}). Pastikan Google Docs API aktif pada Client ID Anda atau gunakan unduh DOCX.`
    );
  }

  const created = (await createRes.json()) as { documentId: string };
  const updateRes = await fetch(
    `https://docs.googleapis.com/v1/documents/${created.documentId}:batchUpdate`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        requests: [
          {
            insertText: {
              location: { index: 1 },
              text: fullText,
            },
          },
        ],
      }),
    }
  );

  if (!updateRes.ok) {
    throw new Error(
      `Dokumen dibuat tetapi gagal mengisi isi notulen (HTTP ${updateRes.status}).`
    );
  }

  return {
    documentId: created.documentId,
    url: `https://docs.google.com/document/d/${created.documentId}/edit`,
  };
}

export async function saveMeetingToGoogleSheets(
  meeting: MeetingRecord,
  clientId: string
): Promise<{ spreadsheetId: string; url: string }> {
  const token = hasGoogleSessionToken()
    ? sessionGoogleAccessToken
    : await authorizeGoogleWorkspaceOptional(clientId);

  const pack = buildGoogleSheetsCsvPack(meeting);

  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: { title: `Data Rapat — ${meeting.title || 'Rapat'}` },
      sheets: [
        { properties: { title: 'Informasi Rapat' } },
        { properties: { title: 'Tindak Lanjut' } },
        { properties: { title: 'Keputusan' } },
        { properties: { title: 'Pembahasan' } },
      ],
    }),
  });

  if (!createRes.ok) {
    throw new Error(
      `Gagal membuat Google Sheet (HTTP ${createRes.status}). Pastikan Google Sheets API aktif pada Client ID Anda atau gunakan ekspor CSV.`
    );
  }

  const created = (await createRes.json()) as {
    spreadsheetId: string;
    spreadsheetUrl?: string;
  };

  const batchRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${created.spreadsheetId}/values:batchUpdate`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        valueInputOption: 'USER_ENTERED',
        data: [
          { range: "'Informasi Rapat'!A1", values: pack.sheet1Info },
          { range: "'Tindak Lanjut'!A1", values: pack.sheet2Actions },
          { range: "'Keputusan'!A1", values: pack.sheet3Decisions },
          { range: "'Pembahasan'!A1", values: pack.sheet4Topics },
        ],
      }),
    }
  );

  if (!batchRes.ok) {
    throw new Error(
      `Spreadsheet dibuat tetapi gagal mengisi baris data (HTTP ${batchRes.status}).`
    );
  }

  return {
    spreadsheetId: created.spreadsheetId,
    url:
      created.spreadsheetUrl ||
      `https://docs.google.com/spreadsheets/d/${created.spreadsheetId}/edit`,
  };
}
