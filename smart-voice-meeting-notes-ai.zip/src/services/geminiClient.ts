import {
  ActionItem,
  DecisionItem,
  DiscussionTopic,
  LetterKind,
  MeetingRecord,
  NotulenData,
  PresentationSlide,
  ReportOutput,
  TranscriptSegment,
} from '../types/meeting';
import { formatDurationHMS, generateId } from '../utils/formatters';
import { formatTranscriptText } from '../utils/meetingLogic';
import { blobToBase64 } from './storage';

// Session-only memory: never written to localStorage or IndexedDB
let sessionGeminiApiKey = '';

export const GEMINI_MODELS = [
  {
    id: 'gemini-4-hydrogen',
    label: 'Gemini 4 Hydrogen (Cepat & Hemat Kuota)',
    supportsAudio: false,
  },
  {
    id: 'gemini-3.5-transcribe',
    label: 'Gemini 3.5 Transcribe (Khusus Transkripsi Audio)',
    supportsAudio: true,
  },
  {
    id: 'gemini-3.1-flash-lite',
    label: 'Gemini 3.1 Flash Lite (Ringkas)',
    supportsAudio: false,
  },
];

export const GEMINI_SECURITY_WARNING =
  'API Key yang digunakan langsung dari browser memiliki risiko terekspos melalui aplikasi, perangkat, atau jaringan. Jangan gunakan API Key dengan akses sensitif atau billing aktif tanpa pengamanan yang memadai.';

export function getSessionGeminiKey(): string {
  return sessionGeminiApiKey;
}

export function setSessionGeminiKey(key: string): void {
  sessionGeminiApiKey = key.trim();
}

export function clearSessionGeminiKey(): void {
  sessionGeminiApiKey = '';
}

export function hasSessionGeminiKey(): boolean {
  return sessionGeminiApiKey.length > 10;
}

interface GeminiGenerateResponse {
  candidates?: Array<{
    content?: {
      parts?: Array<{ text?: string }>;
    };
  }>;
  error?: {
    code?: number;
    message?: string;
    status?: string;
  };
}

function mapGeminiHttpError(status: number, bodyMsg?: string): Error {
  if (status === 400) {
    return new Error(
      `Permintaan ditolak oleh Gemini API (400). Periksa format API Key atau model yang dipilih. ${bodyMsg || ''}`.trim()
    );
  }
  if (status === 401 || status === 403) {
    return new Error(
      'API Key tidak valid atau tidak memiliki izin akses (401/403). Periksa kembali API Key Anda di Pengaturan AI.'
    );
  }
  if (status === 404) {
    return new Error(
      'Model AI tidak ditemukan atau tidak tersedia untuk API Key ini (404). Coba pilih model lain.'
    );
  }
  if (status === 429) {
    return new Error(
      'Kuota Gemini API habis atau melebihi batas laju (429). Audio, transkrip manual, dan template notulen lokal tetap dapat Anda gunakan sepenuhnya.'
    );
  }
  return new Error(bodyMsg || `Kesalahan layanan Gemini API (HTTP ${status}).`);
}

async function callGeminiGenerateContent(params: {
  apiKey: string;
  model: string;
  parts: Array<Record<string, unknown>>;
  systemInstruction?: string;
  responseMimeType?: string;
}): Promise<string> {
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    throw new Error('Tidak ada koneksi internet. Fitur Gemini AI memerlukan internet aktif.');
  }

  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
    params.model
  )}:generateContent?key=${encodeURIComponent(params.apiKey)}`;

  const payload: Record<string, unknown> = {
    contents: [{ role: 'user', parts: params.parts }],
  };
  if (params.systemInstruction) {
    payload.systemInstruction = { parts: [{ text: params.systemInstruction }] };
  }
  if (params.responseMimeType) {
    payload.generationConfig = { responseMimeType: params.responseMimeType };
  }

  let res: Response;
  try {
    res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
  } catch {
    throw new Error(
      'Gagal menghubungi server Gemini API. Periksa koneksi internet atau kebijakan jaringan Anda.'
    );
  }

  const data = (await res.json().catch(() => ({}))) as GeminiGenerateResponse;
  if (!res.ok) {
    throw mapGeminiHttpError(res.status, data.error?.message);
  }

  const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) {
    throw new Error('Gemini API mengembalikan respons kosong.');
  }
  return text;
}

export async function testGeminiConnection(
  apiKey: string,
  model: string
): Promise<{ ok: boolean; message: string }> {
  const trimmed = apiKey.trim();
  if (!trimmed) {
    return { ok: false, message: 'Masukkan API Key terlebih dahulu.' };
  }
  try {
    const reply = await callGeminiGenerateContent({
      apiKey: trimmed,
      model: model || 'gemini-4-hydrogen',
      parts: [{ text: 'Balas dengan satu kata: TERHUBUNG.' }],
    });
    return {
      ok: true,
      message: `Koneksi berhasil (${model}): ${reply.trim().slice(0, 40)}`,
    };
  } catch (err) {
    return {
      ok: false,
      message: err instanceof Error ? err.message : 'Uji koneksi gagal.',
    };
  }
}

export interface AudioTranscriptionProgress {
  completedSegments: number;
  totalSegments: number;
  failedSegments: number[];
  segments: TranscriptSegment[];
}

export async function transcribeAudioChunksWithGemini(params: {
  chunks: Array<{ seq: number; blob: Blob; mimeType: string }>;
  language: string;
  onProgress: (progress: AudioTranscriptionProgress) => void;
}): Promise<{
  segments: TranscriptSegment[];
  isComplete: boolean;
  failedIndexes: number[];
}> {
  const apiKey = getSessionGeminiKey();
  if (!apiKey) {
    throw new Error('API Key Gemini belum dimasukkan pada sesi ini.');
  }
  if (params.chunks.length === 0) {
    throw new Error('Tidak ada rekaman audio untuk ditranskripsi.');
  }

  // Group small 4-second MediaRecorder chunks into ~3MB segments so order is preserved
  // without overloading single inlineData payloads, and never silently drop any segment.
  const MAX_GROUP_BYTES = 3 * 1024 * 1024;
  const groups: Array<{ blobs: Blob[]; mimeType: string }> = [];
  let currentGroup: Blob[] = [];
  let currentSize = 0;
  const baseMime = params.chunks[0].mimeType || 'audio/webm';

  for (const ch of params.chunks) {
    if (currentSize + ch.blob.size > MAX_GROUP_BYTES && currentGroup.length > 0) {
      groups.push({ blobs: currentGroup, mimeType: baseMime });
      currentGroup = [ch.blob];
      currentSize = ch.blob.size;
    } else {
      currentGroup.push(ch.blob);
      currentSize += ch.blob.size;
    }
  }
  if (currentGroup.length > 0) {
    groups.push({ blobs: currentGroup, mimeType: baseMime });
  }

  const allSegments: TranscriptSegment[] = [];
  const failedIndexes: number[] = [];

  for (let i = 0; i < groups.length; i += 1) {
    const grp = groups[i];
    const combinedBlob = new Blob(grp.blobs, { type: grp.mimeType });
    const base64 = await blobToBase64(combinedBlob);

    try {
      const rawText = await callGeminiGenerateContent({
        apiKey,
        model: 'gemini-3.5-transcribe',
        parts: [
          {
            inlineData: {
              mimeType: grp.mimeType.split(';')[0] || 'audio/webm',
              data: base64,
            },
          },
          {
            text: `Transkripsikan rekaman audio rapat ini secara akurat dalam bahasa ${
              params.language === 'en-US' ? 'Inggris' : 'Indonesia'
            }. Jangan mengarang kata yang tidak terdengar; jika tidak jelas tulis [tidak jelas]. Pisahkan tiap giliran bicara dengan label Pembicara 1, Pembicara 2, dst.`,
          },
        ],
      });

      const lines = rawText
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter(Boolean);

      for (const line of lines) {
        const spkMatch = line.match(/^(Pembicara\s*\d+|Speaker\s*\d+|[^:]{2,30}):\s*(.*)$/i);
        allSegments.push({
          id: generateId('seg'),
          timestampSeconds: null,
          speaker: spkMatch ? spkMatch[1].trim() : 'Pembicara 1',
          text: spkMatch ? spkMatch[2].trim() : line,
          isUnclear: line.toLowerCase().includes('[tidak jelas]'),
        });
      }
    } catch {
      failedIndexes.push(i + 1);
      allSegments.push({
        id: generateId('seg'),
        timestampSeconds: null,
        speaker: 'Sistem',
        text: `[Segmen audio ${i + 1}/${groups.length} gagal ditranskripsi — silakan coba ulang atau periksa kuota/koneksi]`,
        isUnclear: true,
      });
    }

    params.onProgress({
      completedSegments: i + 1,
      totalSegments: groups.length,
      failedSegments: [...failedIndexes],
      segments: [...allSegments],
    });
  }

  return {
    segments: allSegments,
    isComplete: failedIndexes.length === 0,
    failedIndexes,
  };
}

export async function generateNotulenWithGemini(
  meeting: MeetingRecord,
  model = 'gemini-4-hydrogen'
): Promise<{
  notulen: NotulenData;
  decisions: DecisionItem[];
  actionItems: ActionItem[];
  discussionTopics: DiscussionTopic[];
  summaryText: string;
}> {
  const apiKey = getSessionGeminiKey();
  if (!apiKey) {
    throw new Error('API Key Gemini belum diatur.');
  }
  const transcript = formatTranscriptText(meeting.transcriptSegments).trim();
  if (!transcript) {
    throw new Error('Transkrip masih kosong. Rekam atau tulis transkrip terlebih dahulu.');
  }

  const prompt = `Susun NOTULEN RAPAT formal dan objektif berdasarkan transkrip dan metadata berikut.
ATURAN KETAT:
1. Jangan mengarang informasi yang tidak ada di transkrip atau metadata. Jika tidak diketahui tulis "Belum diisi" atau "Belum ditentukan".
2. Jangan mengubah usulan atau wacana menjadi keputusan. Jika tidak ada keputusan eksplisit, isi keputusanDanKesepakatan dengan ["Belum ditemukan keputusan yang dinyatakan secara jelas."].
3. Kembalikan JSON murni sesuai struktur berikut:
{
  "informasiKegiatan": {
    "namaKegiatan": "...",
    "tanggal": "...",
    "waktu": "...",
    "lokasi": "...",
    "agenda": "...",
    "peserta": "...",
    "pimpinan": "...",
    "notulis": "..."
  },
  "tujuanRapat": "...",
  "ringkasanPembahasan": "...",
  "pokokPembahasan": ["..."],
  "keputusanDanKesepakatan": ["..."],
  "keputusanDetail": [{"decision": "...", "notes": "..."}],
  "tindakLanjut": [{"task": "...", "pic": "Belum ditentukan", "deadline": "Belum ditentukan", "status": "Belum Dimulai"}],
  "topikPembahasan": [{"topic": "...", "summary": "..."}],
  "kendalaDanCatatan": "...",
  "kesimpulan": "..."
}

Metadata Rapat:
- Judul: ${meeting.title}
- Nama Kegiatan: ${meeting.activityName || 'Belum diisi'}
- Kategori: ${meeting.category}
- Tanggal: ${meeting.date || 'Belum diisi'}
- Waktu: ${meeting.startTime || 'Belum diisi'}
- Lokasi: ${meeting.location || 'Belum diisi'}
- Durasi: ${formatDurationHMS(meeting.durationSeconds)}
- Catatan Awal: ${meeting.notes || 'Tidak ada'}

Transkrip:
${transcript}`;

  const rawJson = await callGeminiGenerateContent({
    apiKey,
    model,
    parts: [{ text: prompt }],
    systemInstruction:
      'Anda adalah notulis profesional berbahasa Indonesia yang sangat teliti dan tidak pernah mengarang fakta.',
    responseMimeType: 'application/json',
  });

  const parsed = JSON.parse(rawJson) as {
    informasiKegiatan?: Partial<NotulenData['informasiKegiatan']>;
    tujuanRapat?: string;
    ringkasanPembahasan?: string;
    pokokPembahasan?: string[];
    keputusanDanKesepakatan?: string[];
    keputusanDetail?: Array<{ decision: string; notes?: string }>;
    tindakLanjut?: Array<{ task: string; pic?: string; deadline?: string; status?: ActionItem['status'] }>;
    topikPembahasan?: Array<{ topic: string; summary: string }>;
    kendalaDanCatatan?: string;
    kesimpulan?: string;
  };

  const notulen: NotulenData = {
    source: 'ai',
    generatedAt: new Date().toISOString(),
    informasiKegiatan: {
      namaKegiatan: parsed.informasiKegiatan?.namaKegiatan || meeting.activityName || meeting.title || 'Belum diisi',
      tanggal: parsed.informasiKegiatan?.tanggal || meeting.date || 'Belum diisi',
      waktu: parsed.informasiKegiatan?.waktu || meeting.startTime || 'Belum diisi',
      lokasi: parsed.informasiKegiatan?.lokasi || meeting.location || 'Belum diisi',
      agenda: parsed.informasiKegiatan?.agenda || meeting.title || 'Belum diisi',
      peserta: parsed.informasiKegiatan?.peserta || 'Belum diisi',
      pimpinan: parsed.informasiKegiatan?.pimpinan || 'Belum diisi',
      notulis: parsed.informasiKegiatan?.notulis || 'Belum diisi',
    },
    tujuanRapat: parsed.tujuanRapat || 'Belum diisi',
    ringkasanPembahasan: parsed.ringkasanPembahasan || 'Belum diisi',
    pokokPembahasan: Array.isArray(parsed.pokokPembahasan) ? parsed.pokokPembahasan : [],
    keputusanDanKesepakatan:
      Array.isArray(parsed.keputusanDanKesepakatan) && parsed.keputusanDanKesepakatan.length > 0
        ? parsed.keputusanDanKesepakatan
        : ['Belum ditemukan keputusan yang dinyatakan secara jelas.'],
    kendalaDanCatatan: parsed.kendalaDanCatatan || 'Tidak ada kendala yang dinyatakan.',
    kesimpulan: parsed.kesimpulan || 'Belum diisi',
    catatanPenyusunan: `Disusun berbantuan Gemini AI (${model}). Harap periksa kembali seluruh fakta, nama, keputusan, dan tindak lanjut sebelum dijadikan dokumen resmi.`,
  };

  const decisions: DecisionItem[] = (parsed.keputusanDetail || []).map((d) => ({
    id: generateId('dec'),
    decision: d.decision,
    notes: d.notes || '',
  }));

  const actionItems: ActionItem[] = (parsed.tindakLanjut || []).map((a) => ({
    id: generateId('act'),
    task: a.task,
    pic: a.pic || 'Belum ditentukan',
    deadline: a.deadline || 'Belum ditentukan',
    status: a.status === 'Proses' || a.status === 'Selesai' ? a.status : 'Belum Dimulai',
  }));

  const discussionTopics: DiscussionTopic[] = (parsed.topikPembahasan || []).map((t) => ({
    id: generateId('top'),
    topic: t.topic,
    summary: t.summary,
  }));

  return {
    notulen,
    decisions,
    actionItems,
    discussionTopics,
    summaryText: notulen.ringkasanPembahasan,
  };
}

export async function generateOtherAiOutput(params: {
  meeting: MeetingRecord;
  kind: 'ringkasan' | 'laporan' | 'surat' | 'ide' | 'presentasi';
  letterKind?: LetterKind;
  model?: string;
}): Promise<
  | { kind: 'ringkasan'; summaryText: string }
  | { kind: 'laporan'; report: ReportOutput }
  | { kind: 'surat'; letter: string }
  | { kind: 'ide'; ideas: string[] }
  | { kind: 'presentasi'; slides: PresentationSlide[] }
> {
  const apiKey = getSessionGeminiKey();
  if (!apiKey) throw new Error('API Key Gemini belum diatur.');
  const model = params.model || 'gemini-4-hydrogen';
  const transcript = formatTranscriptText(params.meeting.transcriptSegments).trim();
  if (!transcript) throw new Error('Transkrip rapat masih kosong.');

  if (params.kind === 'ringkasan') {
    const text = await callGeminiGenerateContent({
      apiKey,
      model,
      parts: [
        {
          text: `Buat ringkasan rapat yang padat, akurat, dan formal dalam Bahasa Indonesia hanya berdasarkan transkrip berikut. Sertakan catatan pemeriksaan di bagian akhir.\n\nTranskrip:\n${transcript}`,
        },
      ],
    });
    return { kind: 'ringkasan', summaryText: text.trim() };
  }

  if (params.kind === 'laporan') {
    const raw = await callGeminiGenerateContent({
      apiKey,
      model,
      responseMimeType: 'application/json',
      parts: [
        {
          text: `Susun Laporan Kegiatan dalam JSON: {"pendahuluan":"","tujuan":"","pelaksanaan":"","pembahasan":"","hasil":"","kesimpulan":"","tindakLanjut":""} berdasarkan metadata (${params.meeting.title}, ${params.meeting.date}, ${params.meeting.location}) dan transkrip berikut. Jangan mengarang data.\n\n${transcript}`,
        },
      ],
    });
    return { kind: 'laporan', report: JSON.parse(raw) as ReportOutput };
  }

  if (params.kind === 'surat') {
    const letterKind = params.letterKind || 'tindak_lanjut';
    const text = await callGeminiGenerateContent({
      apiKey,
      model,
      parts: [
        {
          text: `Susun draf surat resmi jenis "${letterKind}" berdasarkan rapat "${params.meeting.title}" (${params.meeting.date}, ${params.meeting.location}). JANGAN mengarang nomor surat, nama pejabat, NIP, atau tanda tangan — gunakan placeholder seperti [Nomor Surat — Belum Diisi].\n\nTranskrip:\n${transcript}`,
        },
      ],
    });
    return { kind: 'surat', letter: text.trim() };
  }

  if (params.kind === 'ide') {
    const raw = await callGeminiGenerateContent({
      apiKey,
      model,
      responseMimeType: 'application/json',
      parts: [
        {
          text: `Ekstrak daftar ide, usulan, atau peluang perbaikan yang relevan dari transkrip berikut sebagai array string JSON (["..."]).\n\n${transcript}`,
        },
      ],
    });
    return { kind: 'ide', ideas: JSON.parse(raw) as string[] };
  }

  const raw = await callGeminiGenerateContent({
    apiKey,
    model,
    responseMimeType: 'application/json',
    parts: [
      {
        text: `Susun outline materi presentasi dari transkrip rapat berikut dalam format array JSON: [{"slideNumber":1,"title":"...","bullets":["..."]}].\n\n${transcript}`,
      },
    ],
  });
  return { kind: 'presentasi', slides: JSON.parse(raw) as PresentationSlide[] };
}

export async function askMeetingAssistant(params: {
  meeting: MeetingRecord;
  question: string;
  model?: string;
}): Promise<string> {
  const apiKey = getSessionGeminiKey();
  if (!apiKey) {
    throw new Error('API Key Gemini belum tersedia pada sesi ini.');
  }
  const transcript = formatTranscriptText(params.meeting.transcriptSegments).trim();
  if (!transcript) {
    return 'Transkrip rapat ini masih kosong, sehingga belum ada materi yang dapat ditanyakan.';
  }

  const context = [
    `Judul Rapat: ${params.meeting.title}`,
    `Kategori: ${params.meeting.category}`,
    `Tanggal: ${params.meeting.date}`,
    `Lokasi: ${params.meeting.location || 'Belum diisi'}`,
    `Keputusan tercatat: ${
      params.meeting.decisions.map((d) => d.decision).join('; ') || 'Belum ada'
    }`,
    `Tindak lanjut tercatat: ${
      params.meeting.actionItems
        .map((a) => `${a.task} (PIC: ${a.pic}, Tenggat: ${a.deadline}, Status: ${a.status})`)
        .join('; ') || 'Belum ada'
    }`,
    '',
    'TRANSKRIP RAPAT:',
    transcript,
  ].join('\n');

  const answer = await callGeminiGenerateContent({
    apiKey,
    model: params.model || 'gemini-4-hydrogen',
    systemInstruction:
      'Anda adalah AI Meeting Assistant. Jawab pertanyaan HANYA berdasarkan transkrip dan data rapat yang diberikan. Sertakan timestamp jika ada di transkrip. Jika jawabannya tidak ada di transkrip, jawab tepat: "Informasi tersebut tidak ditemukan secara jelas dalam transkrip rapat." Jangan pernah mengarang fakta.',
    parts: [{ text: `${context}\n\nPERTANYAAN PENGGUNA:\n${params.question}` }],
  });

  return answer.trim();
}
