export interface SpeechRecognitionSupport {
  supported: boolean;
  reason?: string;
}

interface SpeechRecognitionAlternativeLike {
  transcript: string;
  confidence: number;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  length: number;
  [index: number]: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike extends Event {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}

interface SpeechRecognitionErrorEventLike extends Event {
  error: string;
  message?: string;
}

interface SpeechRecognitionInstanceLike extends EventTarget {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((ev: SpeechRecognitionEventLike) => void) | null;
  onerror: ((ev: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
  onstart: (() => void) | null;
}

type SpeechRecognitionConstructor = new () => SpeechRecognitionInstanceLike;

function getSpeechConstructor(): SpeechRecognitionConstructor | null {
  if (typeof window === 'undefined') return null;
  const win = window as unknown as {
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  };
  return win.SpeechRecognition || win.webkitSpeechRecognition || null;
}

export function checkSpeechRecognitionSupport(): SpeechRecognitionSupport {
  const Ctor = getSpeechConstructor();
  if (!Ctor) {
    return {
      supported: false,
      reason:
        'Browser ini tidak mendukung Web Speech API (SpeechRecognition). Rekaman audio tetap tersimpan aman di IndexedDB dan dapat ditranskripsi manual atau melalui Gemini AI opsional.',
    };
  }
  return { supported: true };
}

export interface SpeechSessionController {
  stop: () => void;
  pause: () => void;
  resume: () => void;
}

export function startBrowserSpeechRecognition(options: {
  language: string;
  onInterim: (text: string) => void;
  onFinal: (text: string) => void;
  onStatusChange: (status: 'listening' | 'paused' | 'stopped' | 'restarting' | 'error') => void;
  onError: (message: string) => void;
}): SpeechSessionController | null {
  const Ctor = getSpeechConstructor();
  if (!Ctor) {
    options.onError(
      'Web Speech API tidak tersedia pada browser ini. Gunakan mode Audio Saja + input manual atau Gemini AI opsional.'
    );
    return null;
  }

  let shouldBeActive = true;
  let isPaused = false;
  let recognition: SpeechRecognitionInstanceLike | null = null;
  let restartTimer: number | null = null;

  const initAndStart = () => {
    if (!shouldBeActive || isPaused) return;
    try {
      const rec = new Ctor();
      rec.lang = options.language || 'id-ID';
      rec.continuous = true;
      rec.interimResults = true;

      rec.onstart = () => {
        options.onStatusChange('listening');
      };

      rec.onresult = (event: SpeechRecognitionEventLike) => {
        let interimText = '';
        for (let i = event.resultIndex; i < event.results.length; i += 1) {
          const result = event.results[i];
          const text = result[0]?.transcript?.trim() || '';
          if (!text) continue;
          if (result.isFinal) {
            options.onFinal(text);
          } else {
            interimText += (interimText ? ' ' : '') + text;
          }
        }
        options.onInterim(interimText);
      };

      rec.onerror = (event: SpeechRecognitionErrorEventLike) => {
        if (event.error === 'aborted' && (isPaused || !shouldBeActive)) {
          return;
        }
        if (event.error === 'no-speech') {
          return;
        }
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          shouldBeActive = false;
          options.onStatusChange('error');
          options.onError(
            'Layanan pengenalan suara browser ditolak atau tidak diizinkan pada perangkat ini.'
          );
          return;
        }
        if (event.error === 'network') {
          options.onError(
            'Web Speech API membutuhkan koneksi ke layanan pengenalan suara browser. Rekaman audio lokal Anda tetap berjalan.'
          );
          return;
        }
        options.onError(`Peringatan SpeechRecognition: ${event.error}`);
      };

      rec.onend = () => {
        options.onInterim('');
        if (shouldBeActive && !isPaused) {
          options.onStatusChange('restarting');
          restartTimer = window.setTimeout(() => {
            initAndStart();
          }, 350);
        } else if (isPaused) {
          options.onStatusChange('paused');
        } else {
          options.onStatusChange('stopped');
        }
      };

      recognition = rec;
      rec.start();
    } catch (err) {
      options.onStatusChange('error');
      options.onError(
        err instanceof Error
          ? err.message
          : 'Gagal memulai Web Speech API pada browser ini.'
      );
    }
  };

  initAndStart();

  return {
    stop: () => {
      shouldBeActive = false;
      isPaused = false;
      if (restartTimer !== null) {
        clearTimeout(restartTimer);
        restartTimer = null;
      }
      try {
        recognition?.stop();
      } catch {
        // ignore
      }
      options.onStatusChange('stopped');
    },
    pause: () => {
      isPaused = true;
      if (restartTimer !== null) {
        clearTimeout(restartTimer);
        restartTimer = null;
      }
      try {
        recognition?.stop();
      } catch {
        // ignore
      }
      options.onStatusChange('paused');
    },
    resume: () => {
      if (!shouldBeActive) return;
      isPaused = false;
      initAndStart();
    },
  };
}
