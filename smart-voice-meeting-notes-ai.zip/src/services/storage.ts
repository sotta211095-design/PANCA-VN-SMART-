import {
  AppSettings,
  AudioChunkRecord,
  BackupPayload,
  DEFAULT_SETTINGS,
  MeetingRecord,
} from '../types/meeting';

const DB_NAME = 'SmartVoiceMeetingNotesDB';
const DB_VERSION = 1;
const STORE_MEETINGS = 'meetings';
const STORE_AUDIO_CHUNKS = 'audioChunks';
const STORE_SETTINGS = 'settings';
const STORE_DRAFT_META = 'recordingDrafts';

export interface RecordingDraftMeta {
  meetingId: string;
  title: string;
  activityName: string;
  category: string;
  date: string;
  startTime: string;
  location: string;
  notes: string;
  mimeType: string;
  durationSeconds: number;
  chunkCount: number;
  byteSize: number;
  updatedAt: string;
}

export interface StorageEstimateInfo {
  supported: boolean;
  usageBytes: number;
  quotaBytes: number;
  percentUsed: number;
  isNearLimit: boolean;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('Browser Anda tidak mendukung IndexedDB untuk penyimpanan lokal.'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_MEETINGS)) {
        const meetingStore = db.createObjectStore(STORE_MEETINGS, { keyPath: 'id' });
        meetingStore.createIndex('updatedAt', 'updatedAt', { unique: false });
        meetingStore.createIndex('category', 'category', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_AUDIO_CHUNKS)) {
        const chunkStore = db.createObjectStore(STORE_AUDIO_CHUNKS, { keyPath: 'id' });
        chunkStore.createIndex('meetingId', 'meetingId', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
        db.createObjectStore(STORE_SETTINGS, { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains(STORE_DRAFT_META)) {
        db.createObjectStore(STORE_DRAFT_META, { keyPath: 'meetingId' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () =>
      reject(
        new Error(
          request.error?.message || 'Gagal membuka database IndexedDB lokal.'
        )
      );
  });
}

function mapStorageError(err: unknown): Error {
  const msg = err instanceof Error ? err.message : String(err);
  if (
    err instanceof DOMException &&
    (err.name === 'QuotaExceededError' || err.code === 22)
  ) {
    return new Error(
      'Penyimpanan lokal perangkat/browser penuh (QuotaExceededError). Hapus audio rapat lama atau buat backup terlebih dahulu.'
    );
  }
  return new Error(msg || 'Transaksi penyimpanan lokal gagal.');
}

export async function getStorageEstimate(): Promise<StorageEstimateInfo> {
  if (typeof navigator === 'undefined' || !navigator.storage?.estimate) {
    return {
      supported: false,
      usageBytes: 0,
      quotaBytes: 0,
      percentUsed: 0,
      isNearLimit: false,
    };
  }
  try {
    const est = await navigator.storage.estimate();
    const usage = est.usage ?? 0;
    const quota = est.quota ?? 0;
    const percentUsed = quota > 0 ? Math.min(100, (usage / quota) * 100) : 0;
    return {
      supported: true,
      usageBytes: usage,
      quotaBytes: quota,
      percentUsed,
      isNearLimit: percentUsed >= 85,
    };
  } catch {
    return {
      supported: false,
      usageBytes: 0,
      quotaBytes: 0,
      percentUsed: 0,
      isNearLimit: false,
    };
  }
}

export async function getAllMeetings(): Promise<MeetingRecord[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_MEETINGS, 'readonly');
    const store = tx.objectStore(STORE_MEETINGS);
    const req = store.getAll();
    req.onsuccess = () => {
      const items = (req.result as MeetingRecord[]) || [];
      items.sort((a, b) => (b.updatedAt || b.createdAt).localeCompare(a.updatedAt || a.createdAt));
      resolve(items);
    };
    req.onerror = () => reject(mapStorageError(req.error));
  });
}

export async function getMeetingById(id: string): Promise<MeetingRecord | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_MEETINGS, 'readonly');
    const req = tx.objectStore(STORE_MEETINGS).get(id);
    req.onsuccess = () => resolve((req.result as MeetingRecord) || null);
    req.onerror = () => reject(mapStorageError(req.error));
  });
}

export async function saveMeeting(meeting: MeetingRecord): Promise<MeetingRecord> {
  const db = await openDB();
  const updated: MeetingRecord = {
    ...meeting,
    updatedAt: new Date().toISOString(),
  };

  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_MEETINGS, 'readwrite');
    tx.oncomplete = () => resolve(updated);
    tx.onerror = () => reject(mapStorageError(tx.error));
    tx.onabort = () => reject(mapStorageError(tx.error));
    tx.objectStore(STORE_MEETINGS).put(updated);
  });
}

export async function deleteMeeting(id: string): Promise<void> {
  const db = await openDB();
  await deleteAudioChunksForMeeting(id);
  return new Promise((resolve, reject) => {
    const tx = db.transaction([STORE_MEETINGS, STORE_DRAFT_META], 'readwrite');
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(mapStorageError(tx.error));
    tx.objectStore(STORE_MEETINGS).delete(id);
    tx.objectStore(STORE_DRAFT_META).delete(id);
  });
}

export async function saveAudioChunk(chunk: AudioChunkRecord): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_AUDIO_CHUNKS, 'readwrite');
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(mapStorageError(tx.error));
    tx.onabort = () => reject(mapStorageError(tx.error));
    tx.objectStore(STORE_AUDIO_CHUNKS).put(chunk);
  });
}

export async function getAudioChunksForMeeting(meetingId: string): Promise<AudioChunkRecord[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_AUDIO_CHUNKS, 'readonly');
    const index = tx.objectStore(STORE_AUDIO_CHUNKS).index('meetingId');
    const req = index.getAll(IDBKeyRange.only(meetingId));
    req.onsuccess = () => {
      const list = (req.result as AudioChunkRecord[]) || [];
      list.sort((a, b) => a.seq - b.seq);
      resolve(list);
    };
    req.onerror = () => reject(mapStorageError(req.error));
  });
}

export async function assembleMeetingAudio(
  meetingId: string,
  fallbackMime = 'audio/webm'
): Promise<{ blob: Blob | null; chunkCount: number; byteSize: number; mimeType: string }> {
  const chunks = await getAudioChunksForMeeting(meetingId);
  if (chunks.length === 0) {
    return { blob: null, chunkCount: 0, byteSize: 0, mimeType: fallbackMime };
  }
  const mimeType = chunks[0].mimeType || fallbackMime;
  const blob = new Blob(
    chunks.map((c) => c.blob),
    { type: mimeType }
  );
  return {
    blob,
    chunkCount: chunks.length,
    byteSize: blob.size,
    mimeType,
  };
}

export async function deleteAudioChunksForMeeting(meetingId: string): Promise<void> {
  const chunks = await getAudioChunksForMeeting(meetingId);
  if (chunks.length === 0) return;
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_AUDIO_CHUNKS, 'readwrite');
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(mapStorageError(tx.error));
    const store = tx.objectStore(STORE_AUDIO_CHUNKS);
    for (const c of chunks) {
      store.delete(c.id);
    }
  });
}

export async function saveRecordingDraftMeta(draft: RecordingDraftMeta): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_DRAFT_META, 'readwrite');
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(mapStorageError(tx.error));
    tx.objectStore(STORE_DRAFT_META).put(draft);
  });
}

export async function deleteRecordingDraftMeta(meetingId: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_DRAFT_META, 'readwrite');
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(mapStorageError(tx.error));
    tx.objectStore(STORE_DRAFT_META).delete(meetingId);
  });
}

export async function getRecordingDrafts(): Promise<RecordingDraftMeta[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_DRAFT_META, 'readonly');
    const req = tx.objectStore(STORE_DRAFT_META).getAll();
    req.onsuccess = () => resolve((req.result as RecordingDraftMeta[]) || []);
    req.onerror = () => reject(mapStorageError(req.error));
  });
}

export async function loadSettings(): Promise<AppSettings> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_SETTINGS, 'readonly');
      const req = tx.objectStore(STORE_SETTINGS).get('app_settings');
      req.onsuccess = () => {
        const stored = req.result as { key: string; value: Partial<AppSettings> } | undefined;
        resolve({ ...DEFAULT_SETTINGS, ...(stored?.value || {}) });
      };
      req.onerror = () => resolve({ ...DEFAULT_SETTINGS });
    });
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export async function saveSettings(settings: AppSettings): Promise<AppSettings> {
  const db = await openDB();
  // Never store API keys or OAuth tokens in IndexedDB
  const cleanSettings: AppSettings = {
    theme: settings.theme,
    language: settings.language,
    speechLanguage: settings.speechLanguage,
    autoDeleteAudioAfterTranscript: settings.autoDeleteAudioAfterTranscript,
    customCategories: settings.customCategories,
    geminiModel: settings.geminiModel,
    googleClientId: settings.googleClientId,
  };
  try {
    localStorage.setItem('svmn_theme_mode', cleanSettings.theme);
  } catch {
    // ignore localStorage restrictions
  }
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_SETTINGS, 'readwrite');
    tx.oncomplete = () => resolve(cleanSettings);
    tx.onerror = () => reject(mapStorageError(tx.error));
    tx.objectStore(STORE_SETTINGS).put({ key: 'app_settings', value: cleanSettings });
  });
}

export function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const res = typeof reader.result === 'string' ? reader.result : '';
      const comma = res.indexOf(',');
      resolve(comma >= 0 ? res.slice(comma + 1) : res);
    };
    reader.onerror = () => reject(new Error('Gagal membaca data audio untuk backup.'));
    reader.readAsDataURL(blob);
  });
}

export function base64ToBlob(base64: string, mimeType: string): Blob {
  const binary = atob(base64);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new Blob([bytes], { type: mimeType || 'audio/webm' });
}

export async function buildBackupPayload(options: {
  includeAudio: boolean;
  settings: AppSettings;
}): Promise<{ payload: BackupPayload; estimatedBytes: number }> {
  const meetings = await getAllMeetings();
  const audioFiles: BackupPayload['audioFiles'] = [];

  if (options.includeAudio) {
    for (const m of meetings) {
      if (m.hasAudio) {
        const assembled = await assembleMeetingAudio(m.id, m.audioMimeType);
        if (assembled.blob && assembled.byteSize > 0) {
          const base64Data = await blobToBase64(assembled.blob);
          audioFiles.push({
            meetingId: m.id,
            mimeType: assembled.mimeType,
            base64Data,
          });
        }
      }
    }
  }

  const payload: BackupPayload = {
    schemaVersion: 1,
    appName: 'Smart Voice Meeting Notes AI',
    exportedAt: new Date().toISOString(),
    includesAudio: options.includeAudio && audioFiles.length > 0,
    settings: options.settings,
    meetings,
    ...(options.includeAudio ? { audioFiles } : {}),
  };

  const jsonStr = JSON.stringify(payload);
  return {
    payload,
    estimatedBytes: new Blob([jsonStr]).size,
  };
}

export async function restoreBackupPayload(
  payload: BackupPayload,
  mode: 'merge' | 'replace'
): Promise<{ restoredMeetings: number; restoredAudio: number }> {
  const db = await openDB();

  if (mode === 'replace') {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction([STORE_MEETINGS, STORE_AUDIO_CHUNKS, STORE_DRAFT_META], 'readwrite');
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(mapStorageError(tx.error));
      tx.objectStore(STORE_MEETINGS).clear();
      tx.objectStore(STORE_AUDIO_CHUNKS).clear();
      tx.objectStore(STORE_DRAFT_META).clear();
    });
  }

  const audioMap = new Map<string, { mimeType: string; base64Data: string }>();
  if (payload.audioFiles) {
    for (const af of payload.audioFiles) {
      audioMap.set(af.meetingId, { mimeType: af.mimeType, base64Data: af.base64Data });
    }
  }

  let restoredAudio = 0;
  for (const m of payload.meetings) {
    const audioEntry = audioMap.get(m.id);
    const hasRestoredAudio = Boolean(audioEntry);

    if (audioEntry) {
      const blob = base64ToBlob(audioEntry.base64Data, audioEntry.mimeType);
      await deleteAudioChunksForMeeting(m.id);
      await saveAudioChunk({
        id: `${m.id}_0`,
        meetingId: m.id,
        seq: 0,
        blob,
        size: blob.size,
        mimeType: audioEntry.mimeType,
        createdAt: Date.now(),
      });
      restoredAudio += 1;
    }

    await saveMeeting({
      ...m,
      hasAudio: hasRestoredAudio ? true : m.hasAudio && mode === 'merge',
      audioByteSize: audioEntry ? base64ToBlob(audioEntry.base64Data, audioEntry.mimeType).size : m.audioByteSize,
      audioChunkCount: audioEntry ? 1 : m.audioChunkCount,
    });
  }

  if (payload.settings) {
    await saveSettings(payload.settings);
  }

  return {
    restoredMeetings: payload.meetings.length,
    restoredAudio,
  };
}

export async function clearAllLocalData(): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(
      [STORE_MEETINGS, STORE_AUDIO_CHUNKS, STORE_SETTINGS, STORE_DRAFT_META],
      'readwrite'
    );
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(mapStorageError(tx.error));
    tx.objectStore(STORE_MEETINGS).clear();
    tx.objectStore(STORE_AUDIO_CHUNKS).clear();
    tx.objectStore(STORE_SETTINGS).clear();
    tx.objectStore(STORE_DRAFT_META).clear();
  });
}
