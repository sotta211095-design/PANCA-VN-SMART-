import React, { useCallback, useEffect, useState } from 'react';
import {
  AppSettings,
  DEFAULT_SETTINGS,
  MeetingRecord,
  NavigationTab,
  ToastMessage,
} from './types/meeting';
import { generateId } from './utils/formatters';
import { createSampleDemoMeeting } from './utils/meetingLogic';
import {
  deleteMeeting,
  getAllMeetings,
  getRecordingDrafts,
  getStorageEstimate,
  loadSettings,
  RecordingDraftMeta,
  saveMeeting,
  saveSettings,
  StorageEstimateInfo,
} from './services/storage';
import { hasSessionGeminiKey } from './services/geminiClient';
import { NavigationShell } from './components/NavigationShell';
import { DashboardView } from './components/DashboardView';
import { RecorderView } from './components/RecorderView';
import { HistoryView } from './components/HistoryView';
import { MeetingDetailView } from './components/MeetingDetailView';
import { AssistantView } from './components/AssistantView';
import { SettingsView } from './components/SettingsView';
import { PrivacyView } from './components/PrivacyView';
import { ToastContainer } from './components/ToastContainer';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('dashboard');
  const [meetings, setMeetings] = useState<MeetingRecord[]>([]);
  const [selectedMeetingId, setSelectedMeetingId] = useState<string | null>(null);
  const [assistantMeetingId, setAssistantMeetingId] = useState<string | null>(null);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [storageInfo, setStorageInfo] = useState<StorageEstimateInfo>({
    supported: false,
    usageBytes: 0,
    quotaBytes: 0,
    percentUsed: 0,
    isNearLimit: false,
  });
  const [recoverableDrafts, setRecoverableDrafts] = useState<RecordingDraftMeta[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [hasAiKey, setHasAiKey] = useState<boolean>(hasSessionGeminiKey());
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDurationText, setRecordingDurationText] = useState('00:00:00');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const pushToast = useCallback(
    (type: ToastMessage['type'], title: string, description?: string) => {
      const id = generateId('toast');
      setToasts((prev) => [...prev.slice(-1), { id, type, title, description }]);
      window.setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 3200);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const applyThemeClass = useCallback((theme: AppSettings['theme']) => {
    if (theme === 'light') {
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.add('dark');
    }
  }, []);

  const refreshAll = useCallback(async () => {
    try {
      const [loadedMeetings, loadedSettings, est, drafts] = await Promise.all([
        getAllMeetings(),
        loadSettings(),
        getStorageEstimate(),
        getRecordingDrafts(),
      ]);
      setMeetings(loadedMeetings);
      setSettings(loadedSettings);
      applyThemeClass(loadedSettings.theme);
      setStorageInfo(est);
      setRecoverableDrafts(drafts);
      setLoadError(null);
    } catch (err) {
      setLoadError(
        err instanceof Error
          ? err.message
          : 'Gagal membaca database lokal IndexedDB.'
      );
    } finally {
      setIsLoading(false);
    }
  }, [applyThemeClass]);

  useEffect(() => {
    refreshAll();
  }, [refreshAll]);

  const handleSaveSettings = async (next: AppSettings) => {
    try {
      const saved = await saveSettings(next);
      setSettings(saved);
      applyThemeClass(saved.theme);
    } catch (err) {
      pushToast(
        'error',
        'Gagal menyimpan pengaturan',
        err instanceof Error ? err.message : 'Kesalahan IndexedDB.'
      );
    }
  };

  const handleAddCustomCategory = async (cat: string) => {
    const nextCats = Array.from(new Set([...settings.customCategories, cat]));
    await handleSaveSettings({ ...settings, customCategories: nextCats });
  };

  const handleOpenMeeting = (id: string) => {
    setSelectedMeetingId(id);
    setActiveTab('detail');
  };

  const handleUpdateMeeting = async (updated: MeetingRecord) => {
    const saved = await saveMeeting(updated);
    setMeetings((prev) => prev.map((m) => (m.id === saved.id ? saved : m)));
    const est = await getStorageEstimate();
    setStorageInfo(est);
  };

  const handleDeleteMeeting = async (id: string) => {
    await deleteMeeting(id);
    setMeetings((prev) => prev.filter((m) => m.id !== id));
    if (selectedMeetingId === id) {
      setSelectedMeetingId(null);
      setActiveTab('history');
    }
    const est = await getStorageEstimate();
    setStorageInfo(est);
  };

  const handleMeetingSaved = async (saved: MeetingRecord) => {
    setMeetings((prev) => [saved, ...prev.filter((m) => m.id !== saved.id)]);
    setSelectedMeetingId(saved.id);
    setActiveTab('detail');
    const est = await getStorageEstimate();
    setStorageInfo(est);
  };

  const handleCreateDemoMeeting = async () => {
    try {
      const demo = createSampleDemoMeeting();
      const saved = await saveMeeting(demo);
      setMeetings((prev) => [saved, ...prev]);
      setSelectedMeetingId(saved.id);
      setActiveTab('detail');
      const est = await getStorageEstimate();
      setStorageInfo(est);
      pushToast(
        'success',
        'Contoh rapat dimuat',
        'Data contoh lokal ditambahkan ke IndexedDB untuk uji coba fitur.'
      );
    } catch (err) {
      pushToast(
        'error',
        'Gagal memuat contoh rapat',
        err instanceof Error ? err.message : 'Kesalahan IndexedDB.'
      );
    }
  };

  const selectedMeeting =
    meetings.find((m) => m.id === selectedMeetingId) || null;

  const pageTitles: Record<NavigationTab, string> = {
    dashboard: 'Beranda',
    recorder: 'Rekam Rapat Baru',
    history: 'Riwayat Rapat',
    assistant: 'AI Tanya Rapat',
    settings: 'Pengaturan & Backup',
    privacy: 'Privasi & Keamanan',
    detail: selectedMeeting ? selectedMeeting.title : 'Detail Rapat',
  };

  return (
    <>
      <NavigationShell
        activeTab={activeTab}
        onNavigate={(tab) => setActiveTab(tab)}
        storageInfo={storageInfo}
        isRecording={isRecording}
        recordingDurationText={recordingDurationText}
        hasAiKey={hasAiKey}
        pageTitle={pageTitles[activeTab]}
      >
        {isLoading ? (
          <div className="space-y-4">
            <div className="h-44 rounded-2xl border border-slate-200 bg-white/70 p-6 animate-pulse dark:border-slate-800 dark:bg-[#131A26]/60" />
            <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
              {[1, 2, 3, 4].map((n) => (
                <div
                  key={n}
                  className="h-24 rounded-2xl border border-slate-200 bg-white/70 animate-pulse dark:border-slate-800 dark:bg-[#131A26]/60"
                />
              ))}
            </div>
          </div>
        ) : loadError ? (
          <div
            role="alert"
            className="rounded-2xl border border-rose-500/30 bg-rose-500/10 p-6 text-sm text-rose-800 dark:text-rose-200"
          >
            <p className="font-semibold">Kendala Penyimpanan Lokal</p>
            <p className="mt-1 text-xs">{loadError}</p>
          </div>
        ) : (
          <>
            {activeTab === 'dashboard' && (
              <DashboardView
                meetings={meetings}
                onNavigate={setActiveTab}
                onOpenMeeting={handleOpenMeeting}
                onCreateDemoMeeting={handleCreateDemoMeeting}
                hasAiKey={hasAiKey}
              />
            )}

            {activeTab === 'recorder' && (
              <RecorderView
                settings={settings}
                recoverableDrafts={recoverableDrafts}
                onRefreshDrafts={async () => {
                  const d = await getRecordingDrafts();
                  setRecoverableDrafts(d);
                }}
                onAddCustomCategory={handleAddCustomCategory}
                onMeetingSaved={handleMeetingSaved}
                onRecordingActiveChange={(active, dur) => {
                  setIsRecording(active);
                  setRecordingDurationText(dur);
                }}
                onToast={pushToast}
              />
            )}

            {activeTab === 'history' && (
              <HistoryView
                meetings={meetings}
                settings={settings}
                onOpenMeeting={handleOpenMeeting}
                onDeleteMeeting={handleDeleteMeeting}
                onNavigateRecorder={() => setActiveTab('recorder')}
                onToast={pushToast}
              />
            )}

            {activeTab === 'detail' && selectedMeeting && (
              <MeetingDetailView
                meeting={selectedMeeting}
                settings={settings}
                hasAiKey={hasAiKey}
                onUpdateMeeting={handleUpdateMeeting}
                onBack={() => setActiveTab('history')}
                onAskAssistant={(id) => {
                  setAssistantMeetingId(id);
                  setActiveTab('assistant');
                }}
                onToast={pushToast}
              />
            )}

            {activeTab === 'assistant' && (
              <AssistantView
                meetings={meetings}
                settings={settings}
                hasAiKey={hasAiKey}
                initialMeetingId={assistantMeetingId}
                onNavigateSettings={() => setActiveTab('settings')}
                onOpenMeeting={handleOpenMeeting}
              />
            )}

            {activeTab === 'settings' && (
              <SettingsView
                settings={settings}
                storageInfo={storageInfo}
                meetingCount={meetings.length}
                onSaveSettings={handleSaveSettings}
                onRefreshAll={refreshAll}
                onAiKeyChanged={setHasAiKey}
                onToast={pushToast}
              />
            )}

            {activeTab === 'privacy' && (
              <PrivacyView onNavigateSettings={() => setActiveTab('settings')} />
            )}
          </>
        )}
      </NavigationShell>

      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </>
  );
}
